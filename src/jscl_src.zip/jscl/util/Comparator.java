package jscl.util;

import java.io.*;

public abstract class Comparator implements Serializable {
	public abstract int compare(Object o1, Object o2);
}
