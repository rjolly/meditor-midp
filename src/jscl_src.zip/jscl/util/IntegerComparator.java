package jscl.util;

public class IntegerComparator extends Comparator {
	public static final Comparator comparator=new IntegerComparator();

	private IntegerComparator() {}

	public int compare(Object o1, Object o2) {
		int i1=((Integer)o1).intValue();
		int i2=((Integer)o2).intValue();
		return i1<i2?-1:(i1>i2?1:0);
	}
}
