package jscl.util;

public class ParseException extends Exception {
	public ParseException() {}

	public ParseException(String s) {
		super(s);
	}
}
