package jscl.util;

public interface Comparable {
	int compareTo(Comparable comparable);
}
