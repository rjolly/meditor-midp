package jscl.util;

public class GenericComparator extends Comparator {
	public static final Comparator comparator=new GenericComparator();

	private GenericComparator() {}

	public int compare(Object o1, Object o2) {
		Comparable o=(Comparable)o1;
		return o.compareTo((Comparable)o2);
	}
}
