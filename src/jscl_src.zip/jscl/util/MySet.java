package jscl.util;

import java.util.*;

public interface MySet extends Set, MyCollection {}
