package jscl.util;

import java.util.*;

public abstract class MyAbstractCollection extends AbstractCollection implements MyCollection {}
