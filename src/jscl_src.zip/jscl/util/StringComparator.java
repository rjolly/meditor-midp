package jscl.util;

public class StringComparator extends Comparator {
	public static final Comparator comparator=new StringComparator();

	private StringComparator() {}

	public int compare(Object o1, Object o2) {
		return ((String)o1).compareTo((String)o2);
	}
}
