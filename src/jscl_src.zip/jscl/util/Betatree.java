package jscl.util;

import java.io.*;
import java.util.*;

//public class Betatree extends Dictionary implements Cloneable, Serializable {
public class Betatree extends Dictionary implements Serializable {
	public jscl.util.Comparator comparator;
	Leaf root;
	int order;

//	class Leaf implements Cloneable, Serializable {
	class Leaf implements Serializable {
		Entry entry[];
		int count;

		transient int index;

		final class Enumerator implements Enumeration {
			boolean keys;
			boolean direction;
			int count;

			Enumerator(boolean keys, boolean direction) {
				this.keys=keys;
				this.direction=direction;
				count=direction?Leaf.this.count:0;
			}

			public boolean hasMoreElements() {
				return direction?count > 0:count < Leaf.this.count;
			}

			public Object nextElement() {
				synchronized (Leaf.this) {
					if (direction?count > 0:count < Leaf.this.count) {
						Entry en=entry[direction?--count:count++];
						return keys?en.key:en.element;
					}
				}
				throw new NoSuchElementException("Enumerator");
			}
		}

		Leaf() {
			entry=new Entry[order<<1];
		}

		Enumeration keys(boolean direction) {
			return new Enumerator(true,direction);
		}

		Enumeration elements(boolean direction) {
			return new Enumerator(false,direction);
		}

		int size() {
			return count;
		}

		boolean containsAt(Entry entry) {
			return index<count?comparator.compare(this.entry[index].key,entry.key)==0:false;
		}

		boolean contains(Entry entry) {
			indexOf(entry);
			return containsAt(entry);
		}

		void indexOf(Entry entry, int l1, int l2) {
			if(index<l2?comparator.compare(this.entry[index].key,entry.key)<0:false) {
				l1=index+1;
				index=(l1+l2)>>1;
				indexOf(entry,l1,l2);
			} else if(index>l1?comparator.compare(this.entry[index-1].key,entry.key)>=0:false) {
				l2=index-1;
				index=(l1+l2)>>1;
				indexOf(entry,l1,l2);
			}
		}

		void indexOf(Entry entry) {
			indexOf(entry,0,count);
		}

		void putAt(Entry entry) {
			System.arraycopy(this.entry, index, this.entry, index + 1, count - index);
			this.entry[index] = entry;
			count++;
		}

		void removeAt() {
			System.arraycopy(entry, index + 1, entry, index, count - index - 1);
			entry[count-1] = null;
			count--;
		}

		Entry get(Entry entry) {
			indexOf(entry);
			if(containsAt(entry)) return this.entry[index];
			else return new Entry(entry.key,null);
		}

		Entry put(Entry entry) {
			indexOf(entry);
			if(!containsAt(entry)) {
				if(count<order<<1) {
					putAt(entry);
					return new Entry(entry.key,null);
				} else return split(entry);
			} else {
				Entry e=this.entry[index];
				this.entry[index]=entry;
				return e;
			}
		}

		Entry split(Entry entry) {
			Entry newentry;
			Leaf newleaf=new Leaf();

			if(index<order) {
				System.arraycopy(this.entry, order, newleaf.entry, 0, order);
				newleaf.count=order;
				newentry=this.entry[order-1];
				for(int i=order-1;i<count;i++) this.entry[i]=null;
				count=order-1;
				putAt(entry);
			} else if(index>order) {
				System.arraycopy(this.entry, order + 1, newleaf.entry, 0, order - 1);
				newleaf.count=order-1;
				newentry=this.entry[order];
				for(int i=order;i<count;i++) this.entry[i]=null;
				count=order;
				newleaf.index=index-order-1;
				newleaf.putAt(entry);
				index=0;
			} else {
				System.arraycopy(this.entry, order, newleaf.entry, 0, order);
				newleaf.count=order;
				newentry=entry;
				for(int i=order;i<count;i++) this.entry[i]=null;
				count=order;
			}
			return new Overflow(entry.key,null,newentry,newleaf);
		}

		Entry remove(Entry entry) {
			indexOf(entry);
			if(containsAt(entry)) {
				Entry e=this.entry[index];
				removeAt();
				if(count<order) return new Underflow(e.key,e.element);
				else return e;
			} else return new Entry(entry.key,null);
		}

		Entry redistribute(Entry entry, Leaf leaf) {
			int count=Math.abs(leaf.count-this.count)>>1;
			Entry newentry;

			if(this.count<leaf.count) {
				this.entry[this.count]=entry;
				System.arraycopy(leaf.entry, 0, this.entry, this.count+1, count-1);
				this.count+=count;
				newentry=leaf.entry[count-1];
				System.arraycopy(leaf.entry, count, leaf.entry, 0, leaf.count-count);
				for(int i=leaf.count-count;i<leaf.count;i++) leaf.entry[i]=null;
				leaf.count-=count;
				leaf.index=0;
			} else {
				System.arraycopy(leaf.entry, 0, leaf.entry, count, leaf.count);
				System.arraycopy(this.entry, this.count-count+1, leaf.entry, 0, count-1);
				leaf.entry[count-1]=entry;
				leaf.count+=count;
				leaf.index+=count;
				newentry=this.entry[this.count-count];
				for(int i=this.count-count;i<this.count;i++) this.entry[i]=null;
				this.count-=count;
				index=0;
			}
			return newentry;
		}

		void combine(Entry entry, Leaf leaf) {
			this.entry[count]=entry;
			System.arraycopy(leaf.entry, 0, this.entry, count+1, leaf.count);
			count+=leaf.count+1;
		}

		Entry first() {
			return entry[0];
		}

//		protected synchronized Object clone() throws CloneNotSupportedException {
//			Leaf clone = (Leaf)super.clone();
//			clone.entry = new Entry[entry.length];
//			System.arraycopy(entry, 0, clone.entry, 0, count);
//			return clone;
//		}
	}

	class Node extends Leaf {
		Leaf leaf[];

		final class Enumerator implements Enumeration {
			Enumeration leafEnumeration;
			boolean keys;
			boolean direction;
			int count;

			Enumerator(boolean keys, boolean direction) {
				this.keys=keys;
				this.direction=direction;
				count=direction?Node.this.count:0;
				setLeafEnumeration();
			}

			public boolean hasMoreElements() {
				if(leafEnumeration.hasMoreElements()) return true;
				else {
					synchronized (Node.this) {
						if (direction?count > 0:count < Node.this.count) {
							return true;
						}
					}
				}
				return false;
			}

			public Object nextElement() {
				try {
					return leafEnumeration.nextElement();
				} catch (NoSuchElementException e) {
					synchronized (Node.this) {
						if (direction?count > 0:count < Node.this.count) {
							Entry en=entry[direction?--count:count++];
							setLeafEnumeration();
							return keys?en.key:en.element;
						}
					}
				}
				throw new NoSuchElementException("Enumerator");
			}

			void setLeafEnumeration() {
				leafEnumeration=keys?leaf[count].keys(direction):leaf[count].elements(direction);
			}
		}

		Node() {
			leaf=new Leaf[(order<<1)+1];
		}

		Enumeration keys(boolean direction) {
			return new Enumerator(true,direction);
		}

		Enumeration elements(boolean direction) {
			return new Enumerator(false,direction);
		}

		int size() {
			int size=count;
			for(int i=0;i<count+1;i++) {
				size+=leaf[i].size();
			}
			return size;
		}

		boolean contains(Entry entry) {
			indexOf(entry);
			if(containsAt(entry)) return true;
			else return leaf[index].contains(entry);
		}

		void putAt(Entry entry, Leaf leaf) {
			System.arraycopy(this.entry, index, this.entry, index + 1, count - index);
			System.arraycopy(this.leaf, index + 1, this.leaf, index + 2, count - index);
			this.entry[index] = entry;
			this.leaf[index+1] = leaf;
			count++;
		}

		void removeAt() {
			System.arraycopy(entry, index + 1, entry, index, count - index - 1);
			System.arraycopy(leaf, index + 2, leaf, index + 1, count - index - 1);
			entry[count-1] = null;
			leaf[count] = null;
			count--;
		}

		Entry get(Entry entry) {
			indexOf(entry);
			if(containsAt(entry)) return this.entry[index];
			else return leaf[index].get(entry);
		}

		Entry put(Entry entry) {
			indexOf(entry);
			if(!containsAt(entry)) {
				Entry e=leaf[index].put(entry);
				if(e instanceof Overflow) {
					Overflow o=(Overflow)e;
					if(count<order<<1) {
						putAt(o.entry,o.leaf);
						return new Entry(o.key,o.element);
					} else return split(o.entry,o.leaf);
				} else return e;
			} else {
				Entry e=this.entry[index];
				this.entry[index]=entry;
				return e;
			}
		}

		Entry split(Entry entry, Leaf leaf) {
			Entry newentry;
			Node newnode=new Node();

			if(index<order) {
				System.arraycopy(this.entry, order, newnode.entry, 0, order);
				System.arraycopy(this.leaf, order, newnode.leaf, 0, order + 1);
				newnode.count=order;
				newentry=this.entry[order-1];
				for(int i=order-1;i<count;i++) this.entry[i]=null;
				for(int i=order;i<count+1;i++) this.leaf[i]=null;
				count=order-1;
				putAt(entry,leaf);
			} else if(index>order) {
				System.arraycopy(this.entry, order + 1, newnode.entry, 0, order - 1);
				System.arraycopy(this.leaf, order + 1, newnode.leaf, 0, order);
				newnode.count=order-1;
				newentry=this.entry[order];
				for(int i=order;i<count;i++) this.entry[i]=null;
				for(int i=order+1;i<count+1;i++) this.leaf[i]=null;
				count=order;
				newnode.index=index-order-1;
				newnode.putAt(entry,leaf);
				index=0;
			} else {
				System.arraycopy(this.entry, order, newnode.entry, 0, order);
				newnode.leaf[0]=leaf;
				System.arraycopy(this.leaf, order + 1, newnode.leaf, 1, order);
				newnode.count=order;
				newentry=entry;
				for(int i=order;i<count;i++) this.entry[i]=null;
				for(int i=order+1;i<count+1;i++) this.leaf[i]=null;
				count=order;
			}
			return new Overflow(entry.key,null,newentry,newnode);
		}

		Entry remove(Entry entry) {
			indexOf(entry);
			if(containsAt(entry)) {
				entry=leaf[index+1].first();
				this.entry[index++]=entry;
			}
			Entry e=leaf[index].remove(entry);
			if(e instanceof Underflow) {
				Underflow u=(Underflow)e;
				int neighbour=index<count?index+1:index-1;
				index=Math.min(index,count-1);
				if(leaf[neighbour].count>order) {
					this.entry[index]=leaf[index].redistribute(this.entry[index],leaf[index+1]);
					return new Entry(u.key,u.element);
				} else {
					leaf[index].combine(this.entry[index],leaf[index+1]);
					removeAt();
					if(count<order) return u;
					else return new Entry(u.key,u.element);
				}
			} else return e;
		}

		Entry redistribute(Entry entry, Leaf leaf) {
			Node node=(Node)leaf;
			int count=Math.abs(node.count-this.count)>>1;
			Entry newentry;

			if(this.count<node.count) {
				this.entry[this.count]=entry;
				System.arraycopy(node.entry, 0, this.entry, this.count+1, count-1);
				System.arraycopy(node.leaf, 0, this.leaf, this.count+1, count);
				this.count+=count;
				newentry=node.entry[count-1];
				System.arraycopy(node.entry, count, node.entry, 0, node.count-count);
				System.arraycopy(node.leaf, count, node.leaf, 0, node.count-count+1);
				for(int i=node.count-count;i<node.count;i++) node.entry[i]=null;
				for(int i=node.count-count+1;i<node.count+1;i++) node.leaf[i]=null;
				node.count-=count;
				node.index=0;
			} else {
				System.arraycopy(node.entry, 0, node.entry, count, node.count);
				System.arraycopy(node.leaf, 0, node.leaf, count, node.count+1);
				System.arraycopy(this.entry, this.count-count+1, node.entry, 0, count-1);
				System.arraycopy(this.leaf, this.count-count+1, node.leaf, 0, count);
				node.entry[count-1]=entry;
				node.count+=count;
				node.index+=count;
				newentry=this.entry[this.count-count];
				for(int i=this.count-count;i<this.count;i++) this.entry[i]=null;
				for(int i=this.count-count+1;i<this.count+1;i++) this.leaf[i]=null;
				this.count-=count;
				index=0;
			}
			return newentry;
		}

		void combine(Entry entry, Leaf leaf) {
			Node node=(Node)leaf;
    
			this.entry[count]=entry;
			System.arraycopy(node.entry, 0, this.entry, count + 1, node.count);
			System.arraycopy(node.leaf, 0, this.leaf, count + 1, node.count + 1);
			count+=node.count+1;
		}

		Entry first() {
			return leaf[0].first();
		}

//		protected synchronized Object clone() throws CloneNotSupportedException {
//			Node clone = (Node)super.clone();
//			clone.leaf = new Leaf[leaf.length];
//			for(int i=0;i<count+1;i++) clone.leaf[i]=(Leaf)leaf[i].clone();
//			return clone;
//		}
	}

	class Entry implements Serializable {
		Object key;
		Object element;

		Entry(Object key, Object element) {
			this.key=key;
			this.element=element;
		}
	}

	class Overflow extends Entry {
		Entry entry;
		Leaf leaf;

		Overflow(Object key, Object element, Entry entry, Leaf leaf) {
			super(key,element);
			this.entry=entry;
			this.leaf=leaf;
		}
	}

	class Underflow extends Entry {
		Underflow(Object key, Object element) {
			super(key,element);
		}
	}

	public Betatree(int order, jscl.util.Comparator comparator) {
		this.comparator=comparator;
		this.order=order;
		root=new Leaf();
	}

	public Betatree(jscl.util.Comparator comparator) {
		this(4,comparator);
	}

	public Betatree() {
		this(4,GenericComparator.comparator);
	}

	public synchronized Enumeration keys(boolean direction) {
		return root.keys(direction);
	}

	public synchronized Enumeration elements(boolean direction) {
		return root.elements(direction);
	}

	public synchronized Enumeration keys() {
		return root.keys(false);
	}

	public synchronized Enumeration elements() {
		return root.elements(false);
	}

	public boolean isEmpty() {
		return root.count==0;
	}

	public int size() {
		return root.size();
	}

	public synchronized Object get(Object key) {
		Entry e=new Entry(key,null);
		return get(e).element;
	}

	public synchronized Object put(Object key, Object element) {
		Entry e=new Entry(key,element);
		return put(e).element;
	}

	public synchronized Object remove(Object key) {
		Entry e=new Entry(key,null);
		return remove(e).element;
	}

	public synchronized boolean containsKey(Object key) {
		return contains(new Entry(key,null));
	}

	boolean contains(Entry entry) {
		return root.contains(entry);
	}

	Entry get(Entry entry) {
		return root.get(entry);
	}

	Entry put(Entry entry) {
		Entry e=root.put(entry);
		if(e instanceof Overflow) {
			Overflow o=(Overflow)e;
			Node newroot=new Node();
			newroot.leaf[0]=root;
			newroot.entry[0]=o.entry;
			newroot.leaf[1]=o.leaf;
			newroot.count=1;
			root=newroot;
			return new Entry(o.key,o.element);
		} else return e;
	}

	Entry remove(Entry entry) {
		Entry e=root.remove(entry);
		if(e instanceof Underflow) {
			Underflow u=(Underflow)e;
			if(root instanceof Node && root.count==0) {
				Node oldroot=(Node)root;
				root=oldroot.leaf[0];
			}
			return new Entry(u.key,u.element);
		} else return e;
	}

	public synchronized String toString() {
		int max = size() - 1;
		StringBuffer buf = new StringBuffer();
		Enumeration k = keys();
		Enumeration e = elements();
		buf.append("{");

		for (int i = 0; i <= max; i++) {
			String s1 = k.nextElement().toString();
			String s2 = e.nextElement().toString();
			buf.append(s1 + "=" + s2);
			if (i < max) {
				buf.append(", ");
			}
		}
		buf.append("}");
		return buf.toString();
	}

//	protected synchronized Object clone() {
//		try {
//			Betatree clone=(Betatree)super.clone();
//			clone.root=(Leaf)root.clone();
//			return clone;
//		} catch (CloneNotSupportedException e) {
//			throw new InternalError();
//		}
//	}
}
