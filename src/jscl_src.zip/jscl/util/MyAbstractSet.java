package jscl.util;

import java.util.*;

public abstract class MyAbstractSet extends AbstractSet implements MySet {}
