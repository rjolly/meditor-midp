package jscl.util;

import java.util.*;

public interface MyCollection extends Collection {
	Iterator iterator(boolean direction);
}
