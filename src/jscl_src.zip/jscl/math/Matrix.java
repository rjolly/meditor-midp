package jscl.math;

import java.util.*;
import jscl.math.function.*;
import jscl.math.function.trigonometric.*;
import jscl.text.*;
import jscl.util.*;

public class Matrix extends Arithmetic {
	public static final Parser parser=MatrixParser.parser;
	public Arithmetic element[][];
	protected int n,p;

	public Matrix(Arithmetic element[][]) {
		put(element);
	}

	void put(Arithmetic element[][]) {
		this.element=element;
		n=element.length;
		p=element.length>0?element[0].length:0;
	}

	public Arithmetic add(Arithmetic arithmetic) {
		if(arithmetic instanceof Matrix) {
			Matrix m=(Matrix)arithmetic;
			Matrix m2=(Matrix)newinstance();
			for(int i=0;i<n;i++) {
				for(int j=0;j<p;j++) {
					m2.element[i][j]=element[i][j].add(m.element[i][j]);
				}
			}
			return m2;
		} else if(arithmetic instanceof JSCLVector) {
			return null;
		} else {
			return add(valueof(arithmetic));
		}
	}

	public Arithmetic subtract(Arithmetic arithmetic) {
		if(arithmetic instanceof Matrix) {
			Matrix m=(Matrix)arithmetic;
			Matrix m2=(Matrix)newinstance();
			for(int i=0;i<n;i++) {
				for(int j=0;j<p;j++) {
					m2.element[i][j]=element[i][j].subtract(m.element[i][j]);
				}
			}
			return m2;
		} else if(arithmetic instanceof JSCLVector) {
			return null;
		} else {
			return subtract(valueof(arithmetic));
		}
	}

	public Arithmetic multiply(Arithmetic arithmetic) throws ArithmeticException {
		if(arithmetic instanceof Matrix) {
			Matrix m=(Matrix)arithmetic;
			if(p!=m.n) throw new ArithmeticException();
			Matrix m2=(Matrix)newinstance(n,m.p);
			for(int i=0;i<n;i++) {
				for(int j=0;j<m.p;j++) {
					m2.element[i][j]=JSCLInteger.valueOf(0);
					for(int k=0;k<p;k++) {
						m2.element[i][j]=m2.element[i][j].add(element[i][k].multiply(m.element[k][j]));
					}
				}
			}
			return m2;
		} else if(arithmetic instanceof JSCLVector) {
			JSCLVector v=(JSCLVector)arithmetic;
			if(p!=v.n) throw new ArithmeticException();
			JSCLVector v2=(JSCLVector)((JSCLVector)arithmetic).newinstance(n);
			for(int i=0;i<n;i++) {
				v2.element[i]=JSCLInteger.valueOf(0);
				for(int k=0;k<p;k++) {
					v2.element[i]=v2.element[i].add(element[i][k].multiply(v.element[k]));
				}
			}
			return v2;
		} else {
			Matrix m=(Matrix)newinstance();
			for(int i=0;i<n;i++) {
				for(int j=0;j<p;j++) {
					m.element[i][j]=element[i][j].multiply(arithmetic);
				}
			}
			return m;
		}
	}

	public Arithmetic divide(Arithmetic arithmetic) throws ArithmeticException {
		if(arithmetic instanceof Matrix) {
			return null;
		} else if(arithmetic instanceof JSCLVector) {
			return null;
		} else {
			Matrix m=(Matrix)newinstance();
			for(int i=0;i<n;i++) {
				for(int j=0;j<p;j++) {
					m.element[i][j]=element[i][j].divide(arithmetic);
				}
			}
			return m;
		}
	}

	public Arithmetic[] divideAndRemainder(Arithmetic arithmetic) throws ArithmeticException {
		return null;
	}

	public Arithmetic gcd(Arithmetic arithmetic) {
		return null;
	}

	public Arithmetic gcd() {
		return null;
	}

	public Arithmetic negate() {
		Matrix m=(Matrix)newinstance();
		for(int i=0;i<n;i++) {
			for(int j=0;j<p;j++) {
				m.element[i][j]=element[i][j].negate();
			}
		}
		return m;
	}

	public int signum() {
		return 0;
	}

	public int degree() {
		return 0;
	}

	public Arithmetic antiderivative(Variable variable) throws NotIntegrableException {
		Matrix m=(Matrix)newinstance();
		for(int i=0;i<n;i++) {
			for(int j=0;j<p;j++) {
				m.element[i][j]=element[i][j].antiderivative(variable);
			}
		}
		return m;
	}

	public Arithmetic derivative(Variable variable) {
		Matrix m=(Matrix)newinstance();
		for(int i=0;i<n;i++) {
			for(int j=0;j<p;j++) {
				m.element[i][j]=element[i][j].derivative(variable);
			}
		}
		return m;
	}

	public Arithmetic substitute(Variable variable, Arithmetic arithmetic) {
		Matrix m=(Matrix)newinstance();
		for(int i=0;i<n;i++) {
			for(int j=0;j<p;j++) {
				m.element[i][j]=element[i][j].substitute(variable,arithmetic);
			}
		}
		return m;
	}

	public Arithmetic expand() {
		Matrix m=(Matrix)newinstance();
		for(int i=0;i<n;i++) {
			for(int j=0;j<p;j++) {
				m.element[i][j]=element[i][j].expand();
			}
		}
		return m;
	}

	public Arithmetic factorize() {
		Matrix m=(Matrix)newinstance();
		for(int i=0;i<n;i++) {
			for(int j=0;j<p;j++) {
				m.element[i][j]=element[i][j].factorize();
			}
		}
		return m;
	}

	public Arithmetic elementary() {
		Matrix m=(Matrix)newinstance();
		for(int i=0;i<n;i++) {
			for(int j=0;j<p;j++) {
				m.element[i][j]=element[i][j].elementary();
			}
		}
		return m;
	}

	public Arithmetic simplify() {
		Matrix m=(Matrix)newinstance();
		for(int i=0;i<n;i++) {
			for(int j=0;j<p;j++) {
				m.element[i][j]=element[i][j].simplify();
			}
		}
		return m;
	}

	public Arithmetic valueof(Arithmetic arithmetic) {
		Matrix m=(Matrix)identity(Math.max(n,p)).multiply(arithmetic);
		Matrix m2=(Matrix)newinstance();
		for(int i=0;i<n;i++) {
			for(int j=0;j<p;j++) {
				m2.element[i][j]=m.element[i][j];
			}
		}
		return m2;
	}

	public Arithmetic[] sumValue() {
		return new Arithmetic[] {this};
	}

	public Arithmetic[] productValue() throws NotProductException {
		return new Arithmetic[] {this};
	}

	public Object[] powerValue() throws NotPowerException {
		return new Object[] {this,new Integer(1)};
	}

	public Expression expressionValue() throws NotExpressionException {
		throw new NotExpressionException();
	}

	public JSCLInteger integerValue() throws NotIntegerException {
		throw new NotIntegerException();
	}

	public Variable variableValue() throws NotVariableException {
		throw new NotVariableException();
	}

	public Variable[] variables() {
		return null;
	}

	public boolean isPolynomial(Variable variable) {
		return false;
	}

	public boolean isConstant(Variable variable) {
		return false;
	}

	public Arithmetic[] element() {
		JSCLVector v[]=new JSCLVector[n];
		for(int i=0;i<n;i++) {
			v[i]=new JSCLVector(new Arithmetic[p]);
			for(int j=0;j<p;j++) {
				v[i].element[j]=element[i][j];
			}
		}
		return v;
	}

	public Arithmetic tensorProduct(Matrix matrix) {
		Matrix m=(Matrix)newinstance(n*matrix.n,p*matrix.p);
		for(int i=0;i<n;i++) {
			for(int j=0;j<p;j++) {
				for(int k=0;k<matrix.n;k++) {
					for(int l=0;l<matrix.p;l++) {
						m.element[i*matrix.n+k][j*matrix.p+l]=element[i][j].multiply(matrix.element[k][l]);
					}
				}
			}
		}
		return m;
	}

	public Arithmetic transpose() {
		Matrix m=(Matrix)newinstance(p,n);
		for(int i=0;i<n;i++) {
			for(int j=0;j<p;j++) {
				m.element[j][i]=element[i][j];
			}
		}
		return m;
	}

	public Arithmetic trace() {
		Arithmetic s=JSCLInteger.valueOf(0);
		for(int i=0;i<n;i++) {
			s=s.add(element[i][i]);
		}
		return s;
	}

	public Arithmetic inverse() {
		Matrix m=new Matrix(new Arithmetic[n][n]);
		Arithmetic d=determinant();
		for(int i=0;i<n;i++) {
			for(int j=0;j<n;j++) {
				m.element[i][j]=new Frac(inverseElement(i,j),d).evaluate();
			}
		}
		return m.transpose();
	}

	Arithmetic inverseElement(int k, int l) {
		Matrix m=new Matrix(new Arithmetic[n][n]);
		for(int i=0;i<n;i++) {
			for(int j=0;j<n;j++) {
				m.element[i][j]=i==k?JSCLInteger.valueOf(j==l?1:0):element[i][j];
			}
		}
		return m.determinant();
	}

	public Arithmetic determinant() {
		if(n>1) {
			Arithmetic a=JSCLInteger.valueOf(0);
			for(int i=0;i<n;i++) {
				if(element[i][0].signum()==0);
				else {
					Matrix m=new Matrix(new Arithmetic[n-1][n-1]);
					for(int j=0;j<n-1;j++) {
						for(int k=0;k<n-1;k++) m.element[j][k]=element[j<i?j:j+1][k+1];
					}
					if(i%2==0) a=a.add(element[i][0].multiply(m.determinant()));
					else a=a.subtract(element[i][0].multiply(m.determinant()));
				}
			}
			return a;
		} else if(n>0) return element[0][0];
		else return JSCLInteger.valueOf(0);
	}

	public int compareTo(Object comparable) {
		return ArrayComparator.comparator.compare(element(),((Matrix)comparable).element());
	}

	public static Matrix identity(int dimension) {
		Matrix m=new Matrix(new Arithmetic[dimension][dimension]);
		for(int i=0;i<m.n;i++) {
			for(int j=0;j<m.p;j++) {
				if(i==j) {
					m.element[i][j]=JSCLInteger.valueOf(1);
				} else {
					m.element[i][j]=JSCLInteger.valueOf(0);
				}
			}
		}
		return m;
	}

	public static Matrix frame(JSCLVector vector[]) {
		Matrix m=new Matrix(new Arithmetic[vector.length>0?vector[0].n:0][vector.length]);
		for(int i=0;i<m.n;i++) {
			for(int j=0;j<m.p;j++) {
				m.element[i][j]=vector[j].element[i];
			}
		}
		return m;
	}

	public static Matrix rotation(int dimension, int plane, Arithmetic angle) {
		return rotation(dimension,plane,2,angle);
	}

	public static Matrix rotation(int dimension, int axis1, int axis2, Arithmetic angle) {
		Matrix m=new Matrix(new Arithmetic[dimension][dimension]);
		for(int i=0;i<m.n;i++) {
			for(int j=0;j<m.p;j++) {
				if(i==axis1 && j==axis1) {
					m.element[i][j]=new Cos(angle).evaluate();
				} else if(i==axis1 && j==axis2) {
					m.element[i][j]=new Sin(angle).evaluate().negate();
				} else if(i==axis2 && j==axis1) {
					m.element[i][j]=new Sin(angle).evaluate();
				} else if(i==axis2 && j==axis2) {
					m.element[i][j]=new Cos(angle).evaluate();
				} else if(i==j) {
					m.element[i][j]=JSCLInteger.valueOf(1);
				} else {
					m.element[i][j]=JSCLInteger.valueOf(0);
				}
			}
		}
		return m;
	}

	public String toString() {
		StringBuffer buffer=new StringBuffer();
		buffer.append("{");
		for(int i=0;i<n;i++) {
			JSCLVector v=new JSCLVector(element[i]);
			buffer.append(v).append(i<n-1?",\n":"");
		}
		buffer.append("}");
		return buffer.toString();
	}

	public String toMathML(Object data) {
		IndentedBuffer buffer=new IndentedBuffer();
		int exponent=data instanceof Integer?((Integer)data).intValue():1;
		if(exponent==1) {
			buffer.append(bodyToMathML());
		} else {
			buffer.append("<msup>\n");
			buffer.append(1,bodyToMathML());
			buffer.append(1,"<mn>").append(exponent).append("</mn>\n");
			buffer.append("</msup>\n");
		}
		return buffer.toString();
	}

	String bodyToMathML() {
		IndentedBuffer buffer=new IndentedBuffer();
		buffer.append("<mrow>\n");
		buffer.append(1,"<mo>(</mo>\n");
		buffer.append(1,"<mtable>\n");
		for(int i=0;i<n;i++) {
			buffer.append(2,"<mtr>\n");
			for(int j=0;j<p;j++) {
				buffer.append(3,"<mtd>\n");
				buffer.append(4,element[i][j].toMathML(null));
				buffer.append(3,"</mtd>\n");
			}
			buffer.append(2,"</mtr>\n");
		}
		buffer.append(1,"</mtable>\n");
		buffer.append(1,"<mo>)</mo>\n");
		buffer.append("</mrow>\n");
		return buffer.toString();
	}

	protected Arithmetic newinstance() {
		return newinstance(n,p);
	}

	protected Arithmetic newinstance(int n, int p) {
		return new Matrix(new Arithmetic[n][p]);
	}
}

class MatrixParser extends Parser {
	public static final Parser parser=new MatrixParser();

	private MatrixParser() {}

	public Object parse(String str, int pos[]) throws ParseException {
		int pos0=pos[0];
		Vector vector=new Vector();
		skipWhitespaces(str,pos);
		if(pos[0]<str.length() && str.charAt(pos[0])=='{') {
			str.charAt(pos[0]++);
		} else {
			pos[0]=pos0;
			throw new ParseException();
		}
		try {
			JSCLVector v=(JSCLVector)JSCLVector.parser.parse(str,pos);
			vector.addElement(v);
		} catch (ParseException e) {
			pos[0]=pos0;
			throw e;
		}
		while(true) {
			try {
				JSCLVector v=(JSCLVector)JSCLVector.commaAndVector.parse(str,pos);
				vector.addElement(v);
			} catch (ParseException e) {
				break;
			}
		}
		skipWhitespaces(str,pos);
		if(pos[0]<str.length() && str.charAt(pos[0])=='}') {
			str.charAt(pos[0]++);
		} else {
			pos[0]=pos0;
			throw new ParseException();
		}
		JSCLVector v[]=new JSCLVector[vector.size()];
		vector.copyInto(v);
		return Matrix.frame(v).transpose();
	}
}
