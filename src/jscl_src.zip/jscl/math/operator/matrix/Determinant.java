package jscl.math.operator.matrix;

import jscl.math.*;
import jscl.math.operator.*;
import jscl.text.*;

public class Determinant extends Operator {
	public Determinant(Arithmetic matrix) {
		super("det",new Arithmetic[] {matrix});
	}

	public Arithmetic compute() {
		if(parameter[0] instanceof Matrix) {
			Matrix matrix=(Matrix)parameter[0];
			return matrix.determinant();
		}
		return expressionValue();
	}

	public String toMathML(Object data) {
		IndentedBuffer buffer=new IndentedBuffer();
		int exponent=data instanceof Integer?((Integer)data).intValue():1;
		if(exponent==1) {
			buffer.append(bodyToMathML());
		} else {
			buffer.append("<msup>\n");
			buffer.append(1,bodyToMathML());
			buffer.append(1,"<mn>").append(exponent).append("</mn>\n");
			buffer.append("</msup>\n");
		}
		return buffer.toString();
	}

	String bodyToMathML() {
		IndentedBuffer buffer=new IndentedBuffer();
		Arithmetic m=ArithmeticVariable.content(parameter[0]);
		buffer.append("<mfenced open=\"|\" close=\"|\">\n");
		if(m instanceof Matrix) {
			Arithmetic element[][]=((Matrix)m).elements();
			buffer.append(1,"<mtable>\n");
			for(int i=0;i<element.length;i++) {
				buffer.append(2,"<mtr>\n");
				for(int j=0;j<element.length;j++) {
					buffer.append(3,"<mtd>\n");
					buffer.append(4,element[i][j].toMathML(null));
					buffer.append(3,"</mtd>\n");
				}
				buffer.append(2,"</mtr>\n");
			}
			buffer.append(1,"</mtable>\n");
		} else buffer.append(1,m.toMathML(null));
		buffer.append("</mfenced>\n");
		return buffer.toString();
	}

	protected Variable newinstance() {
		return new Determinant(null);
	}
}
