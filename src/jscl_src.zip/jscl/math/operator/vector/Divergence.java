package jscl.math.operator.vector;

import jscl.math.*;
import jscl.math.operator.*;
import jscl.text.*;

public class Divergence extends VectorOperator {
	public Divergence(Arithmetic vector, Arithmetic variable) {
		super("diverg",new Arithmetic[] {vector,variable});
	}

	public Arithmetic compute() {
		Variable variable[]=variables(parameter[1]);
		JSCLVector vector=(JSCLVector)parameter[0];
		return vector.divergence(variable);
	}

	protected String bodyToMathML() {
		IndentedBuffer buffer=new IndentedBuffer();
		buffer.append(operator("nabla"));
		buffer.append(parameter[0].toMathML(null));
		return buffer.toString();
	}

	protected Variable newinstance() {
		return new Divergence(null,null);
	}
}
