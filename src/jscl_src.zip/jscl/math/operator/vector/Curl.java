package jscl.math.operator.vector;

import jscl.math.*;
import jscl.math.operator.*;
import jscl.text.*;

public class Curl extends VectorOperator {
	public Curl(Arithmetic vector, Arithmetic variable) {
		super("curl",new Arithmetic[] {vector,variable});
	}

	public Arithmetic compute() {
		Variable variable[]=variables(parameter[1]);
		JSCLVector vector=(JSCLVector)parameter[0];
		return vector.curl(variable);
	}

	protected String bodyToMathML() {
		IndentedBuffer buffer=new IndentedBuffer();
		buffer.append(operator("nabla"));
		buffer.append("<mo>&wedge;</mo>\n");
		buffer.append(parameter[0].toMathML(null));
		return buffer.toString();
	}

	protected Variable newinstance() {
		return new Curl(null,null);
	}
}
