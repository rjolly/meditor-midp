package jscl.math.operator;

import jscl.math.*;

public class Coefficient extends Operator {
	public Coefficient(Arithmetic expression, Arithmetic variable) {
		super("coef",new Arithmetic[] {expression,variable});
	}

	public Arithmetic compute() {
		Variable variable=parameter[1].variableValue();
		UnivariatePolynomial polynomial=UnivariatePolynomial.valueOf(parameter[0],variable);
		return new JSCLVector(polynomial.element());
	}

	protected Variable newinstance() {
		return new Coefficient(null,null);
	}
}
