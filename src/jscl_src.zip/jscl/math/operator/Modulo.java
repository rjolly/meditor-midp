package jscl.math.operator;

import jscl.math.*;

public class Modulo extends Operator {
	public Modulo(Arithmetic expression1, Arithmetic expression2) {
		super("mod",new Arithmetic[] {expression1,expression2});
	}

	public Arithmetic compute() {
		return parameter[0].mod(parameter[1]);
	}

	protected Variable newinstance() {
		return new Modulo(null,null);
	}
}
