package jscl.math.operator;

import jscl.math.*;

public class Modulo extends Operator {
	public Modulo(Generic expression1, Generic expression2) {
		super("mod",new Generic[] {expression1,expression2});
	}

	public Generic compute() {
		return parameter[0].mod(parameter[1]);
	}

	protected Variable newinstance() {
		return new Modulo(null,null);
	}
}
