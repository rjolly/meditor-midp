package jscl.math.operator;

import jscl.math.*;

public class Product extends Operator {
	public Product(Arithmetic expression, Arithmetic variable, Arithmetic n1, Arithmetic n2) {
		super("prod",new Arithmetic[] {expression,variable,n1,n2});
	}

	public Arithmetic compute() {
		Variable variable=parameter[1].variableValue();
		try {
			int n1=parameter[2].integerValue().intValue();
			int n2=parameter[3].integerValue().intValue();
			Arithmetic a=JSCLInteger.valueOf(1);
			for(int i=n1;i<=n2;i++) {
				a=a.multiply(parameter[0].substitute(variable,JSCLInteger.valueOf(i)));
			}
			return a;
		} catch (NotIntegerException e) {}
		return expressionValue();
	}

	public String toMathML(Object data) {
		IndentedBuffer buffer=new IndentedBuffer();
		int exponent=data instanceof Integer?((Integer)data).intValue():1;
		if(exponent==1) {
			buffer.append(bodyToMathML());
		} else {
			buffer.append("<msup>\n");
			buffer.append(1,"<mrow>\n");
			buffer.append(2,"<mo>(</mo>\n");
			buffer.append(2,bodyToMathML());
			buffer.append(2,"<mo>)</mo>\n");
			buffer.append(1,"</mrow>\n");
			buffer.append(1,"<mn>").append(exponent).append("</mn>\n");
			buffer.append("</msup>\n");
		}
		return buffer.toString();
	}

	String bodyToMathML() {
		IndentedBuffer buffer=new IndentedBuffer();
		buffer.append("<mrow>\n");
		buffer.append(1,"<munderover>\n");
		buffer.append(2,"<mo>&prod;</mo>\n");
		buffer.append(2,"<mrow>\n");
		buffer.append(3,parameter[1].toMathML(null));
		buffer.append(3,"<mo>=</mo>\n");
		buffer.append(3,parameter[2].toMathML(null));
		buffer.append(2,"</mrow>\n");
		buffer.append(2,parameter[3].toMathML(null));
		buffer.append(1,"</munderover>\n");
		buffer.append(1,parameter[0].toMathML(null));
		buffer.append("</mrow>\n");
		return buffer.toString();
	}

	protected Variable newinstance() {
		return new Product(null,null,null,null);
	}
}
