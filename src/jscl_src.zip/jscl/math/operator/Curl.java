package jscl.math.operator;

import jscl.math.*;

public class Curl extends Operator {
	public Curl(Arithmetic vector, Arithmetic variable) {
		super("curl",new Arithmetic[] {vector,variable});
	}

	public Arithmetic compute() {
		Variable variable[]=Variable.valueOf(((JSCLVector)parameter[1]).element);
		JSCLVector vector=(JSCLVector)parameter[0];
		return vector.curl(variable);
	}

	protected Variable newinstance() {
		return new Curl(null,null);
	}
}
