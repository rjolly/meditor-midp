package jscl.math.operator;

import jscl.math.*;
import jscl.math.function.*;

public class Integral extends Operator {
	public Integral(Arithmetic expression, Arithmetic variable, Arithmetic n1, Arithmetic n2) {
		super("integral",new Arithmetic[] {expression,variable,n1,n2});
	}

	public Arithmetic compute() {
		Variable variable=parameter[1].variableValue();
		try {
			Arithmetic a=parameter[0].antiderivative(variable);
			return a.substitute(variable,parameter[3]).subtract(a.substitute(variable,parameter[2]));
		} catch (NotIntegrableException e) {
			try {
				Variable v=parameter[0].variableValue();
				if(v instanceof Frac) {
					Function f=(Function)v;
					if(f.parameter[1].isConstant(variable)) {
						return new Inv(f.parameter[1]).evaluate().multiply(new Integral(f.parameter[0],parameter[1],parameter[2],parameter[3]).compute());
					}
				}
			} catch (NotVariableException e2) {
				Arithmetic a[]=parameter[0].sumValue();
				if(a.length>1) {
					Arithmetic s=JSCLInteger.valueOf(0);
					for(int i=0;i<a.length;i++) {
						s=s.add(new Integral(a[i],parameter[1],parameter[2],parameter[3]).compute());
					}
					return s;
				} else {
					Arithmetic p[]=a[0].productValue();
					Arithmetic s=JSCLInteger.valueOf(1);
					Arithmetic t=JSCLInteger.valueOf(1);
					for(int i=0;i<p.length;i++) {
						if(p[i].isConstant(variable)) s=s.multiply(p[i]);
						else t=t.multiply(p[i]);
					}
					if(s.compareTo(JSCLInteger.valueOf(1))==0);
					else return s.multiply(new Integral(t,parameter[1],parameter[2],parameter[3]).compute());
				}
			}
		}
		return expressionValue();
	}

	public String toMathML(Object data) {
		IndentedBuffer buffer=new IndentedBuffer();
		int exponent=data instanceof Integer?((Integer)data).intValue():1;
		if(exponent==1) {
			buffer.append(bodyToMathML());
		} else {
			buffer.append("<msup>\n");
			buffer.append(1,"<mrow>\n");
			buffer.append(2,"<mo>(</mo>\n");
			buffer.append(2,bodyToMathML());
			buffer.append(2,"<mo>)</mo>\n");
			buffer.append(1,"</mrow>\n");
			buffer.append(1,"<mn>").append(exponent).append("</mn>\n");
			buffer.append("</msup>\n");
		}
		return buffer.toString();
	}

	String bodyToMathML() {
		IndentedBuffer buffer=new IndentedBuffer();
		Variable v=parameter[1].variableValue();
		buffer.append("<mrow>\n");
		buffer.append(1,"<msubsup>\n");
		buffer.append(2,"<mo>&int;</mo>\n");
		buffer.append(2,parameter[2].toMathML(null));
		buffer.append(2,parameter[3].toMathML(null));
		buffer.append(1,"</msubsup>\n");
		buffer.append(1,parameter[0].toMathML(null));
		buffer.append(1,"<mo>d</mo>\n");
		buffer.append(1,v.toMathML(null));
		buffer.append("</mrow>\n");
		return buffer.toString();
	}

	protected Variable newinstance() {
		return new Integral(null,null,null,null);
	}
}
