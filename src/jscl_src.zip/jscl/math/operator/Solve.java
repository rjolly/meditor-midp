package jscl.math.operator;

import jscl.math.*;
import jscl.math.function.*;

public class Solve extends Operator {
	public Solve(Arithmetic expression, Arithmetic variable, Arithmetic subscript) {
		super("solve",new Arithmetic[] {expression,variable,subscript});
	}

	public Arithmetic compute() {
		Variable variable=parameter[1].variableValue();
		UnivariatePolynomial polynomial=UnivariatePolynomial.valueOf(parameter[0],variable);
		int subscript=parameter[2].integerValue().intValue();
		return new Root(polynomial,subscript).evaluate();
	}

	protected Variable newinstance() {
		return new Solve(null,null,null);
	}
}
