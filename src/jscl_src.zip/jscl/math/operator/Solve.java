package jscl.math.operator;

import jscl.math.*;
import jscl.math.function.*;

public class Solve extends Operator {
	public Solve(Arithmetic expression, Arithmetic variable, Arithmetic subscript) {
		super("solve",new Arithmetic[] {expression,variable,subscript});
	}

	public Arithmetic compute() {
		Variable variable=parameter[1].variableValue();
		int subscript=parameter[2].integerValue().intValue();
		if(parameter[0].isPolynomial(variable)) {
			return new Root(UnivariatePolynomial.valueOf(parameter[0],variable),subscript).evaluate();
		}
		return expressionValue();
	}

	protected Variable newinstance() {
		return new Solve(null,null,null);
	}
}
