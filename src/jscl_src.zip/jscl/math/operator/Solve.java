package jscl.math.operator;

import jscl.math.*;
import jscl.math.function.*;

public class Solve extends Operator {
	public Solve(Generic expression, Generic variable, Generic subscript) {
		super("solve",new Generic[] {expression,variable,subscript});
	}

	public Generic compute() {
		Variable variable=parameter[1].variableValue();
		int subscript=parameter[2].integerValue().intValue();
		if(parameter[0].isPolynomial(variable)) {
			return new Root(UnivariatePolynomial.valueOf(parameter[0],variable),subscript).evaluate();
		}
		return expressionValue();
	}

	protected Variable newinstance() {
		return new Solve(null,null,null);
	}
}
