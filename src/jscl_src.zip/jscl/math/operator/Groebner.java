package jscl.math.operator;

import java.util.*;
import jscl.math.*;

public class Groebner extends Operator {
	public Groebner(Arithmetic arithmetic, Arithmetic variable, Arithmetic ordering, Arithmetic modulo) {
		super("groebner",new Arithmetic[] {arithmetic,variable,ordering,modulo});
	}

	public Arithmetic compute() {
		Arithmetic arithmetic[]=((JSCLVector)parameter[0]).element;
		Variable variable[]=Variable.valueOf(((JSCLVector)parameter[1]).element);
		int n=parameter[2].integerValue().intValue();
		int m=parameter[3].integerValue().intValue();
		Basis basis=new Basis(arithmetic,variable,ord[n],m);
		basis.compute();
		Arithmetic a[]=new Arithmetic[basis.size()];
		for(int i=0;i<a.length;i++) a[i]=Polynomial.valueOf(basis.get(i),variable,ord[n],m);
		return new Groebner(new JSCLVector(a.length>0?a:new Arithmetic[] {Polynomial.valueOf(JSCLInteger.valueOf(0),variable,ord[n],m)}),parameter[1],parameter[2],parameter[3]).expressionValue();
	}

	Operator transmute() {
		Arithmetic arithmetic[]=((JSCLVector)parameter[0].expand()).element;
		Variable variable[]=Variable.valueOf(((JSCLVector)parameter[1].expand()).element);
		int n=parameter[2].integerValue().intValue();
		int m=parameter[3].integerValue().intValue();
		Arithmetic a[]=new Arithmetic[arithmetic.length];
		for(int i=0;i<a.length;i++) a[i]=Polynomial.valueOf(arithmetic[i],variable,ord[n],m);
		return new Groebner(new JSCLVector(a),parameter[1],parameter[2],parameter[3]);
	}

	public String toString() {
		StringBuffer buffer=new StringBuffer();
		int n=4;
		if(parameter[3].signum()==0) {
			n=3;
			if(parameter[2].signum()==0) n=2;
		}
		buffer.append(name);
		buffer.append("(");
		for(int i=0;i<n;i++) {
			buffer.append(parameter[i]).append(i<n-1?", ":"");
		}
		buffer.append(")");
		return buffer.toString();
	}

	public String toMathML(Object data) {
		IndentedBuffer buffer=new IndentedBuffer();
		int exponent=data instanceof Integer?((Integer)data).intValue():1;
		int n=4;
		if(parameter[3].signum()==0) {
			n=3;
			if(parameter[2].signum()==0) n=2;
		}
		if(exponent==1) {
			buffer.append(nameToMathML());
		} else {
			buffer.append("<msup>\n");
			buffer.append(1,nameToMathML());
			buffer.append(1,"<mn>").append(exponent).append("</mn>\n");
			buffer.append("</msup>\n");
		}
		buffer.append("<mo stretchy=\"false\">(</mo>\n");
		for(int i=0;i<n;i++) {
			buffer.append(parameter[i].toMathML(null));
			if(i<n-1) buffer.append("<mo>,</mo>\n");
		}
		buffer.append("<mo stretchy=\"false\">)</mo>\n");
		return buffer.toString();
	}

	protected Variable newinstance() {
		return new Groebner(null,null,null,null);
	}

	private static final Comparator ord[]={Monomial.lexicographic,Monomial.totalDegreeLexicographic,Monomial.degreeReverseLexicographic};
}
