package jscl.math.operator;

import java.util.*;
import jscl.math.*;
import jscl.math.function.*;
import jscl.text.*;

public class Groebner extends Operator {
	public Groebner(Arithmetic arithmetic, Arithmetic variable, Arithmetic ordering, Arithmetic modulo) {
		super("groebner",new Arithmetic[] {arithmetic,variable,ordering,modulo});
	}

	public Arithmetic compute() {
		Arithmetic arithmetic[]=((JSCLVector)parameter[0]).element;
		Variable variable[]=Variable.valueOf(((JSCLVector)parameter[1]).element);
		Comparator ord=ordering(parameter[2]);
		int m=parameter[3].integerValue().intValue();
		Basis basis=new Basis(arithmetic,variable,ord,m);
		basis.compute();
		Arithmetic a[]=new Arithmetic[basis.size()];
		for(int i=0;i<a.length;i++) a[i]=Polynomial.valueOf(basis.get(i),variable,ord,m);
		return new Groebner(new JSCLVector(a.length>0?a:new Arithmetic[] {Polynomial.valueOf(JSCLInteger.valueOf(0),variable,ord,m)}),parameter[1],parameter[2],parameter[3]).expressionValue();
	}

	static Comparator ordering(Arithmetic arithmetic) {
		Variable v=arithmetic.variableValue();
		if(v.name.compareTo("lex")==0) return Monomial.lexicographic;
		else if(v.name.compareTo("tdl")==0) return Monomial.totalDegreeLexicographic;
		else if(v.name.compareTo("drl")==0) return Monomial.degreeReverseLexicographic;
		else if(v instanceof Function && v.name.compareTo("elim")==0) {
			Function f=(Function)v;
			int k=f.parameter[0].integerValue().intValue();
			return Monomial.kthElimination(k);
		} else return null;
		
	}

	Operator transmute() {
		Arithmetic arithmetic[]=((JSCLVector)parameter[0].expand()).element;
		Variable variable[]=Variable.valueOf(((JSCLVector)parameter[1].expand()).element);
		Comparator ord=ordering(parameter[2]);
		int m=parameter[3].integerValue().intValue();
		Arithmetic a[]=new Arithmetic[arithmetic.length];
		for(int i=0;i<a.length;i++) a[i]=Polynomial.valueOf(arithmetic[i],variable,ord,m);
		return new Groebner(new JSCLVector(a),parameter[1],parameter[2],parameter[3]);
	}

	public String toString() {
		StringBuffer buffer=new StringBuffer();
		int n=4;
		if(parameter[3].signum()==0) {
			n=3;
			if(ordering(parameter[2])==Monomial.lexicographic) n=2;
		}
		buffer.append(name);
		buffer.append("(");
		for(int i=0;i<n;i++) {
			buffer.append(parameter[i]).append(i<n-1?", ":"");
		}
		buffer.append(")");
		return buffer.toString();
	}

	public String toMathML(Object data) {
		IndentedBuffer buffer=new IndentedBuffer();
		int exponent=data instanceof Integer?((Integer)data).intValue():1;
		int n=4;
		if(parameter[3].signum()==0) {
			n=3;
			if(ordering(parameter[2])==Monomial.lexicographic) n=2;
		}
		if(exponent==1) {
			buffer.append(nameToMathML());
		} else {
			buffer.append("<msup>\n");
			buffer.append(1,nameToMathML());
			buffer.append(1,"<mn>").append(exponent).append("</mn>\n");
			buffer.append("</msup>\n");
		}
		buffer.append("<mo stretchy=\"false\">(</mo>\n");
		for(int i=0;i<n;i++) {
			buffer.append(parameter[i].toMathML(null));
			if(i<n-1) buffer.append("<mo>,</mo>\n");
		}
		buffer.append("<mo stretchy=\"false\">)</mo>\n");
		return buffer.toString();
	}

	protected Variable newinstance() {
		return new Groebner(null,null,null,null);
	}
}
