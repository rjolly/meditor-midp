package jscl.math.operator;

import java.util.*;
import jscl.math.*;
import jscl.math.function.*;
import jscl.text.*;

public class Groebner extends Operator {
	public Groebner(Arithmetic arithmetic, Arithmetic variable, Arithmetic ordering, Arithmetic modulo) {
		super("groebner",new Arithmetic[] {arithmetic,variable,ordering,modulo});
	}

	public Arithmetic compute() {
		Arithmetic arithmetic[]=((PolynomialVector)parameter[0]).elements();
		Variable variable[]=variables(parameter[1]);
		Comparator ord=ordering(parameter[2]);
		int m=parameter[3].integerValue().intValue();
		Basis basis=new Basis(arithmetic,variable,ord,m);
		basis.compute();
		Polynomial b[]=basis.elements();
		Arithmetic a[]=new Arithmetic[b.length];
		for(int i=0;i<a.length;i++) a[i]=b[i].arithmeticValue();
		return new PolynomialVector(a.length>0?a:new Arithmetic[] {JSCLInteger.valueOf(0)},variable,ord,m);
	}

	Operator transmute() {
		Arithmetic arithmetic[]=((JSCLVector)parameter[0].expand()).elements();
		Variable variable[]=variables(parameter[1].expand());
		Comparator ord=ordering(parameter[2]);
		int m=parameter[3].integerValue().intValue();
		return new Groebner(
			new PolynomialVector(arithmetic,variable,ord,m),
			parameter[1],
			parameter[2],
			parameter[3]
		);
	}

	static Comparator ordering(Arithmetic arithmetic) {
		Variable v=arithmetic.variableValue();
		if(v.compareTo(new Constant("lex"))==0) return Monomial.lexicographic;
		else if(v.compareTo(new Constant("tdl"))==0) return Monomial.totalDegreeLexicographic;
		else if(v.compareTo(new Constant("drl"))==0) return Monomial.degreeReverseLexicographic;
		else if(v instanceof ImplicitFunction) {
			int k=((ImplicitFunction)v).parameter[0].integerValue().intValue();
			if(v.compareTo(new ImplicitFunction("elim",new Arithmetic[] {JSCLInteger.valueOf(k)},new int[] {0}))==0) return Monomial.kthElimination(k);
		}
		throw new ArithmeticException();
		
	}

	public String toString() {
		StringBuffer buffer=new StringBuffer();
		int n=4;
		if(parameter[3].signum()==0) {
			n=3;
			if(ordering(parameter[2])==Monomial.lexicographic) n=2;
		}
		buffer.append(name);
		buffer.append("(");
		for(int i=0;i<n;i++) {
			buffer.append(parameter[i]).append(i<n-1?", ":"");
		}
		buffer.append(")");
		return buffer.toString();
	}

	public String toMathML(Object data) {
		IndentedBuffer buffer=new IndentedBuffer();
		int exponent=data instanceof Integer?((Integer)data).intValue():1;
		int n=4;
		if(parameter[3].signum()==0) {
			n=3;
			if(ordering(parameter[2])==Monomial.lexicographic) n=2;
		}
		if(exponent==1) {
			buffer.append(nameToMathML());
		} else {
			buffer.append("<msup>\n");
			buffer.append(1,nameToMathML());
			buffer.append(1,"<mn>").append(exponent).append("</mn>\n");
			buffer.append("</msup>\n");
		}
		buffer.append("<mfenced>\n");
		for(int i=0;i<n;i++) {
			buffer.append(1,parameter[i].toMathML(null));
		}
		buffer.append("</mfenced>\n");
		return buffer.toString();
	}

	protected Variable newinstance() {
		return new Groebner(null,null,null,null);
	}
}

class PolynomialVector extends JSCLVector {
	final Basis basis;

	PolynomialVector(Arithmetic arithmetic[], Variable unknown[], Comparator ordering, int modulo) {
		this(arithmetic,new Basis(new Arithmetic[0],unknown,ordering,modulo));
	}

	PolynomialVector(Arithmetic arithmetic[], Basis basis) {
		super(arithmetic);
		this.basis=basis;
	}

	public String toString() {
		StringBuffer buffer=new StringBuffer();
		Arithmetic v[]=elements();
		buffer.append("{");
		for(int i=0;i<v.length;i++) {
			buffer.append(basis.polynomial(v[i])).append(i<v.length-1?", ":"");
		}
		buffer.append("}");
		return buffer.toString();
	}

	protected String bodyToMathML() {
		IndentedBuffer buffer=new IndentedBuffer();
		Arithmetic v[]=elements();
		buffer.append("<mfenced>\n");
		buffer.append(1,"<mtable>\n");
		for(int i=0;i<v.length;i++) {
			buffer.append(2,"<mtr>\n");
			buffer.append(3,"<mtd>\n");
			buffer.append(4,basis.polynomial(v[i]).toMathML(null));
			buffer.append(3,"</mtd>\n");
			buffer.append(2,"</mtr>\n");
		}
		buffer.append(1,"</mtable>\n");
		buffer.append("</mfenced>\n");
		return buffer.toString();
	}

	protected Arithmetic newinstance(int n) {
		return new PolynomialVector(new Arithmetic[n],basis);
	}
}
