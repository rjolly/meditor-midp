package jscl.math.operator;

import java.util.*;
import jscl.math.*;
import jscl.math.function.*;
import jscl.text.*;

public class Groebner extends Operator {
	public Groebner(Arithmetic arithmetic, Arithmetic variable, Arithmetic ordering, Arithmetic modulo) {
		super("groebner",new Arithmetic[] {arithmetic,variable,ordering,modulo});
	}

	public Arithmetic compute() {
		Arithmetic arithmetic[]=((PolynomialVector)parameter[0]).element;
		Variable variable[]=Variable.valueOf(((JSCLVector)parameter[1]).element);
		Comparator ord=ordering(parameter[2]);
		int m=parameter[3].integerValue().intValue();
		Basis basis=new Basis(arithmetic,variable,ord,m);
		basis.compute();
		Arithmetic a[]=new Arithmetic[basis.size()];
		for(int i=0;i<a.length;i++) a[i]=basis.get(i).arithmeticValue();
		return new Groebner(
			new PolynomialVector(a.length>0?a:new Arithmetic[] {JSCLInteger.valueOf(0)},variable,ord,m),
			parameter[1],
			parameter[2],
			parameter[3]
		).expressionValue();
	}

	Operator transmute() {
		Arithmetic arithmetic[]=((JSCLVector)parameter[0].expand()).element;
		Variable variable[]=Variable.valueOf(((JSCLVector)parameter[1].expand()).element);
		Comparator ord=ordering(parameter[2]);
		int m=parameter[3].integerValue().intValue();
		return new Groebner(
			new PolynomialVector(arithmetic,variable,ord,m),
			parameter[1],
			parameter[2],
			parameter[3]
		);
	}

	static Comparator ordering(Arithmetic arithmetic) {
		Variable v=arithmetic.variableValue();
		if(v.name.compareTo("lex")==0) return Monomial.lexicographic;
		else if(v.name.compareTo("tdl")==0) return Monomial.totalDegreeLexicographic;
		else if(v.name.compareTo("drl")==0) return Monomial.degreeReverseLexicographic;
		else if(v instanceof Function && v.name.compareTo("elim")==0) {
			Function f=(Function)v;
			int k=f.parameter[0].integerValue().intValue();
			return Monomial.kthElimination(k);
		} else return null;
		
	}

	public String toString() {
		StringBuffer buffer=new StringBuffer();
		int n=4;
		if(parameter[3].signum()==0) {
			n=3;
			if(ordering(parameter[2])==Monomial.lexicographic) n=2;
		}
		buffer.append(name);
		buffer.append("(");
		for(int i=0;i<n;i++) {
			buffer.append(parameter[i]).append(i<n-1?", ":"");
		}
		buffer.append(")");
		return buffer.toString();
	}

	public String toMathML(Object data) {
		IndentedBuffer buffer=new IndentedBuffer();
		int exponent=data instanceof Integer?((Integer)data).intValue():1;
		int n=4;
		if(parameter[3].signum()==0) {
			n=3;
			if(ordering(parameter[2])==Monomial.lexicographic) n=2;
		}
		if(exponent==1) {
			buffer.append(nameToMathML());
		} else {
			buffer.append("<msup>\n");
			buffer.append(1,nameToMathML());
			buffer.append(1,"<mn>").append(exponent).append("</mn>\n");
			buffer.append("</msup>\n");
		}
		buffer.append("<mo stretchy=\"false\">(</mo>\n");
		for(int i=0;i<n;i++) {
			buffer.append(parameter[i].toMathML(null));
			if(i<n-1) buffer.append("<mo>,</mo>\n");
		}
		buffer.append("<mo stretchy=\"false\">)</mo>\n");
		return buffer.toString();
	}

	protected Variable newinstance() {
		return new Groebner(null,null,null,null);
	}
}

class PolynomialVector extends JSCLVector {
	final Basis basis;

	PolynomialVector(Arithmetic arithmetic[], Variable unknown[], Comparator ordering, int modulo) {
		this(arithmetic,new Basis(new Arithmetic[0],unknown,ordering,modulo));
	}

	PolynomialVector(Arithmetic arithmetic[], Basis basis) {
		super(arithmetic);
		this.basis=basis;
	}

	public String toString() {
		StringBuffer buffer=new StringBuffer();
		buffer.append("{");
		for(int i=0;i<n;i++) {
			buffer.append(basis.polynomial(element[i])).append(i<n-1?", ":"");
		}
		buffer.append("}");
		return buffer.toString();
	}

	protected String bodyToMathML() {
		IndentedBuffer buffer=new IndentedBuffer();
		buffer.append("<mrow>\n");
		buffer.append(1,"<mo>(</mo>\n");
		buffer.append(1,"<mtable>\n");
		for(int i=0;i<n;i++) {
			buffer.append(2,"<mtr>\n");
			buffer.append(3,"<mtd>\n");
			buffer.append(4,basis.polynomial(element[i]).toMathML(null));
			buffer.append(3,"</mtd>\n");
			buffer.append(2,"</mtr>\n");
		}
		buffer.append(1,"</mtable>\n");
		buffer.append(1,"<mo>)</mo>\n");
		buffer.append("</mrow>\n");
		return buffer.toString();
	}

	protected Arithmetic newinstance(int n) {
		return new PolynomialVector(new Arithmetic[n],basis);
	}
}
