package jscl.math.operator;

import jscl.math.*;

public class Substitute extends Operator {
	public Substitute(Arithmetic expression, Arithmetic variable, Arithmetic value) {
		super("subst",new Arithmetic[] {expression,variable,value});
	}

	public Arithmetic compute() {
		Variable variable=parameter[1].variableValue();
		return parameter[0].substitute(variable,parameter[2]);
	}

	protected Variable newinstance() {
		return new Substitute(null,null,null);
	}
}
