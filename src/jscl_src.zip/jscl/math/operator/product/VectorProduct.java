package jscl.math.operator.product;

import jscl.math.*;
import jscl.math.operator.*;
import jscl.text.*;

public class VectorProduct extends VectorOperator {
	public VectorProduct(Arithmetic vector1, Arithmetic vector2) {
		super("vector",new Arithmetic[] {vector1,vector2});
	}

	public Arithmetic compute() {
		if(parameter[0] instanceof JSCLVector && parameter[1] instanceof JSCLVector) {
			JSCLVector v1=(JSCLVector)parameter[0];
			JSCLVector v2=(JSCLVector)parameter[1];
			return v1.vectorProduct(v2);
		}
		return expressionValue();
	}

	protected String bodyToMathML() {
		IndentedBuffer buffer=new IndentedBuffer();
		buffer.append(parameter[0].toMathML(null));
		buffer.append("<mo>&wedge;</mo>\n");
		buffer.append(parameter[1].toMathML(null));
		return buffer.toString();
	}

	protected Variable newinstance() {
		return new VectorProduct(null,null);
	}
}
