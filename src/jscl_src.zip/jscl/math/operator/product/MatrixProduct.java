package jscl.math.operator.product;

import jscl.math.*;
import jscl.math.operator.*;
import jscl.text.*;

public class MatrixProduct extends VectorOperator {
	public MatrixProduct(Arithmetic matrix1, Arithmetic matrix2) {
		super("matrix",new Arithmetic[] {matrix1,matrix2});
	}

	public Arithmetic compute() {
		return parameter[0].multiply(parameter[1]);
	}

	protected String bodyToMathML() {
		IndentedBuffer buffer=new IndentedBuffer();
		buffer.append(parameter[0].toMathML(null));
		buffer.append(parameter[1].toMathML(null));
		return buffer.toString();
	}

	protected Variable newinstance() {
		return new MatrixProduct(null,null);
	}
}
