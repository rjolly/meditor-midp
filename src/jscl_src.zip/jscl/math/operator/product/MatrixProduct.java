package jscl.math.operator.product;

import jscl.math.*;
import jscl.math.operator.*;
import jscl.text.*;

public class MatrixProduct extends VectorOperator {
	public MatrixProduct(Arithmetic matrix1, Arithmetic matrix2) {
		super("matrix",new Arithmetic[] {matrix1,matrix2});
	}

	public Arithmetic compute() {
		if((parameter[0] instanceof Matrix && parameter[1] instanceof Matrix) || (parameter[0] instanceof Matrix && parameter[1] instanceof JSCLVector) || (parameter[0] instanceof JSCLVector && parameter[1] instanceof Matrix)) {
			return parameter[0].multiply(parameter[1]);
		}
		return expressionValue();
	}

	protected String bodyToMathML() {
		IndentedBuffer buffer=new IndentedBuffer();
		buffer.append(parameter[0].toMathML(null));
		buffer.append(parameter[1].toMathML(null));
		return buffer.toString();
	}

	protected Variable newinstance() {
		return new MatrixProduct(null,null);
	}
}
