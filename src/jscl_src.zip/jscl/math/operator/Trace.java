package jscl.math.operator;

import jscl.math.*;

public class Trace extends Operator {
	public Trace(Arithmetic matrix) {
		super("trace",new Arithmetic[] {matrix});
	}

	public Arithmetic compute() {
		Matrix matrix=(Matrix)parameter[0];
		return matrix.trace();
	}

	public String toMathML(Object data) {
		IndentedBuffer buffer=new IndentedBuffer();
		Matrix m=(Matrix)((MatrixVariable)parameter[0].variableValue()).content;
		int exponent=data instanceof Integer?((Integer)data).intValue():1;
		if(exponent==1) {
			buffer.append("<mo>tr</mo>\n");
		} else {
			buffer.append("<msup>\n");
			buffer.append(1,"<mo>tr</mo>\n");
			buffer.append(1,"<mn>").append(exponent).append("</mn>\n");
			buffer.append("</msup>\n");
		}
		buffer.append(m.toMathML(null));
		return buffer.toString();
	}

	protected Variable newinstance() {
		return new Trace(null);
	}
}
