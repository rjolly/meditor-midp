package jscl.math.operator;

import jscl.math.*;

public class TensorProduct extends Operator {
	public TensorProduct(Arithmetic matrix1, Arithmetic matrix2) {
		super("tensor",new Arithmetic[] {matrix1,matrix2});
	}

	public Arithmetic compute() {
		Matrix m1=(Matrix)parameter[0];
		Matrix m2=(Matrix)parameter[1];
		return m1.tensorProduct(m2);
	}

	public String toMathML(Object data) {
		IndentedBuffer buffer=new IndentedBuffer();
		int exponent=data instanceof Integer?((Integer)data).intValue():1;
		if(exponent==1) {
			buffer.append(bodyToMathML());
		} else {
			buffer.append("<msup>\n");
			buffer.append(1,"<mrow>\n");
			buffer.append(2,"<mo>(</mo>\n");
			buffer.append(2,bodyToMathML());
			buffer.append(2,"<mo>)</mo>\n");
			buffer.append(1,"</mrow>\n");
			buffer.append(1,"<mn>").append(exponent).append("</mn>\n");
			buffer.append("</msup>\n");
		}
		return buffer.toString();
	}

	String bodyToMathML() {
		IndentedBuffer buffer=new IndentedBuffer();
		Matrix m1=(Matrix)((MatrixVariable)parameter[0].variableValue()).content;
		Matrix m2=(Matrix)((MatrixVariable)parameter[1].variableValue()).content;
		buffer.append(m1.toMathML(null));
		buffer.append("<mo>&Cross;</mo>\n");
		buffer.append(m2.toMathML(null));
		return buffer.toString();
	}

	protected Variable newinstance() {
		return new TensorProduct(null,null);
	}
}
