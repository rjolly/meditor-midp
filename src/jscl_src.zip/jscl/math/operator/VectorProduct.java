package jscl.math.operator;

import jscl.math.*;
import jscl.text.*;

public class VectorProduct extends Operator {
	public VectorProduct(Arithmetic vector1, Arithmetic vector2) {
		super("vector",new Arithmetic[] {vector1,vector2});
	}

	public Arithmetic compute() {
		JSCLVector v1=(JSCLVector)parameter[0];
		JSCLVector v2=(JSCLVector)parameter[1];
		return v1.vectorProduct(v2);
	}

	public String toMathML(Object data) {
		IndentedBuffer buffer=new IndentedBuffer();
		int exponent=data instanceof Integer?((Integer)data).intValue():1;
		if(exponent==1) {
			buffer.append(bodyToMathML());
		} else {
			buffer.append("<msup>\n");
			buffer.append(1,"<mrow>\n");
			buffer.append(2,"<mo>(</mo>\n");
			buffer.append(2,bodyToMathML());
			buffer.append(2,"<mo>)</mo>\n");
			buffer.append(1,"</mrow>\n");
			buffer.append(1,"<mn>").append(exponent).append("</mn>\n");
			buffer.append("</msup>\n");
		}
		return buffer.toString();
	}

	String bodyToMathML() {
		IndentedBuffer buffer=new IndentedBuffer();
		JSCLVector v1=(JSCLVector)((VectorVariable)parameter[0].variableValue()).content;
		JSCLVector v2=(JSCLVector)((VectorVariable)parameter[1].variableValue()).content;
		buffer.append(v1.toMathML(null));
		buffer.append("<mo>&wedge;</mo>\n");
		buffer.append(v2.toMathML(null));
		return buffer.toString();
	}

	protected Variable newinstance() {
		return new VectorProduct(null,null);
	}
}
