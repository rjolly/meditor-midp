package jscl.math.operator;

import jscl.math.*;

public class Divergence extends Operator {
	public Divergence(Arithmetic vector, Arithmetic variable) {
		super("diverg",new Arithmetic[] {vector,variable});
	}

	public Arithmetic compute() {
		Variable variable[]=Variable.valueOf(((JSCLVector)parameter[1]).element);
		JSCLVector vector=(JSCLVector)parameter[0];
		return vector.divergence(variable);
	}

	protected Variable newinstance() {
		return new Divergence(null,null);
	}
}
