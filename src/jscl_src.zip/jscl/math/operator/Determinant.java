package jscl.math.operator;

import jscl.math.*;

public class Determinant extends Operator {
	public Determinant(Arithmetic matrix) {
		super("det",new Arithmetic[] {matrix});
	}

	public Arithmetic compute() {
		Matrix matrix=(Matrix)parameter[0];
		return matrix.determinant();
	}

	public String toMathML(Object data) {
		IndentedBuffer buffer=new IndentedBuffer();
		int exponent=data instanceof Integer?((Integer)data).intValue():1;
		if(exponent==1) {
			buffer.append(bodyToMathML());
		} else {
			buffer.append("<msup>\n");
			buffer.append(1,bodyToMathML());
			buffer.append(1,"<mn>").append(exponent).append("</mn>\n");
			buffer.append("</msup>\n");
		}
		return buffer.toString();
	}

	public String bodyToMathML() {
		IndentedBuffer buffer=new IndentedBuffer();
		Arithmetic element[][]=((Matrix)((MatrixVariable)parameter[0].variableValue()).content).element;
		int n=element.length;
		int p=element.length>0?element[0].length:0;
		buffer.append("<mrow>\n");
		buffer.append(1,"<mo>|</mo>\n");
		buffer.append(1,"<mtable>\n");
		for(int i=0;i<n;i++) {
			buffer.append(2,"<mtr>\n");
			for(int j=0;j<p;j++) {
				buffer.append(3,"<mtd>\n");
				buffer.append(4,element[i][j].toMathML(null));
				buffer.append(3,"</mtd>\n");
			}
			buffer.append(2,"</mtr>\n");
		}
		buffer.append(1,"</mtable>\n");
		buffer.append(1,"<mo>|</mo>\n");
		buffer.append("</mrow>\n");
		return buffer.toString();
	}

	protected Variable newinstance() {
		return new Determinant(null);
	}
}
