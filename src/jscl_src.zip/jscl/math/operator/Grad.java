package jscl.math.operator;

import jscl.math.*;

public class Grad extends Operator {
	public Grad(Arithmetic expression, Arithmetic variable) {
		super("grad",new Arithmetic[] {expression,variable});
	}

	public Arithmetic compute() {
		Variable variable[]=Variable.valueOf(((JSCLVector)parameter[1]).element);
		Expression expression=Expression.valueOf(parameter[0]);
		return expression.grad(variable);
	}

	protected Variable newinstance() {
		return new Grad(null,null);
	}
}
