package jscl.math.operator;

import jscl.math.*;

public class Division extends Operator {
	public Division(Arithmetic expression1, Arithmetic expression2) {
		super("div",new Arithmetic[] {expression1,expression2});
	}

	public Arithmetic compute() {
		return parameter[0].divideAndRemainder(parameter[1])[0];
	}

	protected Variable newinstance() {
		return new Division(null,null);
	}
}
