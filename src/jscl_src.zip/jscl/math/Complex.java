package jscl.math;

public class Complex extends JSCLVector {
	public Complex(Arithmetic element[]) {
		super(element);
	}

	public Arithmetic multiply(Arithmetic arithmetic) {
		if(arithmetic instanceof Complex) {
			Arithmetic m[][]={
				{element[0],element[1].negate()},
				{element[1],element[0]}
			};
			return new Matrix(m).multiply(arithmetic);
		} else return super.multiply(arithmetic);
	}

	public Arithmetic divide(Arithmetic arithmetic) throws ArithmeticException {
		if(arithmetic instanceof Complex) {
			Complex c=(Complex)arithmetic;
			return multiply(c.conjugate()).divide(c.modulus2());
		} else return super.divide(arithmetic);
	}

	public Arithmetic modulus2() {
		return scalarProduct(this);
	}

	public Complex conjugate() {
		Complex c=(Complex)newinstance();
		c.element[0]=element[0];
		c.element[1]=element[1].negate();
		return c;
	}

	public static Complex valueOf(Arithmetic re, Arithmetic im) {
		Complex c=new Complex(new Arithmetic[2]);
		c.element[0]=re;
		c.element[1]=im;
		return c;
	}

	protected Arithmetic newinstance(int n) {
		return new Complex(new Arithmetic[2]);
	}
}
