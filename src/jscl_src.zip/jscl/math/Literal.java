package jscl.math;

import java.util.*;
import jscl.math.function.*;
import jscl.util.*;

public class Literal implements jscl.util.Comparable {
	final Betatree content=new Betatree();
	int degree;

	Literal() {}

	public Literal multiply(Literal literal) {
		Literal l=valueof(this);
		l.put(literal);
		return l;
	}

	public Literal divide(Literal literal) throws ArithmeticException {
		Literal l=valueof(this);
		Enumeration k=literal.content.keys();
		Enumeration e=literal.content.elements();
		while(k.hasMoreElements()) {
			Variable v=(Variable)k.nextElement();
			int c=((Integer)e.nextElement()).intValue();
			if(content.containsKey(v)) {
				int c2=((Integer)content.get(v)).intValue();
				if(c>c2) throw new NotDivisibleException();
				else l.put(v,new Integer(-c));
			} else throw new NotDivisibleException();
		}
		return l;
	}

	public Literal gcd(Literal literal) {
		Literal l=newinstance();
		Enumeration k=literal.content.keys();
		Enumeration e=literal.content.elements();
		while(k.hasMoreElements()) {
			Variable v=(Variable)k.nextElement();
			int c2=((Integer)e.nextElement()).intValue();
			if(content.containsKey(v)) {
				int c=((Integer)content.get(v)).intValue();
				l.put(v,new Integer(Math.min(c,c2)));
			}
		}
		return l;
	}

	public Literal scm(Literal literal) {
		Literal l=valueof(this);
		Enumeration k=literal.content.keys();
		Enumeration e=literal.content.elements();
		while(k.hasMoreElements()) {
			Variable v=(Variable)k.nextElement();
			int c2=((Integer)e.nextElement()).intValue();
			if(content.containsKey(v)) {
				int c=((Integer)content.get(v)).intValue();
				if(c2>c) l.put(v,new Integer(c2-c));
			} else {
				l.put(v,new Integer(c2));
			}
		}
		return l;
	}

	public Literal valueof(Literal literal) {
		Literal l=newinstance();
		l.put(literal);
		return l;
	}

	public Arithmetic[] productValue() throws NotProductException {
		Arithmetic a[]=new Arithmetic[content.size()];
		Enumeration k=content.keys();
		Enumeration e=content.elements();
		for(int i=0;i<a.length;i++) {
			Variable v=(Variable)k.nextElement();
			int c=((Integer)e.nextElement()).intValue();
			a[i]=v.expressionValue().pow(c);
		}
		return a;
	}

	public Object[] powerValue() throws NotPowerException {
		int n=content.size();
		if(n==0) return new Object[] {JSCLInteger.valueOf(1),new Integer(1)};
		else if(n==1) {
			Variable v=(Variable)content.keys().nextElement();
			Integer in=(Integer)content.elements().nextElement();
			return new Object[] {v.expressionValue(),in};
		} else throw new NotPowerException();
	}

	public Variable variableValue() throws NotVariableException {
		int n=content.size();
		if(n==0) throw new NotVariableException();
		else if(n==1) {
			Variable v=(Variable)content.keys().nextElement();
			int c=((Integer)content.elements().nextElement()).intValue();
			if(c==1) return v;
			else throw new NotVariableException();
		} else throw new NotVariableException();
	}

	public int degree() {
		return degree;
	}

	public int compareTo(jscl.util.Comparable comparable) {
		Literal l=(Literal)comparable;
		Enumeration k1=content.keys(true);
		Enumeration e1=content.elements(true);
		Enumeration k2=l.content.keys(true);
		Enumeration e2=l.content.elements(true);
		while(true) {
			boolean b1=!k1.hasMoreElements();
			boolean b2=!k2.hasMoreElements();
			if(b1 && b2) return 0;
			else if(b1) return -1;
			else if(b2) return 1;
			else {
				Variable v1=(Variable)k1.nextElement();
				Variable v2=(Variable)k2.nextElement();
				int c=v1.compareTo(v2);
				if(c<0) return -1;
				else if(c>0) return 1;
				else {
					int c1=((Integer)e1.nextElement()).intValue();
					int c2=((Integer)e2.nextElement()).intValue();
					if(c1<c2) return -1;
					else if(c1>c2) return 1;
				}
			}
		}
	}

	Variable variable() {
		Enumeration e=content.keys();
		if(e.hasMoreElements()) return (Variable)e.nextElement();
		else return null;
	}

	Literal[] separate(Variable unknown[]) {
		Literal ll[]=new Literal[] {newinstance(),newinstance()};
		Enumeration k=content.keys();
		Enumeration e=content.elements();
		while(k.hasMoreElements()) {
			Variable v=(Variable)k.nextElement();
			Integer in=((Integer)e.nextElement());
			if(Monomial.variable(v,unknown)<unknown.length) ll[1].put(v,in);
			else ll[0].put(v,in);
		}
		return ll;
	}

	public static Literal valueOf(Monomial monomial) {
		Literal l=new Literal();
		for(int i=0;i<monomial.unknown.length;i++) {
			int c=monomial.get(i);
			if(c>0) l.put(
				monomial.unknown[i],
				new Integer(c)
			);
		}
		return l;
	}

	void put(Literal literal) {
		Enumeration k=literal.content.keys();
		Enumeration e=literal.content.elements();
		while(k.hasMoreElements()) {
			put(
				(Variable)k.nextElement(),
				(Integer)e.nextElement()
			);
		}
	}

	void put(Variable variable, Integer integer) {
		int c=content.containsKey(variable)?((Integer)content.get(variable)).intValue():0;
		int c2=c+integer.intValue();
		if(c2==0) {
			if(c>0) content.remove(variable);
		} else {
			content.put(variable,new Integer(c2));
		}
		int d=c2-c;
		degree+=d;
	}

	public String toString() {
		StringBuffer buffer=new StringBuffer();
		if(degree==0) buffer.append("1");
		Enumeration k=content.keys();
		Enumeration e=content.elements();
		for(int i=0;k.hasMoreElements();i++) {
			if(i>0) buffer.append("*");
			Variable v=(Variable)k.nextElement();
			int c=((Integer)e.nextElement()).intValue();
			if(c==1) buffer.append(v);
			else {
				if(v instanceof Frac) {
					buffer.append("(").append(v).append(")");
				} else buffer.append(v);
				buffer.append("^").append(c);
			}
		}
		return buffer.toString();
	}

	public String toMathML(Object data) {
		IndentedBuffer buffer=new IndentedBuffer();
		if(degree==0) buffer.append("<mn>1</mn>\n");
		Enumeration k=content.keys();
		Enumeration e=content.elements();
		for(int i=0;k.hasMoreElements();i++) {
			Variable v=(Variable)k.nextElement();
			int c=((Integer)e.nextElement()).intValue();
			buffer.append(v.toMathML(new Integer(c)));
		}
		return buffer.toString();
	}

	protected Literal newinstance() {
		return new Literal();
	}
}
