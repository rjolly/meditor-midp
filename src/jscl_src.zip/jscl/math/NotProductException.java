package jscl.math;

public class NotProductException extends ArithmeticException {
	public NotProductException() {}

	public NotProductException(String s) {
		super(s);
	}
}
