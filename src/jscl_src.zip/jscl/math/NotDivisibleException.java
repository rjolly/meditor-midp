package jscl.math;

public class NotDivisibleException extends ArithmeticException {
	public NotDivisibleException() {}

	public NotDivisibleException(String s) {
		super(s);
	}
}
