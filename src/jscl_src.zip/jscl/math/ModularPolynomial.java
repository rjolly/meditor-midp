package jscl.math;

import java.util.*;

public class ModularPolynomial extends MultivariatePolynomial {
	final JSCLInteger mod;

	ModularPolynomial(Variable unknown[], Comparator ordering, int modulo) {
		super(unknown,ordering);
		mod=JSCLInteger.valueOf(modulo);
	}

	public Polynomial normalize() {
		if(signum()!=0) try {
			return multiply(((JSCLInteger)tailCoefficient()).modInverse(mod));
		} catch (ArithmeticException e) {}
		return super.normalize();
	}

	public Polynomial s_polynomial(Polynomial polynomial) {
		ModularPolynomial p2=(ModularPolynomial)polynomial;
		Map.Entry e1=headTerm();
		Monomial m1=(Monomial)e1.getKey();
		Arithmetic c1=(Arithmetic)e1.getValue();
		Map.Entry e2=p2.headTerm();
		Monomial m2=(Monomial)e2.getKey();
		Arithmetic c2=(Arithmetic)e2.getValue();
		Monomial m=m1.scm(m2);
		m1=m.divide(m1);
		m2=m.divide(m2);
		Arithmetic c=c1.scm(c2);
		c1=c.divide(c1);
		c2=c.divide(c2);
		ModularPolynomial p=(ModularPolynomial)multiply(m1,c1);
		p.mutableReduce(JSCLInteger.valueOf(1),p2,m2,c2);
		return p.normalize();
	}

	public Polynomial reduce(Basis basis) {
		ModularPolynomial p=(ModularPolynomial)valueof(this);
		loop: while(p.signum()!=0) {
			Map.Entry e1=p.headTerm();
			Monomial m1=(Monomial)e1.getKey();
			Arithmetic c1=(Arithmetic)e1.getValue();
			Iterator it=basis.content.values().iterator();
			while(it.hasNext()) {
				ModularPolynomial q=(ModularPolynomial)it.next();
				Map.Entry e2=q.headTerm();
				Monomial m2=(Monomial)e2.getKey();
				if(m1.multiple(m2)) {
					Arithmetic c2=(Arithmetic)e2.getValue();
					Monomial m=m1.divide(m2);
					Arithmetic c=c1.scm(c2);
					c1=c.divide(c1);
					c2=c.divide(c2);
					p.mutableReduce(c1,q,m,c2);
					continue loop;
				}
			}
			break;
		}
		return p.normalize();
	}

	public Polynomial reduceCompletely(Basis basis) {
		ModularPolynomial p=(ModularPolynomial)valueof(this);
		Monomial l=null;
		loop: while(p.signum()!=0) {
			Iterator it=(l==null?p.content:p.content.headMap(l)).entrySet().iterator(true);
			while(it.hasNext()) {
				Map.Entry e1=(Map.Entry)it.next();
				Monomial m1=(Monomial)e1.getKey();
				Arithmetic c1=(Arithmetic)e1.getValue();
				Iterator it2=basis.content.values().iterator();
				while(it2.hasNext()) {
					ModularPolynomial q=(ModularPolynomial)it2.next();
					Map.Entry e2=q.headTerm();
					Monomial m2=(Monomial)e2.getKey();
					if(m1.multiple(m2)) {
						Arithmetic c2=(Arithmetic)e2.getValue();
						Monomial m=m1.divide(m2);
						Arithmetic c=c1.scm(c2);
						c1=c.divide(c1);
						c2=c.divide(c2);
						p.mutableReduce(c1,q,m,c2);
						l=m1;
						continue loop;
					}
				}
			}
			break;
		}
		return p.normalize();
	}

	void mutableReduce(Arithmetic c1, ModularPolynomial p2, Monomial m2, Arithmetic c2) {
		if(c1.compareTo(JSCLInteger.valueOf(1))==0);
		else {
			Iterator it=content.entrySet().iterator();
			while(it.hasNext()) {
				Map.Entry e=(Map.Entry)it.next();
				e.setValue(((Arithmetic)e.getValue()).multiply(c1));
			}
		}
		Iterator it=p2.content.entrySet().iterator();
		while(it.hasNext()) {
			Map.Entry e=(Map.Entry)it.next();
			put(
				((Monomial)e.getKey()).multiply(m2),
				((Arithmetic)e.getValue()).multiply(c2).negate()
			);
		}
		sugar=Math.max(sugar,p2.sugar+m2.degree());
	}

	protected Arithmetic uncoefficient(Arithmetic arithmetic) {
		return arithmetic;
	}

	protected Arithmetic coefficient(Arithmetic arithmetic) {
		return ((JSCLInteger)arithmetic).mod(mod);
	}

	void put(Monomial monomial, Arithmetic arithmetic) {
		Map.Entry e=content.myGetEntry(monomial);
		if(e!=null) {
			Arithmetic a=arithmetic.add((Arithmetic)e.getValue()).mod(mod);
			if(a.signum()==0) content.remove(monomial);
			else e.setValue(a);
		} else {
			Arithmetic a=arithmetic.mod(mod);
			if(a.signum()==0);
			else content.put(monomial,a);
		}
		if(content.isEmpty()) degree=0;
		else degree=headMonomial().degree();
	}

	protected Polynomial newinstance() {
		return new ModularPolynomial(unknown,ordering,mod.intValue());
	}
}
