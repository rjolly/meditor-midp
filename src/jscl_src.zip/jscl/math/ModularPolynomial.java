package jscl.math;

import java.util.*;

public class ModularPolynomial extends MultivariatePolynomial {
	final JSCLInteger mod;

	ModularPolynomial(Variable unknown[], Comparator ordering, int modulo) {
		super(unknown,ordering);
		mod=JSCLInteger.valueOf(modulo);
	}

	public Polynomial normalize() {
		if(signum()!=0) try {
			return multiply(((JSCLInteger)tailCoefficient()).modInverse(mod));
		} catch (ArithmeticException e) {}
		return super.normalize();
	}

	protected Arithmetic uncoefficient(Arithmetic arithmetic) {
		return arithmetic;
	}

	protected Arithmetic coefficient(Arithmetic arithmetic) {
		return ((JSCLInteger)arithmetic).mod(mod);
	}

	void put(Monomial monomial, Arithmetic arithmetic) {
		Map.Entry e=content.myGetEntry(monomial);
		if(e!=null) {
			Arithmetic a=arithmetic.add((Arithmetic)e.getValue()).mod(mod);
			if(a.signum()==0) content.remove(monomial);
			else e.setValue(a);
		} else {
			Arithmetic a=arithmetic.mod(mod);
			if(a.signum()==0);
			else content.put(monomial,a);
		}
		if(content.isEmpty()) degree=0;
		else degree=headMonomial().degree();
	}

	protected Polynomial newinstance() {
		return new ModularPolynomial(unknown,ordering,mod.intValue());
	}
}
