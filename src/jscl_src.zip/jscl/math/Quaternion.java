package jscl.math;

public class Quaternion extends JSCLVector {
	public Quaternion(Arithmetic element[]) {
		super(element);
	}

	public Arithmetic multiply(Arithmetic arithmetic) {
		if(arithmetic instanceof Quaternion) {
			Arithmetic m[][]={
				{element[0],element[1].negate(),element[2],element[3].negate()},
				{element[1],element[0],element[3],element[2]},
				{element[2].negate(),element[3].negate(),element[0],element[1]},
				{element[3],element[2].negate(),element[1].negate(),element[0]}
			};
			return new Matrix(m).multiply(arithmetic);
		} else return super.multiply(arithmetic);
	}

	public static Quaternion valueOf(Arithmetic x, Arithmetic y, Arithmetic z, Arithmetic w) {
		Quaternion c=new Quaternion(new Arithmetic[4]);
		c.element[0]=x;
		c.element[1]=y;
		c.element[2]=z;
		c.element[3]=w;
		return c;
	}

	protected Arithmetic newinstance(int n) {
		return new Quaternion(new Arithmetic[4]);
	}
}
