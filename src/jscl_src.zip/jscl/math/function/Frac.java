package jscl.math.function;

import jscl.math.*;
import jscl.text.*;
import jscl.util.*;

public class Frac extends Function implements Algebraic {
	public Frac(Arithmetic numerator, Arithmetic denominator) {
		super("",new Arithmetic[] {numerator,denominator});
	}

	public Root rootValue() {
		return new Root(
			new Arithmetic[] {
				parameter[0].negate(),
				parameter[1]
			},
			0
		);
	}

	public Arithmetic antiderivative(Variable variable) throws NotIntegrableException {
		if(parameter[0].isPolynomial(variable) && parameter[1].isPolynomial(variable)) {
			Antiderivative s=new Antiderivative(variable);
			s.compute(this);
			return s.getValue();
		} else throw new NotIntegrableException();
	}

	public Arithmetic antiderivative(int n) throws NotIntegrableException {
		return null;
	}

	public Arithmetic derivative(int n) {
		if(n==0) {
			return new Inv(parameter[1]).evaluate();
		} else {
			return parameter[0].multiply(new Inv(parameter[1]).evaluate().pow(2).negate());
		}
	}

	public Arithmetic evaluate() {
		if(parameter[0].signum()<0) {
			return new Frac(parameter[0].negate(),parameter[1]).evaluate().negate();
		} else if(parameter[0].signum()==0 && parameter[1].signum()!=0) {
			return JSCLInteger.valueOf(0);
		} else if(parameter[0].compareTo(JSCLInteger.valueOf(1))==0) {
			return new Inv(parameter[1]).evaluate();
		}
		if(parameter[1].signum()<0) {
			return new Frac(parameter[0].negate(),parameter[1].negate()).evaluate();
		} else if(parameter[1].compareTo(JSCLInteger.valueOf(1))==0) {
			return parameter[0];
		}
		return expressionValue();
	}

	public Arithmetic evalelem() {
		return evaluate();
	}

	public Arithmetic evalsimp() {
		return evaluate();
	}

	static Arithmetic[] separateCoefficient(Arithmetic arithmetic) {
		if(arithmetic.signum()<0) {
			Arithmetic n[]=separateCoefficient(arithmetic.negate());
			return new Arithmetic[] {n[0],n[1],n[2].negate()};
		}
		try {
			Variable v=arithmetic.variableValue();
			if(v instanceof Frac) {
				Frac f=(Frac)v;
				Arithmetic a=f.parameter[0].expressionValue();
				Arithmetic d=f.parameter[1].expressionValue();
				Arithmetic na[]=a.gcdAndNormalize();
				Arithmetic nd[]=d.gcdAndNormalize();
				return new Arithmetic[] {na[0],nd[0],new Frac(na[1],nd[1]).evaluate()};
			}
		} catch (NotVariableException e) {
			Arithmetic a=arithmetic.expressionValue();
			Arithmetic n[]=a.gcdAndNormalize();
			return new Arithmetic[] {n[0],JSCLInteger.valueOf(1),n[1]};
		}
		return new Arithmetic[] {JSCLInteger.valueOf(1),JSCLInteger.valueOf(1),arithmetic};
	}

	public int compareTo(Object comparable) {
		if(this==comparable) return 0;
		int c=comparator.compare(this,comparable);
		if(c<0) return -1;
		else if(c>0) return 1;
		else {
			Frac v=(Frac)comparable;
			return ArrayComparator.comparator.compare(parameter,v.parameter);
		}
	}

	public String toString() {
		StringBuffer buffer=new StringBuffer();
		try {
			parameter[0].powerValue();
			buffer.append(parameter[0]);
		} catch (NotPowerException e) {
			buffer.append(new ExpressionVariable(parameter[0]));
		}
		buffer.append("/");
		try {
			Variable v=parameter[1].variableValue();
			if(v instanceof Frac) {
				buffer.append(new ExpressionVariable(parameter[1]));
			} else buffer.append(v);
		} catch (NotVariableException e) {
			try {
				parameter[1].abs().powerValue();
				buffer.append(parameter[1]);
			} catch (NotPowerException e2) {
				buffer.append(new ExpressionVariable(parameter[1]));
			}
		}
		return buffer.toString();
	}

	public String toMathML(Object data) {
		IndentedBuffer buffer=new IndentedBuffer();
		int exponent=data instanceof Integer?((Integer)data).intValue():1;
		if(exponent==1) {
			buffer.append(bodyToMathML());
		} else {
			buffer.append("<msup>\n");
			buffer.append(1,"<mrow>\n");
			buffer.append(2,"<mo>(</mo>\n");
			buffer.append(2,bodyToMathML());
			buffer.append(2,"<mo>)</mo>\n");
			buffer.append(1,"</mrow>\n");
			buffer.append(1,"<mn>").append(exponent).append("</mn>\n");
			buffer.append("</msup>\n");
		}
		return buffer.toString();
	}

	String bodyToMathML() {
		IndentedBuffer buffer=new IndentedBuffer();
		buffer.append("<mfrac>\n");
		buffer.append(1,parameter[0].toMathML(null));
		buffer.append(1,parameter[1].toMathML(null));
		buffer.append("</mfrac>\n");
		return buffer.toString();
	}

	protected Variable newinstance() {
		return new Frac(null,null);
	}
}
