package jscl.math.function;

import java.util.*;
import jscl.math.*;
import jscl.math.function.hyperbolic.*;
import jscl.math.function.trigonometric.*;
import jscl.text.*;
import jscl.util.*;

public abstract class Function extends Variable {
	public static final Parser parser=FunctionParser.parser;
	public static final Parser parameterList=ParameterList.parser;
	public Arithmetic parameter[];

	public Function(String name, Arithmetic parameter[]) {
		super(name);
		this.parameter=parameter;
	}

	public abstract Arithmetic evaluate();

	public abstract Arithmetic evalelem();

	public abstract Arithmetic evalsimp();

	public Arithmetic antiderivative(Variable variable) throws NotIntegrableException {
		int n=-1;
		for(int i=0;i<parameter.length;i++) {
			if(n==-1 && parameter[i].isIdentity(variable)) n=i;
			else if(parameter[i].isConstant(variable));
			else {
				n=-1;
				break;
			}
		}
		if(n<0) throw new NotIntegrableException();
		else return antiderivative(n);
	}

	public abstract Arithmetic antiderivative(int n) throws NotIntegrableException;

	public Arithmetic derivative(Variable variable) {
		if(isIdentity(variable)) return JSCLInteger.valueOf(1);
		else {
			Arithmetic a=JSCLInteger.valueOf(0);
			for(int i=0;i<parameter.length;i++) {
				a=a.add(parameter[i].derivative(variable).multiply(derivative(i)));
			}
			return a;
		}
	}

	public abstract Arithmetic derivative(int n);

	public Arithmetic substitute(Variable variable, Arithmetic arithmetic) {
		Function v=(Function)newinstance();
		for(int i=0;i<parameter.length;i++) {
			v.parameter[i]=parameter[i].substitute(variable,arithmetic);
		}
		if(v.isIdentity(variable)) return arithmetic;
		else return v.evaluate();
	}

	public Arithmetic expand() {
		Function v=(Function)newinstance();
		for(int i=0;i<parameter.length;i++) {
			v.parameter[i]=parameter[i].expand();
		}
		return v.expressionValue();
	}

	public Arithmetic factorize() {
		Function v=(Function)newinstance();
		for(int i=0;i<parameter.length;i++) {
			v.parameter[i]=parameter[i].factorize();
		}
		return v.expressionValue();
	}

	public Arithmetic elementary() {
		Function v=(Function)newinstance();
		for(int i=0;i<parameter.length;i++) {
			v.parameter[i]=parameter[i].elementary();
		}
		return v.evalelem();
	}

	public Arithmetic simplify() {
		Function v=(Function)newinstance();
		for(int i=0;i<parameter.length;i++) {
			v.parameter[i]=parameter[i].simplify();
		}
		return v.evalsimp();
	}

	public boolean isConstant(Variable variable) {
		boolean s=!isIdentity(variable);
		for(int i=0;i<parameter.length;i++) {
			s=s && parameter[i].isConstant(variable);
		}
		return s;
	}

	public int compareTo(Object comparable) {
		if(this==comparable) return 0;
		int c=comparator.compare(this,comparable);
		if(c<0) return -1;
		else if(c>0) return 1;
		else {
			Function v=(Function)comparable;
			c=name.compareTo(v.name);
			if(c<0) return -1;
			else if(c>0) return 1;
			else return ArrayComparator.comparator.compare(parameter,v.parameter);
		}
	}

	public String toString() {
		StringBuffer buffer=new StringBuffer();
		buffer.append(name);
		buffer.append("(");
		for(int i=0;i<parameter.length;i++) {
			buffer.append(parameter[i]).append(i<parameter.length-1?", ":"");
		}
		buffer.append(")");
		return buffer.toString();
	}

	public String toMathML(Object data) {
		IndentedBuffer buffer=new IndentedBuffer();
		int exponent=data instanceof Integer?((Integer)data).intValue():1;
		if(exponent==1) {
			buffer.append(nameToMathML());
		} else {
			buffer.append("<msup>\n");
			buffer.append(1,nameToMathML());
			buffer.append(1,"<mn>").append(exponent).append("</mn>\n");
			buffer.append("</msup>\n");
		}
		buffer.append("<mo stretchy=\"false\">(</mo>\n");
		for(int i=0;i<parameter.length;i++) {
			buffer.append(parameter[i].toMathML(null));
			if(i<parameter.length-1) buffer.append("<mo>,</mo>\n");
		}
		buffer.append("<mo stretchy=\"false\">)</mo>\n");
		return buffer.toString();
	}
}

class FunctionParser extends Parser {
	public static final Parser parser=new FunctionParser();

	private FunctionParser() {}

	public Object parse(String str, int pos[]) throws ParseException {
		Function v;
		try {
			v=(Function)UsualFunctionParser.parser.parse(str,pos);
		} catch (ParseException e) {
			try {
				v=(Function)Root.parser.parse(str,pos);
			} catch (ParseException e2) {
				try {
					v=(Function)ImplicitFunction.parser.parse(str,pos);
				} catch (ParseException e3) {
					throw e3;
				}
			}
		}
		return v;
	}
}

class UsualFunctionParser extends Parser {
	public static final Parser parser=new UsualFunctionParser();

	private UsualFunctionParser() {}

	public Object parse(String str, int pos[]) throws ParseException {
		int pos0=pos[0];
		String name;
		Arithmetic a[];
		try {
			name=(String)Constant.identifier.parse(str,pos);
			if(valid(name));
			else {
				pos[0]=pos0;
				throw new ParseException();
			}
		} catch (ParseException e) {
			throw e;
		}
		try {
			a=(Arithmetic[])Function.parameterList.parse(str,pos);
		} catch (ParseException e) {
			pos[0]=pos0;
			throw e;
		}
		Function v=null;
		if(name.compareTo("sin")==0) v=new Sin(a[0]);
		else if(name.compareTo("cos")==0) v=new Cos(a[0]);
		else if(name.compareTo("tan")==0) v=new Tan(a[0]);
		else if(name.compareTo("asin")==0) v=new Asin(a[0]);
		else if(name.compareTo("acos")==0) v=new Acos(a[0]);
		else if(name.compareTo("atan")==0) v=new Atan(a[0]);
		else if(name.compareTo("log")==0) v=new Log(a[0]);
		else if(name.compareTo("exp")==0) v=new Exp(a[0]);
		else if(name.compareTo("sqrt")==0) v=new Sqrt(a[0]);
		else if(name.compareTo("sinh")==0) v=new Sinh(a[0]);
		else if(name.compareTo("cosh")==0) v=new Cosh(a[0]);
		else if(name.compareTo("tanh")==0) v=new Tanh(a[0]);
		else if(name.compareTo("asinh")==0) v=new Asinh(a[0]);
		else if(name.compareTo("acosh")==0) v=new Acosh(a[0]);
		else if(name.compareTo("atanh")==0) v=new Atanh(a[0]);
		else if(name.compareTo("abs")==0) v=new Abs(a[0]);
		else if(name.compareTo("sgn")==0) v=new Sgn(a[0]);
		return v;
	}

	static boolean valid(String name) {
		for(int i=0;i<na.length;i++) if(name.compareTo(na[i])==0) return true;
		return false;
	}

	private static String na[]={"sin","cos","tan","asin","acos","atan","log","exp","sqrt","sinh","cosh","tanh","asinh","acosh","atanh","abs","sgn"};
}

class ParameterList extends Parser {
	public static final Parser parser=new ParameterList();

	private ParameterList() {}

	public Object parse(String str, int pos[]) throws ParseException {
		int pos0=pos[0];
		Vector vector=new Vector();
		skipWhitespaces(str,pos);
		if(pos[0]<str.length() && str.charAt(pos[0])=='(') {
			str.charAt(pos[0]++);
		} else {
			pos[0]=pos0;
			throw new ParseException();
		}
		try {
			Arithmetic a=(Arithmetic)Expression.parser.parse(str,pos);
			vector.addElement(a);
		} catch (ParseException e) {
			pos[0]=pos0;
			throw e;
		}
		while(true) {
			try {
				Arithmetic a=(Arithmetic)Expression.commaAndExpression.parse(str,pos);
				vector.addElement(a);
			} catch (ParseException e) {
				break;
			}
		}
		skipWhitespaces(str,pos);
		if(pos[0]<str.length() && str.charAt(pos[0])==')') {
			str.charAt(pos[0]++);
		} else {
			pos[0]=pos0;
			throw new ParseException();
		}
		Arithmetic a[]=new Arithmetic[vector.size()];
		vector.copyInto(a);
		return a;
	}
}
