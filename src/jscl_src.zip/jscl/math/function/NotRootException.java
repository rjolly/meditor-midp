package jscl.math.function;

public class NotRootException extends ArithmeticException {
	public NotRootException() {}

	public NotRootException(String s) {
		super(s);
	}
}
