package jscl.math.function;

import jscl.math.*;

public abstract class ArcTrigonometric extends Function {
	public ArcTrigonometric(String name, Arithmetic parameter[]) {
		super(name,parameter);
	}

	public Arithmetic antiderivative(int n) throws NotIntegrableException {
		throw new NotIntegrableException();
	}

	public Arithmetic evalsimp() {
		return evaluate();
	}
}
