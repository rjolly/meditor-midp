package jscl.math.function;

import jscl.math.*;
import jscl.text.*;

public class Sgn extends Function {
	public Sgn(Arithmetic arithmetic) {
		super("sgn",new Arithmetic[] {arithmetic});
	}

	public Arithmetic antiderivative(int n) throws NotIntegrableException {
		return new Abs(parameter[0]).evaluate();
	}

	public Arithmetic derivative(int n) {
		return JSCLInteger.valueOf(0);
	}

	public Arithmetic evaluate() {
		if(parameter[0].signum()<0) {
			return new Sgn(parameter[0].negate()).evaluate().negate();
		} else if(parameter[0].signum()==0) {
			return JSCLInteger.valueOf(1);
		}
		try {
			return JSCLInteger.valueOf(parameter[0].integerValue().signum());
		} catch (NotIntegerException e) {}
		return expressionValue();
	}

	public Arithmetic evalelem() {
		return new Frac(
			parameter[0],
			new Abs(parameter[0]).evalelem()
		).evalelem();
	}

	public Arithmetic evalsimp() {
		if(parameter[0].signum()<0) {
			return new Sgn(parameter[0].negate()).evaluate().negate();
		} else if(parameter[0].signum()==0) {
			return JSCLInteger.valueOf(1);
		}
		try {
			return JSCLInteger.valueOf(parameter[0].integerValue().signum());
		} catch (NotIntegerException e) {}
		try {
			Variable v=parameter[0].variableValue();
			if(v instanceof Abs) {
				return JSCLInteger.valueOf(1);
			} else if(v instanceof Sgn) {
				Function f=(Function)v;
				return f.evalsimp();
			}
		} catch (NotVariableException e) {}
		return expressionValue();
	}

	public Arithmetic evalnum() {
		return ((NumericWrapper)parameter[0]).sgn();
	}

	public String toJava() {
		StringBuffer buffer=new StringBuffer();
		buffer.append(parameter[0].toJava());
		buffer.append(".sgn()");
		return buffer.toString();
	}

	protected Variable newinstance() {
		return new Sgn(null);
	}
}
