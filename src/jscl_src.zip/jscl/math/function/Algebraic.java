package jscl.math.function;

public interface Algebraic {
	public abstract Root rootValue() throws NotRootException;
}
