package jscl.math.function.hyperbolic;

import jscl.math.*;
import jscl.math.function.*;

public class Sinh extends Trigonometric {
	public Sinh(Arithmetic arithmetic) {
		super("sinh",new Arithmetic[] {arithmetic});
	}

	public Arithmetic antiderivative(int n) throws NotIntegrableException {
		return new Cosh(parameter[0]).evaluate();
	}

	public Arithmetic derivative(int n) {
		return new Cosh(parameter[0]).evaluate();
	}

	public Arithmetic evaluate() {
		if(parameter[0].signum()<0) {
			return new Sinh(parameter[0].negate()).evaluate().negate();
		} else if(parameter[0].signum()==0) {
			return JSCLInteger.valueOf(0);
		}
		return expressionValue();
	}

	public Arithmetic evalelem() {
		return new Exp(
			parameter[0]
		).evalelem().subtract(
			new Exp(
				parameter[0].negate()
			).evalelem()
		).multiply(Constant.half);
	}

	public Arithmetic evalsimp() {
		if(parameter[0].signum()<0) {
			return new Sinh(parameter[0].negate()).evaluate().negate();
		} else if(parameter[0].signum()==0) {
			return JSCLInteger.valueOf(0);
		}
		try {
			Variable v=parameter[0].variableValue();
			if(v instanceof Asinh) {
				Function f=(Function)v;
				return f.parameter[0];
			}
		} catch (NotVariableException e) {}
		return identity();
	}

	public Arithmetic identity(Arithmetic a, Arithmetic b) {
		return new Cosh(b).evalsimp().multiply(
			new Sinh(a).evalsimp()
		).add(
			new Cosh(a).evalsimp().multiply(
				new Sinh(b).evalsimp()
			)
		);
	}

	protected Variable newinstance() {
		return new Sinh(null);
	}
}
