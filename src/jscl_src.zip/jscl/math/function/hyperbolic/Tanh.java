package jscl.math.function.hyperbolic;

import jscl.math.*;
import jscl.math.function.*;

public class Tanh extends Function {
	public Tanh(Arithmetic arithmetic) {
		super("th",new Arithmetic[] {arithmetic});
	}

	public Arithmetic antiderivative(int n) throws NotIntegrableException {
		throw new NotIntegrableException();
	}

	public Arithmetic derivative(int n) {
		return JSCLInteger.valueOf(1).subtract(
			new Tanh(parameter[0]).evaluate().pow(2)
		);
	}

	public Arithmetic evaluate() {
		if(parameter[0].signum()<0) {
			return new Tanh(parameter[0].negate()).evaluate().negate();
		} else if(parameter[0].signum()==0) {
			return JSCLInteger.valueOf(0);
		}
		return expressionValue();
	}

	public Arithmetic evalelem() {
		return new Frac(
			new Sinh(parameter[0]).evalelem(),
			new Cosh(parameter[0]).evalelem()
		).evalelem();
	}

	public Arithmetic evalsimp() {
		return evaluate();
	}

	protected Variable newinstance() {
		return new Tanh(null);
	}
}
