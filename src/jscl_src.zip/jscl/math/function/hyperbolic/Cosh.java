package jscl.math.function.hyperbolic;

import jscl.math.*;
import jscl.math.function.*;

public class Cosh extends Trigonometric {
	public Cosh(Arithmetic arithmetic) {
		super("cosh",new Arithmetic[] {arithmetic});
	}

	public Arithmetic antiderivative(int n) throws NotIntegrableException {
		return new Sinh(parameter[0]).evaluate();
	}

	public Arithmetic derivative(int n) {
		return new Sinh(parameter[0]).evaluate();
	}

	public Arithmetic evaluate() {
		if(parameter[0].signum()<0) {
			return new Cosh(parameter[0].negate()).evaluate();
		} else if(parameter[0].signum()==0) {
			return JSCLInteger.valueOf(1);
		}
		return expressionValue();
	}

	public Arithmetic evalelem() {
		return new Exp(
			parameter[0]
		).evalelem().add(
			new Exp(
				parameter[0].negate()
			).evalelem()
		).multiply(Constant.half);
	}

	public Arithmetic evalsimp() {
		if(parameter[0].signum()<0) {
			return new Cosh(parameter[0].negate()).evaluate();
		} else if(parameter[0].signum()==0) {
			return JSCLInteger.valueOf(1);
		}
		try {
			Variable v=parameter[0].variableValue();
			if(v instanceof Acosh) {
				Function f=(Function)v;
				return f.parameter[0];
			}
		} catch (NotVariableException e) {}
		return identity();
	}

	public Arithmetic identity(Arithmetic a, Arithmetic b) {
		return new Cosh(a).evalsimp().multiply(
			new Cosh(b).evalsimp()
		).add(
			new Sinh(a).evalsimp().multiply(
				new Sinh(b).evalsimp()
			)
		);
	}

	protected Variable newinstance() {
		return new Cosh(null);
	}
}
