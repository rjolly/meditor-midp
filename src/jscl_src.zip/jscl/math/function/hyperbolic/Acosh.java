package jscl.math.function.hyperbolic;

import jscl.math.*;
import jscl.math.function.*;

public class Acosh extends Function {
	public Acosh(Arithmetic arithmetic) {
		super("acosh",new Arithmetic[] {arithmetic});
	}

	public Arithmetic antiderivative(int n) throws NotIntegrableException {
		throw new NotIntegrableException();
	}

	public Arithmetic derivative(int n) {
		return new Inv(
			new Sqrt(
				parameter[0].pow(2).subtract(
					JSCLInteger.valueOf(1)
				)
			).evaluate()
		).evaluate();
	}

	public Arithmetic evaluate() {
		if(parameter[0].signum()==0) {
			return JSCLInteger.valueOf(0);
		}
		return expressionValue();
	}

	public Arithmetic evalelem() {
		return new Log(
			new Root(
				new Arithmetic[] {
					JSCLInteger.valueOf(-1),
					JSCLInteger.valueOf(2).multiply(parameter[0]),
					JSCLInteger.valueOf(-1)
				},
				0
			).evalelem()
		).evalelem();
	}

	public Arithmetic evalsimp() {
		return evaluate();
	}

	protected Variable newinstance() {
		return new Acosh(null);
	}
}
