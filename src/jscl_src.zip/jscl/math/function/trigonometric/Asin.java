package jscl.math.function.trigonometric;

import jscl.math.*;
import jscl.math.function.*;

public class Asin extends Function {
	public Asin(Arithmetic arithmetic) {
		super("asin",new Arithmetic[] {arithmetic});
	}

	public Arithmetic antiderivative(int n) throws NotIntegrableException {
		throw new NotIntegrableException();
	}

	public Arithmetic derivative(int n) {
		return new Inv(
			new Sqrt(
				JSCLInteger.valueOf(1).subtract(parameter[0].pow(2))
			).evaluate()
		).evaluate();
	}

	public Arithmetic evaluate() {
		if(parameter[0].signum()<0) {
			return new Asin(parameter[0].negate()).evaluate().negate();
		} else if(parameter[0].signum()==0) {
			return JSCLInteger.valueOf(0);
		}
		return expressionValue();
	}

	public Arithmetic evalelem() {
		return Constant.i.multiply(
			new Log(
				new Root(
					new Arithmetic[] {
						JSCLInteger.valueOf(-1),
						JSCLInteger.valueOf(2).multiply(Constant.i.multiply(parameter[0])),
						JSCLInteger.valueOf(1)
					},
					0
				).evalelem()
			).evalelem()
		);
	}

	public Arithmetic evalsimp() {
		return evaluate();
	}

	protected Variable newinstance() {
		return new Asin(null);
	}
}
