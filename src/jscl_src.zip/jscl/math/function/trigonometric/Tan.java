package jscl.math.function.trigonometric;

import jscl.math.*;
import jscl.math.function.*;

public class Tan extends Trigonometric {
	public Tan(Arithmetic arithmetic) {
		super("tan",new Arithmetic[] {arithmetic});
	}

	public Arithmetic antiderivative(int n) throws NotIntegrableException {
		throw new NotIntegrableException();
	}

	public Arithmetic derivative(int n) {
		return JSCLInteger.valueOf(1).add(
			new Tan(parameter[0]).evaluate().pow(2)
		);
	}

	public Arithmetic evaluate() {
		if(parameter[0].signum()<0) {
			return new Tan(parameter[0].negate()).evaluate().negate();
		} else if(parameter[0].signum()==0) {
			return JSCLInteger.valueOf(0);
		} else if(parameter[0].compareTo(Constant.pi)==0) {
			return JSCLInteger.valueOf(0);
		}
		return expressionValue();
	}

	public Arithmetic evalelem() {
		return new Frac(
			new Sin(parameter[0]).evalelem(),
			new Cos(parameter[0]).evalelem()
		).evalelem();
	}

	public Arithmetic evalsimp() {
		if(parameter[0].signum()<0) {
			return new Tan(parameter[0].negate()).evaluate().negate();
		} else if(parameter[0].signum()==0) {
			return JSCLInteger.valueOf(0);
		} else if(parameter[0].compareTo(Constant.pi)==0) {
			return JSCLInteger.valueOf(0);
		}
		try {
			Variable v=parameter[0].variableValue();
			if(v instanceof Atan) {
				Function f=(Function)v;
				return f.parameter[0];
			}
		} catch (NotVariableException e) {}
		return identity();
	}

	public Arithmetic identity(Arithmetic a, Arithmetic b) {
		Arithmetic ta=new Tan(a).evalsimp();
		Arithmetic tb=new Tan(b).evalsimp();
		return new Frac(
			ta.add(tb),
			JSCLInteger.valueOf(1).subtract(
				ta.multiply(tb)
			)
		).evalsimp();
	}

	protected Variable newinstance() {
		return new Tan(null);
	}
}
