package jscl.math.function;

import jscl.math.*;

public abstract class Trigonometric extends Function {
	public Trigonometric(String name, Arithmetic parameter[]) {
		super(name,parameter);
	}

	public Arithmetic identity() {
		Arithmetic a[]=parameter[0].sumValue();
		if(a.length>1) {
			Arithmetic s=JSCLInteger.valueOf(0);
			for(int i=1;i<a.length;i++) s=s.add(a[i]);
			return identity(a[0],s);
		}
		Arithmetic n[]=Frac.separateCoefficient(parameter[0]);
		if(n[0].compareTo(JSCLInteger.valueOf(1))==0);
		else {
			Arithmetic s=new Frac(n[2],n[1]).evalsimp();
			return identity(s,n[0].subtract(JSCLInteger.valueOf(1)).multiply(s));
		}
		return expressionValue();
	}

	public abstract Arithmetic identity(Arithmetic a, Arithmetic b);
}
