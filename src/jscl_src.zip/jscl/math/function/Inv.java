package jscl.math.function;

import jscl.math.*;

public class Inv extends Frac {
	public Inv(Arithmetic arithmetic) {
		super(JSCLInteger.valueOf(1),arithmetic);
	}

	public Arithmetic evaluate() {
		if(parameter().signum()<0) {
			return new Inv(parameter().negate()).evaluate().negate();
		} else if(parameter().compareTo(JSCLInteger.valueOf(1))==0) {
			return JSCLInteger.valueOf(1);
		}
		return expressionValue();
	}

	public Arithmetic parameter() {
		return parameter[1];
	}

	protected Variable newinstance() {
		return new Inv(null);
	}
}
