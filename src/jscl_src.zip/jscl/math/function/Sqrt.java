package jscl.math.function;

import jscl.math.*;
import jscl.text.*;

public class Sqrt extends Function implements Algebraic {
	public Sqrt(Arithmetic arithmetic) {
		super("sqrt",new Arithmetic[] {arithmetic});
	}

	public Root rootValue() {
		return new Root(
			new Arithmetic[] {
				parameter[0].negate(),
				JSCLInteger.valueOf(0),
				JSCLInteger.valueOf(1)
			},
			0
		);
	}

	public Arithmetic antiderivative(Variable variable) throws NotIntegrableException {
		Root r=rootValue();
		if(r.parameter[0].isPolynomial(variable)) {
			Antiderivative s=new Antiderivative(variable);
			s.compute(r);
			return s.getValue();
		} else throw new NotIntegrableException();
	}

	public Arithmetic antiderivative(int n) throws NotIntegrableException {
		return null;
	}

	public Arithmetic derivative(int n) {
		return Constant.half.multiply(
			new Inv(
				evaluate()
			).evaluate()
		);
	}

	public Arithmetic evaluate() {
		try {
			JSCLInteger en=parameter[0].integerValue();
			if(en.signum()<0);
			else {
				Arithmetic sqrt=sqrt(en);
				if(sqrt.pow(2).compareTo(en)==0) return sqrt;
			}
		} catch (NotIntegerException e) {}
		return expressionValue();
	}

	public Arithmetic evalelem() {
		return evaluate();
	}

	public Arithmetic evalsimp() {
		try {
			JSCLInteger en=parameter[0].integerValue();
			if(en.signum()<0) return Constant.i.multiply(new Sqrt(en.negate()).evalsimp());
			else {
				Arithmetic sqrt=sqrt(en);
				if(sqrt.pow(2).compareTo(en)==0) return sqrt;
			}
			Arithmetic a=en.factorize();
			Arithmetic p[]=a.productValue();
			Arithmetic s=JSCLInteger.valueOf(1);
			for(int i=0;i<p.length;i++) {
				Object o[]=p[i].powerValue();
				Arithmetic q=IntegerVariable.content((Arithmetic)o[0]);
				int c=((Integer)o[1]).intValue();
				s=s.multiply(q.pow(c/2).multiply(new Sqrt(q).expressionValue().pow(c%2)));
			}
			return s;
		} catch (NotIntegerException e) {}
		Arithmetic n[]=Frac.separateCoefficient(parameter[0]);
		if(n[0].compareTo(JSCLInteger.valueOf(1))==0 && n[1].compareTo(JSCLInteger.valueOf(1))==0);
		else return new Sqrt(n[2]).evalsimp().multiply(
			new Frac(
				new Sqrt(n[0]).evalsimp(),
				new Sqrt(n[1]).evalsimp()
			).evalsimp()
		);
		return expressionValue();
	}

	static Arithmetic sqrt(JSCLInteger y) {
//		return JSCLInteger.valueOf((int)Math.sqrt((double)y.intValue()));
		if(y.signum()==0) return JSCLInteger.valueOf(0);
		else {
			Arithmetic x0;
			Arithmetic x=y;
			do {
				x0=x;
				x=y.divideAndRemainder(x)[0].add(x).divideAndRemainder(JSCLInteger.valueOf(2))[0];
			} while(x.compareTo(x0)<0);
			return x0;
		}
	}

	public String toMathML(Object data) {
		IndentedBuffer buffer=new IndentedBuffer();
		int exponent=data instanceof Integer?((Integer)data).intValue():1;
		if(exponent==1) {
			buffer.append(bodyToMathML());
		} else {
			buffer.append("<msup>\n");
			buffer.append(1,bodyToMathML());
			buffer.append(1,"<mn>").append(exponent).append("</mn>\n");
			buffer.append("</msup>\n");
		}
		return buffer.toString();
	}

	String bodyToMathML() {
		IndentedBuffer buffer=new IndentedBuffer();
		buffer.append("<msqrt>\n");
		buffer.append(1,parameter[0].toMathML(null));
		buffer.append("</msqrt>\n");
		return buffer.toString();
	}

	protected Variable newinstance() {
		return new Sqrt(null);
	}
}
