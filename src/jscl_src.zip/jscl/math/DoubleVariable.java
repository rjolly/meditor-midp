package jscl.math;

import jscl.text.*;

public class DoubleVariable extends ArithmeticVariable {
	public static final Parser parser=DoubleVariableParser.parser;

	public DoubleVariable(Arithmetic arithmetic) {
		super(arithmetic);
	}

	public Arithmetic antiderivative(Variable variable) throws NotIntegrableException {
		return expressionValue().multiply(variable.expressionValue());
	}

	public Arithmetic derivative(Variable variable) {
		return JSCLInteger.valueOf(0);
	}

	public Arithmetic substitute(Variable variable, Arithmetic arithmetic) {
		return expressionValue();
	}

	public Arithmetic expand() {
		return expressionValue();
	}

	public Arithmetic factorize() {
		return expressionValue();
	}

	public Arithmetic elementary() {
		return expressionValue();
	}

	public Arithmetic simplify() {
		return expressionValue();
	}

	protected Variable newinstance() {
		return new DoubleVariable(null);
	}
}

class DoubleVariableParser extends Parser {
	public static final Parser parser=new DoubleVariableParser();

	private DoubleVariableParser() {}

	public Object parse(String str, int pos[]) throws ParseException {
		NumericWrapper a;
		try {
			a=(NumericWrapper)NumericWrapper.parser.parse(str,pos);
		} catch (ParseException e) {
			throw e;
		}
		return new DoubleVariable(a);
	}
}
