package jscl.math;

import java.util.*;
import jscl.math.function.*;

public class Factorization {
	Factorized result;

	public void compute(Arithmetic arithmetic) {
		try {
			result=process(arithmetic.integerValue());
		} catch (NotIntegerException e) {
			Debug.println("factorization");
			Debug.increment();
			result=process(Polynomial.valueOf(arithmetic,Polynomial.unknown(arithmetic),Monomial.totalDegreeLexicographic,0));
			Debug.decrement();
		}
	}

	Factorized process(Polynomial polynomial) {
		Arithmetic n[]=polynomial.gcdAndNormalize();
		Polynomial b=(Polynomial)n[1];
		FactorizedExpression f=new FactorizedExpression();
		CandidateGenerator cg=new CandidateGenerator(b);
		cg.init();
		while(true) {
			Candidate p=cg.current();
			Candidate q=cg.carry()?null:cg.complementary(p);
			if(q==null?true:q.compareTo(p)<0) {
				f.put(expression(b));
				break;
			}
			Debug.println(""+p+", "+q);
			Polynomial r[]=remainder(b,cg.polynomial(p,"a"),cg.polynomial(q,"b"));
			if(r[0].signum()==0) {
				f.put(expression(r[1]));
				b=r[2];
				cg=new CandidateGenerator(b);
				cg.init(p);
			} else {
				cg.increment();
			}
		}
		f.put(n[0]);
		return f;
	}

	Arithmetic expression(Polynomial polynomial) {
		return ExpressionVariable.content(Expression.valueOf(polynomial));
	}

	Polynomial[] remainder(Polynomial b, Polynomial p, Polynomial q) {
		Polynomial z=new Polynomial(b.unknown,b.ordering,b.modulo);
		Arithmetic a[]=((Polynomial)b.subtract(p.multiply(q))).element();
		if(a.length==0) return new Polynomial[] {z,p,q};
		Variable in[]=new Variable[0];
		in=Basis.augmentUnknown(in,a);
		if(in.length==0) return new Polynomial[] {b,z,z};
		Basis basis=new Basis(a,in,Monomial.lexicographic,0);
		basis.compute();
		int n=basis.size();
		if(n>0 && basis.get(0).compareTo(JSCLInteger.valueOf(1))==0) return new Polynomial[] {b,z,z};
		try {
			linearize(basis);
		} catch (NotIntegerException e) {
			return new Polynomial[] {b,z,z};
		}
		n=basis.size();
		Vector w=new Vector();
		Vector u=new Vector();
		for(int i=0;i<n;i++) w.addElement(basis.get(i));
		for(int i=0;i<in.length;i++) u.addElement(in[i]);
		Variable vp=new TechnicalVariable("p");
		Variable vq=new TechnicalVariable("q");
		w.addElement(vp.expressionValue().subtract(p));
		w.addElement(vq.expressionValue().subtract(q));
		u.addElement(vp);
		u.addElement(vq);
		a=new Arithmetic[w.size()];
		w.copyInto(a);
		in=new Variable[u.size()];
		u.copyInto(in);
		basis=new Basis(a,in,Monomial.lexicographic,0);
		basis.reduce();
		basis.sort();
		n=basis.size();
		p=Polynomial.valueOf(UnivariatePolynomial.valueOf(basis.get(n-2),vp).solve(),b.unknown,b.ordering,b.modulo);
		q=Polynomial.valueOf(UnivariatePolynomial.valueOf(basis.get(n-1),vq).solve(),b.unknown,b.ordering,b.modulo);
		return new Polynomial[] {z,p,q};
	}

	static void linearize(Basis basis) throws NotIntegerException {
		loop: while(true) {
			int n=basis.size();
			for(int i=0;i<n;i++) {
				Expression s=basis.get(i);
				Literal l=s.variables();
				if(l.content.size()==1) {
					Variable t=l.variable();
					UnivariatePolynomial pr=UnivariatePolynomial.valueOf(s,t);
					if(pr.degree()>1) {
						pr=(UnivariatePolynomial)pr.squarefree();
						JSCLInteger r=new Root(pr,0).expressionValue().simplify().integerValue();
						basis.put(basis.polynomial(t.expressionValue().subtract(r)));
						basis.reduce();
						continue loop;
					}
				}
			}
			break;
		}
	}

	Factorized process(JSCLInteger integer) {
		Arithmetic n[]=integer.gcdAndNormalize();
		Arithmetic b=n[1];
		FactorizedInteger f=new FactorizedInteger();
		Arithmetic p=JSCLInteger.valueOf(2);
		while(true) {
			Arithmetic q[]=b.divideAndRemainder(p);
			if(q[0].compareTo(p)<0) {
				f.put(b);
				break;
			}
			if(q[1].signum()==0) {
				f.put(p);
				b=q[0];
			} else {
				p=p.add(JSCLInteger.valueOf(1));
			}
		}
		f.put(n[0]);
		return f;
	}

	public Factorized getValue() {
		return result;
	}
}

class CandidateGenerator {
	Polynomial polynomial;
	CandidateMonomial head;
	CandidateMonomial tail;
	CandidateCoefficient headcoef;
	CandidateCoefficient tailcoef;
	boolean sign;
	boolean carry;

	CandidateGenerator(Polynomial p) {
		polynomial=p;
		head=new CandidateMonomial((Monomial)p.content.lastKey());
		tail=new CandidateMonomial((Monomial)p.content.firstKey());
		headcoef=new CandidateCoefficient((Arithmetic)p.content.values().iterator(true).next());
		tailcoef=new CandidateCoefficient((Arithmetic)p.content.values().iterator().next());
		sign=false;
	}

	void init() {
		head.increment();
		head.next();
		if(head.carry()) carry=true;
	}

	void init(Candidate ca) {
		tail.init(ca.tail);
		head.init(ca.head);
		if(tail.current().compareTo(tail.monomial)>0) {
			tail.reset();
			tail.carry=true;
		}
		tail.next();
		if(tail.carry()) head.increment();
		if(head.current().compareTo(head.monomial)>0) {
			head.reset();
			head.carry=true;
		}
		head.next();
		if(head.carry()) carry=true;
	}

	Candidate current() {
		return new Candidate(head.current(),tail.current(),headcoef.current(),tailcoef.current(),sign);
	}

	Polynomial polynomial(Candidate ca, String str) {
		Polynomial p=new Polynomial(polynomial.unknown,polynomial.ordering,polynomial.modulo);
		int c=ca.head.compareTo(ca.tail);
		if(c==0) {
			p.put(ca.tail,JSCLInteger.valueOf(1));
		} else {
			boolean direction=c<0;
			CandidateMonomial inter=new CandidateMonomial(direction?ca.head:ca.tail);
			inter.init(inter.monomial);
			for(int i=0;true;i++) {
				Monomial m=inter.current();
				if(m.compareTo(ca.tail)==0) {
					p.put(m,ca.tailcoef);
					if(direction) break;
				} else if(m.compareTo(ca.head)==0) {
					p.put(m,ca.sign?ca.headcoef.negate():ca.headcoef);
					if(!direction) break;
				} else {
					p.put(m,new TechnicalVariable(str,new int[] {i}).expressionValue());
				}
				inter.increment(false);
			}
		}
		return p;
	}

	Candidate complementary(Candidate ca) {
		return new Candidate(head.monomial.divide(ca.head),tail.monomial.divide(ca.tail),headcoef.arithmetic.divide(ca.headcoef),tailcoef.arithmetic.divide(ca.tailcoef),headcoef.sign?!sign:sign);
	}

	boolean carry() {
		return carry;
	}

	void increment() {
		if(tail.current().compareTo(head.current())==0) {
			tail.increment();
			if(tail.current().compareTo(head.current())>0) {
				tail.reset();
				tail.carry=true;
			}
			tail.next();
			if(tail.carry()) {
				head.increment();
				head.next();
			}
		} else {
			sign=!sign;
			if(!sign) {
				tailcoef.increment();
				if(tailcoef.carry()) {
					headcoef.increment();
					if(headcoef.carry()) {
						tail.increment();
						if(tail.current().compareTo(head.current())>0) {
							tail.reset();
							tail.carry=true;
						}
						tail.next();
						if(tail.carry()) {
							head.increment();
							head.next();
						}
					}
				}
			}
		}
		carry=head.carry();
	}
}

class Candidate implements Comparable {
	Monomial head;
	Monomial tail;
	Arithmetic headcoef;
	Arithmetic tailcoef;
	boolean sign;

	Candidate(Monomial head, Monomial tail, Arithmetic headcoef, Arithmetic tailcoef, boolean sign) {
		this.head=head;
		this.tail=tail;
		this.headcoef=headcoef;
		this.tailcoef=tailcoef;
		this.sign=sign;
	}

	public int compareTo(Object comparable) {
		Candidate ca=(Candidate)comparable;
		if(head.compareTo(ca.head)<0) return -1;
		else if(head.compareTo(ca.head)>0) return 1;
		else {
			if(tail.compareTo(ca.tail)<0) return -1;
			else if(tail.compareTo(ca.tail)>0) return 1;
			else {
				if(headcoef.compareTo(ca.headcoef)<0) return -1;
				else if(headcoef.compareTo(ca.headcoef)>0) return 1;
				else {
					if(tailcoef.compareTo(ca.tailcoef)<0) return -1;
					else if(tailcoef.compareTo(ca.tailcoef)>0) return 1;
					else {
						if(!sign && ca.sign) return -1;
						else if(sign && !ca.sign) return 1;
						else return 0;
					}
				}
			}
		}
	}

	public String toString() {
		StringBuffer buffer=new StringBuffer();
		buffer.append("{").append(head).append(", ").append(tail).append(", ").append(headcoef).append(", ").append(tailcoef).append(", ").append(sign?"-":"+").append("}");
		return buffer.toString();
	}
}

class CandidateMonomial {
	Monomial monomial;
	int element[];
	int degree;
	boolean carry;

	CandidateMonomial(Monomial monomial) {
		this.monomial=monomial;
		element=new int[monomial.unknown.length];
		degree=0;
	}

	void init(Monomial m) {
		for(int i=0;i<element.length;i++) {
			element[i]=m.get(i);
		}
		degree=m.degree();
	}

	Monomial current() {
		return Monomial.valueOf(element,monomial.unknown,monomial.ordering);
	}

	void next() {
		while(true) {
			if(monomial.multiple(current())) break;
			increment();
		}
	}

	boolean carry() {
		return carry;
	}

	void increment() {
		increment(true);
	}

	void increment(boolean flag) {
		process(0);
		if(flag && current().compareTo(monomial)>0) {
			reset();
			carry=true;
		} else carry=false;
	}

	void process(int n) {
		if(n<element.length) {
			if(element[n]==0) {
				process(n+1);
			} else {
				int i=element[n];
				element[n]=0;
				element[0]=i-1;
				if(n+1<element.length) {
					element[n+1]++;
				} else {
					element[0]+=2;
					degree++;
				}
			}
		} else {
			element[0]++;
			degree++;
		}
	}

	void reset() {
		for(int i=0;i<element.length;i++) element[i]=0;
		degree=0;
	}
}

class CandidateCoefficient {
	Arithmetic arithmetic;
	Arithmetic current;
	boolean sign;
	boolean carry;

	CandidateCoefficient(Arithmetic arithmetic) {
		sign=arithmetic.signum()<0;
		if(sign) arithmetic=arithmetic.negate();
		this.arithmetic=arithmetic;
		current=JSCLInteger.valueOf(1);
	}

	Arithmetic current() {
		return current;
	}

	boolean carry() {
		return carry;
	}

	void increment() {
		if(process()) {
			reset();
			carry=true;
		} else carry=false;
	}

	boolean process() {
		while(current.compareTo(arithmetic)<0) {
			current=current.add(JSCLInteger.valueOf(1));
			if(arithmetic.multiple(current)) return false;
		}
		return true;
	}

	void reset() {
		current=JSCLInteger.valueOf(1);
	}
}
