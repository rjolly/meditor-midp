package jscl.math;

public class NotPowerException extends ArithmeticException {
	public NotPowerException() {}

	public NotPowerException(String s) {
		super(s);
	}
}
