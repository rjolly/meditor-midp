package jscl.math;

import java.util.*;
import jscl.math.function.*;
import jscl.util.*;

public class Simplification {
	Betatree cache=new Betatree();
	Arithmetic result;
	Vector constraint;
	boolean simple;

	public void compute(Arithmetic arithmetic) {
		Debug.println("simplification");
		Debug.increment();
		Variable t=new TechnicalVariable("t");
		simple=false;
		constraint=new Vector();
		process(new Constraint(t,t.expressionValue().subtract(arithmetic),false));
		UnivariatePolynomial p=polynomial(t);
		switch(p.degree()) {
		case 0:
			result=arithmetic;
			break;
		case 1:
			result=new Root(p,0).evaluate();
			break;
		case 2:
			int n=branch(arithmetic,p);
			if(n<p.degree()) simple(new Root(p,n).expressionValue());
			else simple(arithmetic);
			break;
		default:
			simple(arithmetic);
		}
		Debug.decrement();
	}

	void simple(Arithmetic arithmetic) {
		Variable t=new TechnicalVariable("t");
		simple=true;
		constraint.removeAllElements();
		process(new Constraint(t,t.expressionValue().subtract(arithmetic),false));
		UnivariatePolynomial p=polynomial(t);
		switch(p.degree()) {
		case 0:
			result=arithmetic;
			break;
		default:
			result=new Root(p,0).evaluate();
		}
	}

	int branch(Arithmetic arithmetic, UnivariatePolynomial polynomial) {
		int n=polynomial.degree();
		Variable t=new TechnicalVariable("t");
		simple=true;
		for(int i=0;i<n;i++) {
			constraint.removeAllElements();
			process(new Constraint(t,t.expressionValue().subtract(arithmetic.subtract(new Root(polynomial,i).expressionValue())),false));
			Arithmetic a=polynomial(t).solve();
			if(a!=null?a.signum()==0:false) return i;
		}
		return n;
	}

	UnivariatePolynomial polynomial(Variable t) {
		int n=constraint.size();
		Arithmetic a[]=new Arithmetic[n];
		boolean r[]=new boolean[n];
		Variable in[]=new Variable[n];
		int j=0;
		for(int i=0;i<n;i++) {
			Constraint co=(Constraint)constraint.elementAt(i);
			a[i]=co.arithmetic;
			r[i]=co.reduce && simple;
			if(r[i]) in[j++]=co.unknown;
		}
		int k=j;
		for(int i=0;i<n;i++) {
			Constraint co=(Constraint)constraint.elementAt(i);
			if(!r[i]) in[k++]=co.unknown;
		}
		in=Basis.augmentUnknown(in,a);
		Basis basis=new SimplificationBasis(a,r,in,Monomial.lexicographic,0);
		basis.compute();
		return UnivariatePolynomial.valueOf(basis.get(j),t);
	}

	void process(Constraint co) {
		constraint.addElement(co);
		Literal l=Expression.valueOf(co.arithmetic).variables();
		Enumeration k=l.content.keys();
		while(k.hasMoreElements()) {
			Variable v=(Variable)k.nextElement();
			if(constraint.contains(new Constraint(v))) continue;
			co=null;
			if(v instanceof Frac) {
				Function f=(Function)v;
				co=new Constraint(v,f.expressionValue().multiply(f.parameter[1]).subtract(f.parameter[0]),false);
			} else if(v instanceof Sqrt) {
				Function f=(Function)v;
				if(simple) co=simpleConstraint(v);
				if(co==null) co=new Constraint(v,f.expressionValue().pow(2).subtract(f.parameter[0]),true);
			} else if(v instanceof Root) {
				try {
					Root f=(Root)v;
					int d=f.degree();
					int n=f.subscript().integerValue().intValue();
					if(simple) co=simpleConstraint(v);
					if(co==null) co=new Constraint(v,Root.sigma(f.parameter,d-n).multiply(JSCLInteger.valueOf(-1).pow(d-n)).multiply(f.parameter[d]).subtract(f.parameter[n]),d>1);
				} catch (NotIntegerException e) {
					co=simpleConstraint(v);
				}
			} else if(v instanceof Pow) {
				try {
					Pow f=(Pow)v;
					Root r=f.rootValue();
					int d=r.degree();
					Arithmetic a=r.parameter[0].negate();
					if(simple) co=simpleConstraint(v);
					if(co==null) co=new Constraint(v,f.expressionValue().pow(d).subtract(a),d>1);
				} catch (NotRootException e) {
					co=simpleConstraint(v);
				}
			} else co=simpleConstraint(v);
			if(co!=null) process(co);
		}
	}

	Constraint simpleConstraint(Variable v) {
		Arithmetic s;
		if(cache.containsKey(v)) s=(Arithmetic)cache.get(v);
		else {
			s=v.simplify();
			cache.put(v,s);
		}
		Arithmetic a=v.expressionValue().subtract(s);
		if(a.signum()!=0) return new Constraint(v,a,false);
		else return null;
	}

	public Arithmetic getValue() {
		return result;
	}
}

class Constraint {
	Variable unknown;
	Arithmetic arithmetic;
	boolean reduce;

	Constraint(Variable unknown, Arithmetic arithmetic, boolean reduce) {
		this.unknown=unknown;
		this.arithmetic=arithmetic;
		this.reduce=reduce;
	}

	Constraint(Variable unknown) {
		this(unknown,null,false);
	}

	public boolean equals(Object obj) {
		return unknown.compareTo(((Constraint)obj).unknown)==0;
	}
}

class SimplificationBasis extends Basis {
	Vector reducer=new Vector();

	public SimplificationBasis(Arithmetic arithmetic[], boolean reduce[], Variable unknown[], jscl.util.Comparator ordering, int modulo) {
		super(new Arithmetic[0],unknown,ordering,modulo);
		for(int i=0;i<arithmetic.length;i++) {
			PolynomialWithSugar p=polynomial(arithmetic[i]);
			if(p.signum()!=0) {
				if(reduce[i]) reducer.addElement(p);
				makePairs(p);
				put(p);
			}
		}
	}

	void makePairs(PolynomialWithSugar polynomial) {
		if(reducer.contains(polynomial)) return;
		int n=content.size();
		for(int i=0;i<n;i++) {
			PolynomialWithSugar p=(PolynomialWithSugar)content.elementAt(i);
			if(reducer.contains(p)) continue;
			Pair pa=new Pair(p,polynomial);
			if(!a_criterion(pa)) pairs.put(pa,null);
		}
	}
}
