package jscl.math;

import java.util.*;
import jscl.util.*;

public class Basis {
	final Variable unknown[];
	final jscl.util.Comparator ordering;
	final int modulo;
	final Vector content=new Vector();
	Betatree pairs=new Betatree();
	Vector removed=new Vector();

	public Basis(Arithmetic arithmetic[], Variable unknown[], jscl.util.Comparator ordering, int modulo) {
		this.unknown=unknown;
		this.ordering=ordering;
		this.modulo=modulo;
		for(int i=0;i<arithmetic.length;i++) {
			PolynomialWithSugar p=polynomial(arithmetic[i]);
			if(p.signum()!=0) {
				makePairs(p);
				put(p);
			}
		}
	}

	PolynomialWithSugar polynomial(Arithmetic arithmetic) {
		PolynomialWithSugar p=new PolynomialWithSugar(unknown,ordering,modulo);
		p.put(arithmetic);
		Enumeration k=p.content.keys();
		while(k.hasMoreElements()) {
			Monomial m=(Monomial)k.nextElement();
			p.sugar=Math.max(p.sugar,m.degree());
		}
		return (PolynomialWithSugar)p.normalize();
	}

	public static Variable[] augmentUnknown(Variable unknown[], Arithmetic arithmetic[]) {
		Vector w=new Vector();
		for(int i=0;i<unknown.length;i++) {
			w.addElement(unknown[i]);
		}
		Literal l=new Literal();
		for(int i=0;i<arithmetic.length;i++) {
			l=l.scm(Expression.valueOf(arithmetic[i]).variables());
		}
		int index=0;
		Enumeration k=l.content.keys();
		while(k.hasMoreElements()) {
			Variable v=(Variable)k.nextElement();
			if(w.contains(v));
			else w.insertElementAt(v,index++);
		}
		Variable in[]=new Variable[w.size()];
		w.copyInto(in);
		return in;
	}

	public void compute() {
		Debug.println(this);
		while(!pairs.isEmpty()) {
			Pair pa=(Pair)pairs.keys().nextElement();
			if(!b_criterion(pa)) {
				Debug.println(pa);
				Debug.increment();
				PolynomialWithSugar p=pa.polynomial[0].s_polynomial(pa.polynomial[1]);
				p=(PolynomialWithSugar)p.reduceCompletely(content).normalize();
				if(p.signum()!=0) {
					Debug.println(p.principal());
					makePairs(p);
					put(p);
				}
				Debug.decrement();
			}
			try {
				pa.polynomial[1].principal().divide(pa.polynomial[0].principal());
				removed.addElement(pa.polynomial[1]);
			} catch (NotDivisibleException ex) {}
			pairs.remove(pa);
		}
		reduce();
		sort();
	}

	void makePairs(PolynomialWithSugar polynomial) {
		int n=content.size();
		for(int i=0;i<n;i++) {
			PolynomialWithSugar p=(PolynomialWithSugar)content.elementAt(i);
			Pair pa=new Pair(p,polynomial);
			if(!a_criterion(pa)) pairs.put(pa,null);
		}
	}

	boolean a_criterion(Pair pair) {
		return pair.polynomial[0].principal().gcd(pair.polynomial[1].principal()).degree()==0;
	}

	boolean b_criterion(Pair pair) {
		int n=content.size();
		for(int i=0;i<n;i++) {
			PolynomialWithSugar p=(PolynomialWithSugar)content.elementAt(i);
			try {
				pair.scm.divide(p.principal());
				Pair pa1=new Pair(pair.polynomial[0],p);
				Pair pa2=new Pair(p,pair.polynomial[1]);
				if(!pairs.containsKey(pa1) && !pairs.containsKey(pa2)) return true;
			} catch (NotDivisibleException ex) {}
		}
		return false;
	}

	void reduce() {
		Debug.println("reduce");
		int n=removed.size();
		for(int i=0;i<n;i++) {
			PolynomialWithSugar p=(PolynomialWithSugar)removed.elementAt(i);
			content.removeElement(p);
		}
		n=content.size();
		loop: while(true) {
			for(int i=0;i<n;) {
				PolynomialWithSugar p=(PolynomialWithSugar)content.elementAt(i);
				Monomial m=p.principal();
				content.removeElementAt(i);
				p=(PolynomialWithSugar)p.reduceCompletely(content).normalize();
				if(p.signum()!=0) {
					Debug.println(p.principal());
					if(p.principal().compareTo(m)==0) {
						content.insertElementAt(p,i++);
					} else {
						put(p);
						continue loop;
					}
				} else n--;
			}
			break;
		}
	}

	void put(PolynomialWithSugar p) {
		content.insertElementAt(p,p.degree()>0?index(p,SaccharineComparator.comparator):0);
	}

	void sort() {
		Vector v=new Vector();
		int n=content.size();
		for(int i=0;i<n;i++) {
			PolynomialWithSugar p=(PolynomialWithSugar)content.elementAt(i);
			v.addElement(p);
		}
		content.removeAllElements();
		for(int i=0;i<n;i++) {
			PolynomialWithSugar p=(PolynomialWithSugar)v.elementAt(i);
			content.insertElementAt(p,index(p,GenericComparator.comparator));
		}
	}

	int index(PolynomialWithSugar polynomial, jscl.util.Comparator comparator) {
		int n=content.size();
		for(int i=0;i<n;i++) {
			PolynomialWithSugar p=(PolynomialWithSugar)content.elementAt(i);
			if(comparator.compare(p,polynomial)>0) return i;
		}
		return n;
	}

	public int size() {
		return content.size();
	}

	public Expression get(int n) {
		return Expression.valueOf((Arithmetic)content.elementAt(n));
	}

	public String toString() {
		StringBuffer buffer=new StringBuffer();
		Arithmetic a[]=new Arithmetic[content.size()];
		content.copyInto(a);
		buffer.append(new JSCLVector(a));
		buffer.append(", {");
		for(int i=0;i<unknown.length;i++) {
			buffer.append(unknown[i]).append(i<unknown.length-1?", ":"");
		}
		buffer.append("}");
		return buffer.toString();
	}
}

class SaccharineComparator extends jscl.util.Comparator {
	public static final jscl.util.Comparator comparator=new SaccharineComparator();

	private SaccharineComparator() {}

	public int compare(Object o1, Object o2) {
		PolynomialWithSugar p1=(PolynomialWithSugar)o1;
		PolynomialWithSugar p2=(PolynomialWithSugar)o2;
		int c1=p1.saccharine();
		int c2=p2.saccharine();
		if(c1<c2) return -1;
		else if(c1>c2) return 1;
		else {
			int c=p1.compareTo(p2);
			if(c<0) return -1;
			else if(c>0) return 1;
			else return 0;
		}
	}
}

class Pair implements jscl.util.Comparable {
	PolynomialWithSugar polynomial[];
	Monomial scm;
	int sugar;

	Pair(PolynomialWithSugar p1, PolynomialWithSugar p2) {
		this(p1.compareTo(p2)>0?new PolynomialWithSugar[] {p2,p1}:new PolynomialWithSugar[] {p1,p2});
	}

	Pair(PolynomialWithSugar polynomial[]) {
		this.polynomial=polynomial;
		scm=polynomial[0].principal().scm(polynomial[1].principal());
		sugar=Math.max(polynomial[0].saccharine(),polynomial[1].saccharine())+scm.degree();
	}

	public int compareTo(jscl.util.Comparable comparable) {
		Pair pa=(Pair)comparable;
		if(sugar<pa.sugar) return -1;
		else if(sugar>pa.sugar) return 1;
		else {
			int c=scm.compareTo(pa.scm);
			if(c<0) return -1;
			else if(c>0) return 1;
			else {
				c=polynomial[1].compareTo(pa.polynomial[1]);
				if(c<0) return -1;
				else if(c>0) return 1;
				else {
					c=polynomial[0].compareTo(pa.polynomial[0]);
					if(c<0) return -1;
					else if(c>0) return 1;
					else return 0;
				}
			}
		}
	}

	public String toString() {
		return "{"+polynomial[0].principal()+", "+polynomial[1].principal()+"}, "+sugar;
	}
}

class PolynomialWithSugar extends Polynomial {
	int sugar;

	PolynomialWithSugar(Variable unknown[], jscl.util.Comparator ordering, int modulo) {
		super(unknown,ordering,modulo);
	}

	public Arithmetic multiply(Arithmetic arithmetic) {
		PolynomialWithSugar p=(PolynomialWithSugar)super.multiply(arithmetic);
		p.sugar=sugar;
		return p;
	}

	public Arithmetic divide(Arithmetic arithmetic) throws ArithmeticException {
		PolynomialWithSugar p=(PolynomialWithSugar)super.divide(arithmetic);
		p.sugar=sugar;
		return p;
	}

	public Arithmetic valueof(Arithmetic arithmetic) {
		PolynomialWithSugar p=(PolynomialWithSugar)super.valueof(arithmetic);
		p.sugar=((PolynomialWithSugar)arithmetic).sugar;
		return p;
	}

	PolynomialWithSugar s_polynomial(PolynomialWithSugar polynomial) {
		Monomial m1=principal();
		Arithmetic c1=headCoefficient();
		Monomial m2=polynomial.principal();
		Arithmetic c2=polynomial.headCoefficient();
		Monomial m=(Monomial)m1.scm(m2);
		m1=(Monomial)m.divide(m1);
		m2=(Monomial)m.divide(m2);
		Arithmetic c=c1.scm(c2);
		c1=c.divide(c1);
		c2=c.divide(c2);
		PolynomialWithSugar p=multiply(m1,c1);
		p.reduce(JSCLInteger.valueOf(1),polynomial,m2,c2);
		return p;
	}

	PolynomialWithSugar multiply(Monomial m1, Arithmetic c1) {
		PolynomialWithSugar p=(PolynomialWithSugar)newinstance();
		Enumeration k=content.keys();
		Enumeration e=content.elements();
		while(k.hasMoreElements()) {
			p.put(
				(Monomial)((Monomial)k.nextElement()).multiply(m1),
				((Arithmetic)e.nextElement()).multiply(c1)
			);
		}
		p.sugar=sugar+m1.degree();
		return p;
	}

	PolynomialWithSugar reduce(Vector vector) {
		PolynomialWithSugar p=(PolynomialWithSugar)valueof(this);
		int n=vector.size();
		loop: while(p.signum()!=0) {
			Monomial m1=p.principal();
			Arithmetic c1=p.headCoefficient();
			for(int i=0;i<n;i++) {
				PolynomialWithSugar q=(PolynomialWithSugar)vector.elementAt(i);
				Monomial m2=q.principal();
				Arithmetic c2=q.headCoefficient();
				try {
					Monomial m=(Monomial)m1.divide(m2);
					Arithmetic c=c1.scm(c2);
					c1=c.divide(c1);
					c2=c.divide(c2);
					p.reduce(c1,q,m,c2);
					continue loop;
				} catch (NotDivisibleException ex) {}
			}
			break;
		}
		return p;
	}

	PolynomialWithSugar reduceCompletely(Vector vector) {
		PolynomialWithSugar p=(PolynomialWithSugar)valueof(this);
		int n=vector.size();
		Monomial l=null;
		loop: while(p.signum()!=0) {
			Enumeration k=p.content.keys(true);
			Enumeration e=p.content.elements(true);
			while(k.hasMoreElements()) {
				Monomial m1=(Monomial)k.nextElement();
				Arithmetic c1=(Arithmetic)e.nextElement();
				if(l==null?false:m1.compareTo(l)>0) continue;
				for(int i=0;i<n;i++) {
					PolynomialWithSugar q=(PolynomialWithSugar)vector.elementAt(i);
					Monomial m2=q.principal();
					Arithmetic c2=q.headCoefficient();
					try {
						Monomial m=(Monomial)m1.divide(m2);
						Arithmetic c=c1.scm(c2);
						c1=c.divide(c1);
						c2=c.divide(c2);
						p.reduce(c1,q,m,c2);
						l=m1;
						continue loop;
					} catch (NotDivisibleException ex) {}
				}
			}
			break;
		}
		return p;
	}

	void reduce(Arithmetic c1, PolynomialWithSugar p2, Monomial m2, Arithmetic c2) {
		if(c1.compareTo(JSCLInteger.valueOf(1))==0);
		else {
			Enumeration k=content.keys();
			Enumeration e=content.elements();
			while(k.hasMoreElements()) {
				content.put(
					(Monomial)k.nextElement(),
					((Arithmetic)e.nextElement()).multiply(c1)
				);
			}
		}
		Enumeration k=p2.content.keys();
		Enumeration e=p2.content.elements();
		while(k.hasMoreElements()) {
			put(
				(Monomial)((Monomial)k.nextElement()).multiply(m2),
				((Arithmetic)e.nextElement()).multiply(c2).negate()
			);
		}
		sugar=Math.max(sugar,p2.sugar+m2.degree());
	}

	Monomial principal() {
		return (Monomial)content.keys(true).nextElement();
	}

	Arithmetic headCoefficient() {
		return (Arithmetic)content.elements(true).nextElement();
	}

	int saccharine() {
		return sugar-degree;
	}

	public int compareTo(jscl.util.Comparable comparable) {
		if(this==comparable) return 0;
		return super.compareTo(comparable);
	}

	protected Arithmetic newinstance() {
		return new PolynomialWithSugar(unknown,ordering,modulo);
	}
}
