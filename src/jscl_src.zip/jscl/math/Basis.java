package jscl.math;

import java.util.*;

public class Basis {
	final Variable unknown[];
	final Comparator ordering;
	final int modulo;
	final Vector content=new Vector();
	final SortedMap pairs=new TreeMap();

	public Basis(Arithmetic arithmetic[], Variable unknown[], Comparator ordering, int modulo) {
		this.unknown=unknown;
		this.ordering=ordering;
		this.modulo=modulo;
		for(int i=0;i<arithmetic.length;i++) {
			Polynomial p=polynomial(arithmetic[i]).normalize();
			if(p.signum()!=0) {
				int n=put(p);
				makePairs(n);
			}
		}
	}

	public Polynomial polynomial(Arithmetic arithmetic) {
		return MultivariatePolynomial.valueOf(arithmetic,unknown,ordering,modulo);
	}

	public static Variable[] augmentUnknown(Variable unknown[], Arithmetic arithmetic[]) {
		Vector w=new Vector();
		for(int i=0;i<unknown.length;i++) {
			w.addElement(unknown[i]);
		}
		int index=0;
		for(int i=0;i<arithmetic.length;i++) {
			Variable va[]=arithmetic[i].variables();
			for(int j=0;j<va.length;j++) {
				Variable v=va[j];
				if(w.contains(v));
				else w.insertElementAt(v,index++);
			}
		}
		Variable in[]=new Variable[w.size()];
		w.copyInto(in);
		return in;
	}

	public void compute() {
		Debug.println(this);
		while(!pairs.isEmpty()) {
			Pair pa=(Pair)pairs.firstKey();
			if(!b_criterion(pa)) {
				Debug.println(pa);
				Debug.increment();
				Polynomial p=pa.get(1).s_polynomial(pa.get(0)).reduceCompletely(this);
				if(p.signum()!=0) {
					if(p.degree()==0) {
						content.removeAllElements();
						pairs.clear();
						pairs.put(pa,null);
					}
					int n=put(p);
					makePairs(n);
				}
				Debug.decrement();
			}
			pairs.remove(pa);
		}
		reduce();
		sort();
	}

	int put(Polynomial polynomial) {
		int n=content.size();
		Debug.println(polynomial.headMonomial()+" ("+n+")");
		content.addElement(polynomial);
		return n;
	}

	void makePairs(int n) {
		for(int i=0;i<n;i++) {
			Pair pa=pair(new int[] {i,n});
			if(!a_criterion(pa)) pairs.put(pa,null);
		}
	}

	Pair pair(int index[]) {
		return new Pair(this,index);
	}

	Pair pair(int index1, int index2) {
		return pair(index1>index2?new int[] {index2,index1}:new int[] {index1,index2});
	}

	boolean a_criterion(Pair pair) {
		return pair.monomial(0).gcd(pair.monomial(1)).degree()==0;
	}

	boolean b_criterion(Pair pair) {
		int n=content.size();
		for(int i=0;i<n;i++) {
			Polynomial p=get(i);
			if(pair.scm.multiple(p.headMonomial())) {
				Pair pa1=pair(pair.index[0],i);
				Pair pa2=pair(i,pair.index[1]);
				if(!pairs.containsKey(pa1) && !pairs.containsKey(pa2)) return true;
			}
		}
		return false;
	}

	void reduce() {
		Debug.println("reduce");
		int n=content.size();
		for(int i=0;i<n;) {
			Polynomial p=get(i);
			content.removeElementAt(i);
			p=p.reduceCompletely(this);
			if(p.signum()!=0) {
				Debug.println(p.headMonomial());
				content.insertElementAt(p,i++);
			} else n--;
		}
	}

	void sort() {
		Vector v=new Vector();
		int n=content.size();
		for(int i=0;i<n;i++) {
			Polynomial p=get(i);
			v.addElement(p);
		}
		content.removeAllElements();
		for(int i=0;i<n;i++) {
			Polynomial p=(Polynomial)v.elementAt(i);
			content.insertElementAt(p,index(p));
		}
	}

	int index(Polynomial polynomial) {
		int n=content.size();
		for(int i=0;i<n;i++) {
			Polynomial p=get(i);
			if(p.compareTo(polynomial)>0) return i;
		}
		return n;
	}

	public int size() {
		return content.size();
	}

	public Polynomial get(int index) {
		return (Polynomial)content.elementAt(index);
	}

	public String toString() {
		StringBuffer buffer=new StringBuffer();
		buffer.append("{");
		int n=size();
		for(int i=0;i<n;i++) {
			buffer.append(get(i)).append(i<n-1?", ":"");
		}
		buffer.append("}, {");
		for(int i=0;i<unknown.length;i++) {
			buffer.append(unknown[i]).append(i<unknown.length-1?", ":"");
		}
		buffer.append("}");
		return buffer.toString();
	}
}

class Pair implements Comparable {
	Basis basis;
	int index[];
	Monomial scm;
	int sugar;
	boolean multiple;

	Pair(Basis basis, int index[]) {
		this.basis=basis;
		this.index=index;
		Polynomial p1=basis.get(index[0]);
		Polynomial p2=basis.get(index[1]);
		Monomial m1=p1.headMonomial();
		Monomial m2=p2.headMonomial();
		scm=m1.scm(m2);
		sugar=Math.max(saccharine(p1),saccharine(p2))+scm.degree();
		multiple=m1.compareTo(m2)>0?m1.multiple(m2):m2.multiple(m1);
	}

	static int saccharine(Polynomial polynomial) {
		return polynomial.sugar()-polynomial.degree();
	}

	Polynomial get(int n) {
		return basis.get(index[n]);
	}

	Monomial monomial(int n) {
		return basis.get(index[n]).headMonomial();
	}

	public int compareTo(Object comparable) {
		Pair pa=(Pair)comparable;
		if(sugar<pa.sugar) return -1;
		else if(sugar>pa.sugar) return 1;
		else {
			int c=scm.compareTo(pa.scm);
			if(c<0) return -1;
			else if(c>0) return 1;
			else {
				if(index[1]<pa.index[1]) return -1;
				else if(index[1]>pa.index[1]) return 1;
				else {
					if(index[0]<pa.index[0]) return -1;
					else if(index[0]>pa.index[0]) return 1;
					else return 0;
				}
			}
		}
	}

	public String toString() {
		return "{"+index[0]+", "+index[1]+"}, "+sugar+", "+multiple;
	}
}
