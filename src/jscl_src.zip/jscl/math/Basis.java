package jscl.math;

import java.util.*;

public class Basis {
	final Variable unknown[];
	final Comparator ordering;
	final int modulo;
	final Map content=new TreeMap(IndexComparator.comparator);
	SortedMap pairs=new TreeMap();
	int index;

	public Basis(Arithmetic arithmetic[], Variable unknown[], Comparator ordering, int modulo) {
		this.unknown=unknown;
		this.ordering=ordering;
		this.modulo=modulo;
		for(int i=0;i<arithmetic.length;i++) {
			Polynomial p=polynomial(arithmetic[i]).normalize();
			if(p.signum()!=0) {
				put(p);
			}
		}
	}

	public Polynomial polynomial(Arithmetic arithmetic) {
		return MultivariatePolynomial.valueOf(arithmetic,unknown,ordering,modulo);
	}

	public static Variable[] augmentUnknown(Variable unknown[], Arithmetic arithmetic[]) {
		Vector w=new Vector();
		for(int i=0;i<unknown.length;i++) {
			w.addElement(unknown[i]);
		}
		int n=0;
		for(int i=0;i<arithmetic.length;i++) {
			Variable va[]=arithmetic[i].variables();
			for(int j=0;j<va.length;j++) {
				Variable v=va[j];
				if(w.contains(v));
				else w.insertElementAt(v,n++);
			}
		}
		Variable in[]=new Variable[w.size()];
		w.copyInto(in);
		return in;
	}

	public void compute() {
		Debug.println(this);
		while(!pairs.isEmpty()) {
			Pair pa=(Pair)pairs.firstKey();
			if(!b_criterion(pa)) {
				Debug.println(pa);
				Debug.increment();
				Polynomial p=s_polynomial(pa).reduceCompletely(this);
				if(p.signum()!=0) {
					if(p.degree()==0) {
						content.clear();
						pairs.clear();
						pairs.put(pa,null);
					}
					put(p);
				}
				Debug.decrement();
			}
			pairs.remove(pa);
		}
		reduce();
	}

	Polynomial s_polynomial(Pair pair) {
		Polynomial p1=(Polynomial)content.get(pair.handle[1]);
		Polynomial p2=(Polynomial)content.get(pair.handle[0]);
		return p1.s_polynomial(p2);
	}

	public void put(Polynomial polynomial) {
		Handle h=new Handle(polynomial,index++);
		makePairs(h);
		Debug.println(h);
		content.put(h,polynomial);
	}

	void makePairs(Handle handle) {
		Iterator it=content.keySet().iterator();
		while(it.hasNext()) {
			Handle h=(Handle)it.next();
			Pair pa=new Pair(new Handle[] {h,handle});
			if(!a_criterion(pa)) pairs.put(pa,null);
		}
	}

	boolean a_criterion(Pair pair) {
		return pair.handle[0].monomial.gcd(pair.handle[1].monomial).degree()==0;
	}

	boolean b_criterion(Pair pair) {
		Iterator it=content.keySet().iterator();
		while(it.hasNext()) {
			Handle h=(Handle)it.next();
			if(pair.scm.multiple(h.monomial)) {
				Pair pa1=new Pair(pair.handle[0],h);
				Pair pa2=new Pair(h,pair.handle[1]);
				if(!pairs.containsKey(pa1) && !pairs.containsKey(pa2)) return true;
			}
		}
		return false;
	}

	void reduce() {
		Debug.println("reduce");
		Map map=newTreeMap(content);
		Iterator it=map.entrySet().iterator();
		while(it.hasNext()) {
			Map.Entry e=(Map.Entry)it.next();
			Handle h=(Handle)e.getKey();
			Polynomial p=(Polynomial)e.getValue();
			content.remove(h);
			p=p.reduceCompletely(this);
			if(p.signum()!=0) {
				Debug.println(h);
				content.put(h,p);
			}
		}
	}

	static Map newTreeMap(Map map) {
		Map m=new TreeMap();
		Iterator it=map.entrySet().iterator();
		while(it.hasNext()) {
			Map.Entry e=(Map.Entry)it.next();
			m.put(e.getKey(),e.getValue());
		}
		return m;
	}

	public Polynomial[] elements() {
		Map map=newTreeMap(content);
		Polynomial p[]=new Polynomial[map.size()];
		Iterator it=map.values().iterator();
		for(int i=0;it.hasNext();i++) {
			p[i]=(Polynomial)it.next();
		}
		return p;
	}

	public String toString() {
		StringBuffer buffer=new StringBuffer();
		Polynomial b[]=elements();
		buffer.append("{");
		for(int i=0;i<b.length;i++) {
			buffer.append(b[i]).append(i<b.length-1?", ":"");
		}
		buffer.append("}, {");
		for(int i=0;i<unknown.length;i++) {
			buffer.append(unknown[i]).append(i<unknown.length-1?", ":"");
		}
		buffer.append("}");
		return buffer.toString();
	}
}

class Pair implements Comparable {
	Handle handle[];
	Monomial scm;
	int sugar;

	Pair(Handle handle[]) {
		this.handle=handle;
		scm=handle[0].monomial.scm(handle[1].monomial);
		sugar=Math.max(handle[0].saccharine,handle[1].saccharine)+scm.degree();
	}

	Pair(Handle handle1, Handle handle2) {
		this(handle1.index<handle2.index?new Handle[] {handle1,handle2}:new Handle[] {handle2,handle1});
	}

	boolean multiple() {
		return handle[0].monomial.compareTo(handle[1].monomial)<0?multiple(1):multiple(0);
	}

	boolean multiple(int n) {
		return handle[n].monomial.multiple(handle[(n+1)%2].monomial);
	}

	public int compareTo(Object comparable) {
		Pair pa=(Pair)comparable;
		if(sugar<pa.sugar) return -1;
		else if(sugar>pa.sugar) return 1;
		else {
			int c=scm.compareTo(pa.scm);
			if(c<0) return -1;
			else if(c>0) return 1;
			else {
				c=IndexComparator.comparator.compare(handle[1],pa.handle[1]);
				if(c<0) return -1;
				else if(c>0) return 1;
				else {
					c=IndexComparator.comparator.compare(handle[0],pa.handle[0]);
					if(c<0) return -1;
					else if(c>0) return 1;
					else return 0;
				}
			}
		}
	}

	public String toString() {
		return "{"+handle[0].index+", "+handle[1].index+"}, "+sugar+", "+multiple();
	}
}

class Handle implements Comparable {
	Monomial monomial;
	int saccharine;
	int index;

	Handle(Polynomial polynomial, int index) {
		monomial=polynomial.headMonomial();
		saccharine=polynomial.sugar()-polynomial.degree();
		this.index=index;
	}

	public int compareTo(Object comparable) {
		Handle h=(Handle)comparable;
		int c=monomial.compareTo(h.monomial);
		if(c<0) return -1;
		else if(c>0) return 1;
		else return IndexComparator.comparator.compare(this,h);
	}

	public String toString() {
		return "("+monomial+", "+saccharine+", "+index+")";
	}
}

class IndexComparator implements Comparator {
	public static final Comparator comparator=new IndexComparator();

	private IndexComparator() {}

	public int compare(Object o1, Object o2) {
		Handle h1=(Handle)o1;
		Handle h2=(Handle)o2;
		if(h1.index<h2.index) return -1;
		else if(h1.index>h2.index) return 1;
		else return 0;
	}
}
