package jscl.math;

import java.util.*;

public class Basis {
	final Variable unknown[];
	final Comparator ordering;
	final int modulo;
	final Vector content=new Vector();
	final TreeMap pairs=new TreeMap();

	public Basis(Arithmetic arithmetic[], Variable unknown[], Comparator ordering, int modulo) {
		this.unknown=unknown;
		this.ordering=ordering;
		this.modulo=modulo;
		for(int i=0;i<arithmetic.length;i++) {
			PolynomialWithSugar p=polynomial(arithmetic[i]);
			if(p.signum()!=0) {
				makePairs(p);
				put(p);
			}
		}
	}

	PolynomialWithSugar polynomial(Arithmetic arithmetic) {
		PolynomialWithSugar p=new PolynomialWithSugar(unknown,ordering,modulo);
		p.put(arithmetic);
		Iterator it=p.content.keySet().iterator();
		while(it.hasNext()) {
			Monomial m=(Monomial)it.next();
			p.sugar=Math.max(p.sugar,m.degree());
		}
		return (PolynomialWithSugar)p.normalize();
	}

	public static Variable[] augmentUnknown(Variable unknown[], Arithmetic arithmetic[]) {
		Vector w=new Vector();
		for(int i=0;i<unknown.length;i++) {
			w.addElement(unknown[i]);
		}
		Literal l=new Literal();
		for(int i=0;i<arithmetic.length;i++) {
			l=l.scm(Expression.valueOf(arithmetic[i]).variables());
		}
		int index=0;
		Iterator it=l.content.keySet().iterator();
		while(it.hasNext()) {
			Variable v=(Variable)it.next();
			if(w.contains(v));
			else w.insertElementAt(v,index++);
		}
		Variable in[]=new Variable[w.size()];
		w.copyInto(in);
		return in;
	}

	public void compute() {
		Debug.println(this);
		Vector removed=new Vector();
		while(!pairs.isEmpty()) {
			Pair pa=(Pair)pairs.firstKey();
			if(!b_criterion(pa)) {
				Debug.println(pa);
				Debug.increment();
				PolynomialWithSugar p=pa.polynomial[1].s_polynomial(pa.polynomial[0]);
				p=(PolynomialWithSugar)p.reduceCompletely(content);
				if(p.signum()!=0) {
					Debug.println(p.principal());
					makePairs(p);
					put(p);
				}
				Debug.decrement();
			}
			if(pa.multiple) {
				removed.addElement(pa.polynomial[1]);
//				content.removeElement(pa.polynomial[1]);
//				removePairs(pa.polynomial[1]);
			}
			pairs.remove(pa);
		}
		int n=removed.size();
		for(int i=0;i<n;i++) {
			PolynomialWithSugar p=(PolynomialWithSugar)removed.elementAt(i);
			content.removeElement(p);
		}
		reduce();
		sort();
	}

	void makePairs(PolynomialWithSugar polynomial) {
//		polynomial.index=content.size();
		int n=content.size();
		for(int i=0;i<n;i++) {
			PolynomialWithSugar p=(PolynomialWithSugar)content.elementAt(i);
			Pair pa=new Pair(p,polynomial);
			if(!a_criterion(pa)) pairs.put(pa,null);
		}
	}
/*
	void removePairs(PolynomialWithSugar polynomial) {
		for(Iterator it=pairs.keySet().iterator();it.hasNext();) {
			Pair pa=(Pair)it.next();
			if(pa.polynomial[0].compareTo(polynomial)==0 || pa.polynomial[1].compareTo(polynomial)==0) it.remove();
		}
	}
*/
	boolean a_criterion(Pair pair) {
		return pair.polynomial[0].principal().gcd(pair.polynomial[1].principal()).degree()==0;
	}

	boolean b_criterion(Pair pair) {
		int n=content.size();
		for(int i=0;i<n;i++) {
			PolynomialWithSugar p=(PolynomialWithSugar)content.elementAt(i);
			if(pair.scm.multiple(p.principal())) {
				Pair pa1=new Pair(pair.polynomial[0],p);
				Pair pa2=new Pair(p,pair.polynomial[1]);
				if(!pairs.containsKey(pa1) && !pairs.containsKey(pa2)) return true;
			}
		}
		return false;
	}
/*
	void reduce() {
		Debug.println("reduce");
		int n=content.size();
		for(int i=0;i<n;) {
			PolynomialWithSugar p=(PolynomialWithSugar)content.elementAt(i);
			content.removeElementAt(i);
			p=(PolynomialWithSugar)p.reduceCompletely(content);
			if(p.signum()!=0) {
				Debug.println(p.principal());
				content.insertElementAt(p,i++);
			} else n--;
		}
	}
*/
	void reduce() {
		Debug.println("reduce");
		int n=content.size();
		loop: while(true) {
			for(int i=0;i<n;) {
				PolynomialWithSugar p=(PolynomialWithSugar)content.elementAt(i);
				Monomial m=p.principal();
				content.removeElementAt(i);
				p=(PolynomialWithSugar)p.reduceCompletely(content);
				if(p.signum()!=0) {
					Debug.println(p.principal());
					if(p.principal().compareTo(m)==0) {
						content.insertElementAt(p,i++);
					} else {
						put(p);
						continue loop;
					}
				} else n--;
			}
			break;
		}
	}

	void put(PolynomialWithSugar p) {
//		content.insertElementAt(p,p.degree()>0?index(p,SaccharineComparator.comparator):0);
		content.addElement(p);
//		content.insertElementAt(p,index(p,null));
	}

	void sort() {
		Vector v=new Vector();
		int n=content.size();
		for(int i=0;i<n;i++) {
			PolynomialWithSugar p=(PolynomialWithSugar)content.elementAt(i);
			v.addElement(p);
		}
		content.removeAllElements();
		for(int i=0;i<n;i++) {
			PolynomialWithSugar p=(PolynomialWithSugar)v.elementAt(i);
			content.insertElementAt(p,index(p,null));
		}
	}

	int index(PolynomialWithSugar polynomial, Comparator comparator) {
		int n=content.size();
		for(int i=0;i<n;i++) {
			PolynomialWithSugar p=(PolynomialWithSugar)content.elementAt(i);
			if((comparator==null?p.compareTo(polynomial):comparator.compare(p,polynomial))>0) return i;
		}
		return n;
	}

	public int size() {
		return content.size();
	}

	public Expression get(int n) {
		return Expression.valueOf((Arithmetic)content.elementAt(n));
	}

	public String toString() {
		StringBuffer buffer=new StringBuffer();
		Arithmetic a[]=new Arithmetic[content.size()];
		content.copyInto(a);
		buffer.append(new JSCLVector(a));
		buffer.append(", {");
		for(int i=0;i<unknown.length;i++) {
			buffer.append(unknown[i]).append(i<unknown.length-1?", ":"");
		}
		buffer.append("}");
		return buffer.toString();
	}
}

class Pair implements Comparable {
	PolynomialWithSugar polynomial[];
	Monomial scm;
	int sugar;
	boolean multiple;

	Pair(PolynomialWithSugar p1, PolynomialWithSugar p2) {
		this(p1.compareTo(p2)>0?new PolynomialWithSugar[] {p2,p1}:new PolynomialWithSugar[] {p1,p2});
//		this(p1.index>p2.index?new PolynomialWithSugar[] {p2,p1}:new PolynomialWithSugar[] {p1,p2});
	}

	Pair(PolynomialWithSugar polynomial[]) {
		this.polynomial=polynomial;
		scm=polynomial[0].principal().scm(polynomial[1].principal());
		sugar=Math.max(polynomial[0].saccharine(),polynomial[1].saccharine())+scm.degree();
		multiple=polynomial[1].principal().multiple(polynomial[0].principal());
	}

	public int compareTo(Object comparable) {
		Pair pa=(Pair)comparable;
		if(sugar<pa.sugar) return -1;
		else if(sugar>pa.sugar) return 1;
		else {
			int c=scm.compareTo(pa.scm);
			if(c<0) return -1;
			else if(c>0) return 1;
			else {
				c=polynomial[1].compareTo(pa.polynomial[1]);
				if(c<0) return -1;
				else if(c>0) return 1;
//				int c1=polynomial[1].index;
//				int c2=pa.polynomial[1].index;
//				if(c1<c2) return -1;
//				else if(c1>c2) return 1;
				else {
					c=polynomial[0].compareTo(pa.polynomial[0]);
					if(c<0) return -1;
					else if(c>0) return 1;
//					c1=polynomial[0].index;
//					c2=pa.polynomial[0].index;
//					if(c1<c2) return -1;
//					else if(c1>c2) return 1;
					else return 0;
				}
			}
		}
	}

	public String toString() {
		return "{"+polynomial[0].principal()+", "+polynomial[1].principal()+"}, "+sugar+", "+multiple;
	}
}

class SaccharineComparator implements Comparator {
	public static final Comparator comparator=new SaccharineComparator();

	private SaccharineComparator() {}

	public int compare(Object o1, Object o2) {
		PolynomialWithSugar p1=(PolynomialWithSugar)o1;
		PolynomialWithSugar p2=(PolynomialWithSugar)o2;
		int c1=p1.saccharine();
		int c2=p2.saccharine();
		if(c1<c2) return -1;
		else if(c1>c2) return 1;
		else {
			int c=p1.compareTo(p2);
			if(c<0) return -1;
			else if(c>0) return 1;
			else return 0;
		}
	}
}

class PolynomialWithSugar extends Polynomial {
	int sugar;
//	int index;

	PolynomialWithSugar(Variable unknown[], Comparator ordering, int modulo) {
		super(unknown,ordering,modulo);
	}

	public Arithmetic multiply(Arithmetic arithmetic) {
		if(arithmetic.compareTo(JSCLInteger.valueOf(1))==0) return this;
		PolynomialWithSugar p=(PolynomialWithSugar)super.multiply(arithmetic);
		p.sugar=sugar;
		return p;
	}

	public Arithmetic divide(Arithmetic arithmetic) throws ArithmeticException {
		if(arithmetic.compareTo(JSCLInteger.valueOf(1))==0) return this;
		PolynomialWithSugar p=(PolynomialWithSugar)super.divide(arithmetic);
		p.sugar=sugar;
		return p;
	}

	public Arithmetic gcd() {
		Arithmetic a=JSCLInteger.valueOf(0);
		for(Iterator it=content.values().iterator(true);it.hasNext();) {
			a=a.gcd((Arithmetic)it.next());
			if(a.abs().compareTo(JSCLInteger.valueOf(1))==0) break;
		}
		return a;
	}

	public Arithmetic valueof(Arithmetic arithmetic) {
		PolynomialWithSugar p=(PolynomialWithSugar)super.valueof(arithmetic);
		p.sugar=((PolynomialWithSugar)arithmetic).sugar;
		return p;
	}

	PolynomialWithSugar s_polynomial(PolynomialWithSugar polynomial) {
		Map.Entry e1=headTerm();
		Monomial m1=(Monomial)e1.getKey();
		Arithmetic c1=(Arithmetic)e1.getValue();
		Map.Entry e2=polynomial.headTerm();
		Monomial m2=(Monomial)e2.getKey();
		Arithmetic c2=(Arithmetic)e2.getValue();
		Monomial m=(Monomial)m1.scm(m2);
		m1=(Monomial)m.divide(m1);
		m2=(Monomial)m.divide(m2);
		Arithmetic c=c1.scm(c2);
		c1=c.divide(c1);
		c2=c.divide(c2);
		PolynomialWithSugar p=multiply(m1,c1);
		p.reduce(JSCLInteger.valueOf(1),polynomial,m2,c2);
		return p;
	}

	PolynomialWithSugar multiply(Monomial m1, Arithmetic c1) {
		PolynomialWithSugar p=(PolynomialWithSugar)newinstance();
		Iterator it=content.entrySet().iterator();
		while(it.hasNext()) {
			Map.Entry e=(Map.Entry)it.next();
			p.put(
				(Monomial)((Monomial)e.getKey()).multiply(m1),
				((Arithmetic)e.getValue()).multiply(c1)
			);
		}
		p.sugar=sugar+m1.degree();
		return p;
	}

	PolynomialWithSugar reduce(Vector vector) {
		PolynomialWithSugar p=(PolynomialWithSugar)valueof(this);
		int n=vector.size();
		loop: while(p.signum()!=0) {
			Map.Entry e1=p.headTerm();
			Monomial m1=(Monomial)e1.getKey();
			Arithmetic c1=(Arithmetic)e1.getValue();
			for(int i=0;i<n;i++) {
				PolynomialWithSugar q=(PolynomialWithSugar)vector.elementAt(i);
				Map.Entry e2=q.headTerm();
				Monomial m2=(Monomial)e2.getKey();
				if(m1.multiple(m2)) {
					Arithmetic c2=(Arithmetic)e2.getValue();
					Monomial m=(Monomial)m1.divide(m2);
					Arithmetic c=c1.scm(c2);
					c1=c.divide(c1);
					c2=c.divide(c2);
					p.reduce(c1,q,m,c2);
					continue loop;
				}
			}
			break;
		}
		return p;
	}

	PolynomialWithSugar reduceCompletely(Vector vector) {
		PolynomialWithSugar p=(PolynomialWithSugar)valueof(this);
		int n=vector.size();
		Monomial l=null;
		loop: while(p.signum()!=0) {
			Iterator it=l==null?p.content.entrySet().iterator(true):p.content.headMap(l).entrySet().iterator(true);
//			boolean flag=true;
			while(it.hasNext()) {
				Map.Entry e1=(Map.Entry)it.next();
				Monomial m1=(Monomial)e1.getKey();
				Arithmetic c1=(Arithmetic)e1.getValue();
//				if(l==null?false:m1.compareTo(l)>0) continue;
				for(int i=0;i<n;i++) {
					PolynomialWithSugar q=(PolynomialWithSugar)vector.elementAt(i);
//					if(!really) if(!flag) if(q.saccharine()>p.saccharine()) continue;
					Map.Entry e2=q.headTerm();
					Monomial m2=(Monomial)e2.getKey();
					if(m1.multiple(m2)) {
						Arithmetic c2=(Arithmetic)e2.getValue();
						Monomial m=(Monomial)m1.divide(m2);
						Arithmetic c=c1.scm(c2);
						c1=c.divide(c1);
						c2=c.divide(c2);
						p.reduce(c1,q,m,c2);
						l=m1;
						continue loop;
					}
				}
//				flag=false;
			}
			break;
		}
		return p;
	}

	void reduce(Arithmetic c1, PolynomialWithSugar p2, Monomial m2, Arithmetic c2) {
		if(c1.compareTo(JSCLInteger.valueOf(1))==0);
		else {
			Iterator it=content.entrySet().iterator();
			while(it.hasNext()) {
				Map.Entry e=(Map.Entry)it.next();
				e.setValue(((Arithmetic)e.getValue()).multiply(c1));
			}
		}
		Iterator it=p2.content.entrySet().iterator();
		while(it.hasNext()) {
			Map.Entry e=(Map.Entry)it.next();
			put(
				(Monomial)((Monomial)e.getKey()).multiply(m2),
				((Arithmetic)e.getValue()).multiply(c2).negate()
			);
		}
		sugar=Math.max(sugar,p2.sugar+m2.degree());
		Arithmetic gcd=gcd();
		if(gcd.signum()==0) return;
		if(gcd.signum()!=signum()) gcd=gcd.negate();
		if(gcd.compareTo(JSCLInteger.valueOf(1))==0) return;
		it=content.entrySet().iterator();
		while(it.hasNext()) {
			Map.Entry e=(Map.Entry)it.next();
			e.setValue(((Arithmetic)e.getValue()).divide(gcd));
		}
	}

	Monomial principal() {
		return (Monomial)content.lastKey();
	}

	int saccharine() {
		return sugar-degree;
	}

	public int compareTo(Object comparable) {
		if(this==comparable) return 0;
		return super.compareTo(comparable);
	}

	protected Arithmetic newinstance() {
		return new PolynomialWithSugar(unknown,ordering,modulo);
	}
}
