package jscl.math;

import java.util.*;

public class Basis {
	final Variable unknown[];
	final Comparator ordering;
	final int modulo;
	final Vector content=new Vector();
	final SortedMap pairs=new TreeMap();

	public Basis(Arithmetic arithmetic[], Variable unknown[], Comparator ordering, int modulo) {
		this.unknown=unknown;
		this.ordering=ordering;
		this.modulo=modulo;
		for(int i=0;i<arithmetic.length;i++) {
			PolynomialWithSugar p=polynomial(arithmetic[i]);
			if(p.signum()!=0) {
				int n=put(p);
				makePairs(n);
			}
		}
	}

	PolynomialWithSugar polynomial(Arithmetic arithmetic) {
		PolynomialWithSugar p=new PolynomialWithSugar(arithmetic,unknown,ordering,modulo);
		return (PolynomialWithSugar)p.normalize();
	}

	public static Variable[] augmentUnknown(Variable unknown[], Arithmetic arithmetic[]) {
		Vector w=new Vector();
		for(int i=0;i<unknown.length;i++) {
			w.addElement(unknown[i]);
		}
		Literal l=new Literal();
		for(int i=0;i<arithmetic.length;i++) {
			l=l.scm(Expression.valueOf(arithmetic[i]).variables());
		}
		int index=0;
		Iterator it=l.content.keySet().iterator();
		while(it.hasNext()) {
			Variable v=(Variable)it.next();
			if(w.contains(v));
			else w.insertElementAt(v,index++);
		}
		Variable in[]=new Variable[w.size()];
		w.copyInto(in);
		return in;
	}

	public void compute() {
		Debug.println(this);
		while(!pairs.isEmpty()) {
			Pair pa=(Pair)pairs.firstKey();
			if(!b_criterion(pa)) {
				Debug.println(pa);
				Debug.increment();
				PolynomialWithSugar p=pa.polynomial(1).s_polynomial(pa.polynomial(0));
				p=(PolynomialWithSugar)p.reduceCompletely(this);
				if(p.signum()!=0) {
					if(p.degree()==0) {
						content.removeAllElements();
						pairs.clear();
						pairs.put(pa,null);
					}
					int n=put(p);
					makePairs(n);
				}
				Debug.decrement();
			}
			pairs.remove(pa);
		}
		reduce();
		sort();
	}

	int put(PolynomialWithSugar polynomial) {
		int n=content.size();
		Debug.println(polynomial.principal()+" ("+n+")");
		content.addElement(polynomial);
		return n;
	}

	PolynomialWithSugar polynomial(int index) {
		return (PolynomialWithSugar)content.elementAt(index);
	}

	void makePairs(int n) {
		for(int i=0;i<n;i++) {
			Pair pa=pair(new int[] {i,n});
			if(!a_criterion(pa)) pairs.put(pa,null);
		}
	}

	Pair pair(int index[]) {
		return new Pair(this,index);
	}

	Pair pair(int index1, int index2) {
		return pair(index1>index2?new int[] {index2,index1}:new int[] {index1,index2});
	}

	boolean a_criterion(Pair pair) {
		return pair.monomial(0).gcd(pair.monomial(1)).degree()==0;
	}

	boolean b_criterion(Pair pair) {
		int n=content.size();
		for(int i=0;i<n;i++) {
			PolynomialWithSugar p=polynomial(i);
			if(pair.scm.multiple(p.principal())) {
				Pair pa1=pair(pair.index[0],i);
				Pair pa2=pair(i,pair.index[1]);
				if(!pairs.containsKey(pa1) && !pairs.containsKey(pa2)) return true;
			}
		}
		return false;
	}

	void reduce() {
		Debug.println("reduce");
		int n=content.size();
		for(int i=0;i<n;) {
			PolynomialWithSugar p=polynomial(i);
			content.removeElementAt(i);
			p=(PolynomialWithSugar)p.reduceCompletely(this);
			if(p.signum()!=0) {
				Debug.println(p.principal());
				content.insertElementAt(p,i++);
			} else n--;
		}
	}

	void sort() {
		Vector v=new Vector();
		int n=content.size();
		for(int i=0;i<n;i++) {
			PolynomialWithSugar p=polynomial(i);
			v.addElement(p);
		}
		content.removeAllElements();
		for(int i=0;i<n;i++) {
			PolynomialWithSugar p=(PolynomialWithSugar)v.elementAt(i);
			content.insertElementAt(p,index(p));
		}
	}

	int index(PolynomialWithSugar polynomial) {
		int n=content.size();
		for(int i=0;i<n;i++) {
			PolynomialWithSugar p=polynomial(i);
			if(p.compareTo(polynomial)>0) return i;
		}
		return n;
	}

	public int size() {
		return content.size();
	}

	public Expression get(int n) {
		return Expression.valueOf(polynomial(n));
	}

	public String toString() {
		StringBuffer buffer=new StringBuffer();
		Arithmetic a[]=new Arithmetic[content.size()];
		content.copyInto(a);
		buffer.append(new JSCLVector(a));
		buffer.append(", {");
		for(int i=0;i<unknown.length;i++) {
			buffer.append(unknown[i]).append(i<unknown.length-1?", ":"");
		}
		buffer.append("}");
		return buffer.toString();
	}
}

class Pair implements Comparable {
	Basis basis;
	int index[];
	Monomial scm;
	int sugar;
	boolean multiple;

	Pair(Basis basis, int index[]) {
		this.basis=basis;
		this.index=index;
		PolynomialWithSugar p1=basis.polynomial(index[0]);
		PolynomialWithSugar p2=basis.polynomial(index[1]);
		Monomial m1=p1.principal();
		Monomial m2=p2.principal();
		scm=m1.scm(m2);
		sugar=Math.max(p1.saccharine(),p2.saccharine())+scm.degree();
		multiple=m1.compareTo(m2)>0?m1.multiple(m2):m2.multiple(m1);
	}

	PolynomialWithSugar polynomial(int n) {
		return basis.polynomial(index[n]);
	}

	Monomial monomial(int n) {
		return basis.polynomial(index[n]).principal();
	}

	public int compareTo(Object comparable) {
		Pair pa=(Pair)comparable;
		if(sugar<pa.sugar) return -1;
		else if(sugar>pa.sugar) return 1;
		else {
			int c=scm.compareTo(pa.scm);
			if(c<0) return -1;
			else if(c>0) return 1;
			else {
				if(index[1]<pa.index[1]) return -1;
				else if(index[1]>pa.index[1]) return 1;
				else {
					if(index[0]<pa.index[0]) return -1;
					else if(index[0]>pa.index[0]) return 1;
					else return 0;
				}
			}
		}
	}

	public String toString() {
		return "{"+index[0]+", "+index[1]+"}, "+sugar+", "+multiple;
	}
}

class PolynomialWithSugar extends Polynomial {
	int sugar;

	PolynomialWithSugar(Variable unknown[], Comparator ordering, int modulo) {
		super(unknown,ordering,modulo);
	}

	PolynomialWithSugar(Arithmetic arithmetic, Variable unknown[], Comparator ordering, int modulo) {
		this(unknown,ordering,modulo);
		put(arithmetic);
		Iterator it=content.keySet().iterator();
		while(it.hasNext()) {
			Monomial m=(Monomial)it.next();
			sugar=Math.max(sugar,m.degree());
		}
	}

	public Arithmetic multiply(Arithmetic arithmetic) {
		if(arithmetic.compareTo(JSCLInteger.valueOf(1))==0) return this;
		PolynomialWithSugar p=(PolynomialWithSugar)super.multiply(arithmetic);
		p.sugar=sugar;
		return p;
	}

	public Arithmetic divide(Arithmetic arithmetic) throws ArithmeticException {
		if(arithmetic.compareTo(JSCLInteger.valueOf(1))==0) return this;
		PolynomialWithSugar p=(PolynomialWithSugar)super.divide(arithmetic);
		p.sugar=sugar;
		return p;
	}

	public Arithmetic gcd() {
		Arithmetic a=JSCLInteger.valueOf(0);
		for(Iterator it=content.values().iterator(true);it.hasNext();) {
			a=a.gcd((Arithmetic)it.next());
			if(a.abs().compareTo(JSCLInteger.valueOf(1))==0) break;
		}
		return a;
	}

	public Arithmetic valueof(Arithmetic arithmetic) {
		PolynomialWithSugar p=(PolynomialWithSugar)super.valueof(arithmetic);
		p.sugar=((PolynomialWithSugar)arithmetic).sugar;
		return p;
	}

	PolynomialWithSugar s_polynomial(PolynomialWithSugar polynomial) {
		Map.Entry e1=headTerm();
		Monomial m1=(Monomial)e1.getKey();
		Arithmetic c1=(Arithmetic)e1.getValue();
		Map.Entry e2=polynomial.headTerm();
		Monomial m2=(Monomial)e2.getKey();
		Arithmetic c2=(Arithmetic)e2.getValue();
		Monomial m=(Monomial)m1.scm(m2);
		m1=(Monomial)m.divide(m1);
		m2=(Monomial)m.divide(m2);
		Arithmetic c=c1.scm(c2);
		c1=c.divide(c1);
		c2=c.divide(c2);
		PolynomialWithSugar p=multiply(m1,c1);
		p.reduce(JSCLInteger.valueOf(1),polynomial,m2,c2);
		return p;
	}

	PolynomialWithSugar multiply(Monomial m1, Arithmetic c1) {
		PolynomialWithSugar p=(PolynomialWithSugar)newinstance();
		Iterator it=content.entrySet().iterator();
		while(it.hasNext()) {
			Map.Entry e=(Map.Entry)it.next();
			p.put(
				(Monomial)((Monomial)e.getKey()).multiply(m1),
				((Arithmetic)e.getValue()).multiply(c1)
			);
		}
		p.sugar=sugar+m1.degree();
		return p;
	}

	PolynomialWithSugar reduce(Basis basis) {
		PolynomialWithSugar p=(PolynomialWithSugar)valueof(this);
		int n=basis.size();
		loop: while(p.signum()!=0) {
			Map.Entry e1=p.headTerm();
			Monomial m1=(Monomial)e1.getKey();
			Arithmetic c1=(Arithmetic)e1.getValue();
			for(int i=0;i<n;i++) {
				PolynomialWithSugar q=basis.polynomial(i);
				Map.Entry e2=q.headTerm();
				Monomial m2=(Monomial)e2.getKey();
				if(m1.multiple(m2)) {
					Arithmetic c2=(Arithmetic)e2.getValue();
					Monomial m=(Monomial)m1.divide(m2);
					Arithmetic c=c1.scm(c2);
					c1=c.divide(c1);
					c2=c.divide(c2);
					p.reduce(c1,q,m,c2);
					continue loop;
				}
			}
			break;
		}
		return p;
	}

	PolynomialWithSugar reduceCompletely(Basis basis) {
		PolynomialWithSugar p=(PolynomialWithSugar)valueof(this);
		int n=basis.size();
		Monomial l=null;
		loop: while(p.signum()!=0) {
			Iterator it=l==null?p.content.entrySet().iterator(true):p.content.headMap(l).entrySet().iterator(true);
			while(it.hasNext()) {
				Map.Entry e1=(Map.Entry)it.next();
				Monomial m1=(Monomial)e1.getKey();
				Arithmetic c1=(Arithmetic)e1.getValue();
//				if(l==null?false:m1.compareTo(l)>0) continue;
				for(int i=0;i<n;i++) {
					PolynomialWithSugar q=basis.polynomial(i);
					Map.Entry e2=q.headTerm();
					Monomial m2=(Monomial)e2.getKey();
					if(m1.multiple(m2)) {
						Arithmetic c2=(Arithmetic)e2.getValue();
						Monomial m=(Monomial)m1.divide(m2);
						Arithmetic c=c1.scm(c2);
						c1=c.divide(c1);
						c2=c.divide(c2);
						p.reduce(c1,q,m,c2);
						l=m1;
						continue loop;
					}
				}
			}
			break;
		}
		return p;
	}

	void reduce(Arithmetic c1, PolynomialWithSugar p2, Monomial m2, Arithmetic c2) {
		if(c1.compareTo(JSCLInteger.valueOf(1))==0);
		else {
			Iterator it=content.entrySet().iterator();
			while(it.hasNext()) {
				Map.Entry e=(Map.Entry)it.next();
				e.setValue(((Arithmetic)e.getValue()).multiply(c1));
			}
		}
		Iterator it=p2.content.entrySet().iterator();
		while(it.hasNext()) {
			Map.Entry e=(Map.Entry)it.next();
			put(
				(Monomial)((Monomial)e.getKey()).multiply(m2),
				((Arithmetic)e.getValue()).multiply(c2).negate()
			);
		}
		sugar=Math.max(sugar,p2.sugar+m2.degree());
		Arithmetic gcd=gcd();
		if(gcd.signum()==0) return;
		if(gcd.signum()!=signum()) gcd=gcd.negate();
		if(gcd.compareTo(JSCLInteger.valueOf(1))==0) return;
		it=content.entrySet().iterator();
		while(it.hasNext()) {
			Map.Entry e=(Map.Entry)it.next();
			e.setValue(((Arithmetic)e.getValue()).divide(gcd));
		}
	}

	Monomial principal() {
		return (Monomial)content.lastKey();
	}

	int saccharine() {
		return sugar-degree;
	}

	protected Arithmetic newinstance() {
		return new PolynomialWithSugar(unknown,ordering,modulo);
	}
}
/*
class RationalPolynomialWithSugar extends PolynomialWithSugar {
	RationalPolynomialWithSugar(Variable unknown[], Comparator ordering, int modulo) {
		super(unknown,ordering,modulo);
	}

	RationalPolynomialWithSugar(Arithmetic arithmetic, Variable unknown[], Comparator ordering, int modulo) {
		super(arithmetic,unknown,ordering,modulo);
	}

	public Arithmetic normalize() {
		return signum()==0?this:multiply(((Rational)headTerm().getValue()).inverse());
	}

	PolynomialWithSugar s_polynomial(PolynomialWithSugar polynomial) {
		Map.Entry e1=headTerm();
		Monomial m1=(Monomial)e1.getKey();
		Map.Entry e2=polynomial.headTerm();
		Monomial m2=(Monomial)e2.getKey();
		Monomial m=(Monomial)m1.scm(m2);
		m1=(Monomial)m.divide(m1);
		m2=(Monomial)m.divide(m2);
		RationalPolynomialWithSugar p=multiply(m1);
		p.reduce(polynomial,m2,Rational.valueOf(JSCLInteger.valueOf(1)));
		return p;
	}

	RationalPolynomialWithSugar multiply(Monomial m1) {
		RationalPolynomialWithSugar p=(RationalPolynomialWithSugar)newinstance();
		Iterator it=content.entrySet().iterator();
		while(it.hasNext()) {
			Map.Entry e=(Map.Entry)it.next();
			p.put(
				(Monomial)((Monomial)e.getKey()).multiply(m1),
				(Arithmetic)e.getValue()
			);
		}
		p.sugar=sugar+m1.degree();
		return p;
	}

	PolynomialWithSugar reduce(Basis basis) {
		RationalPolynomialWithSugar p=(RationalPolynomialWithSugar)valueof(this);
		int n=basis.size();
		loop: while(p.signum()!=0) {
			Map.Entry e1=p.headTerm();
			Monomial m1=(Monomial)e1.getKey();
			Arithmetic c1=(Arithmetic)e1.getValue();
			for(int i=0;i<n;i++) {
				PolynomialWithSugar q=basis.polynomial(i);
				Map.Entry e2=q.headTerm();
				Monomial m2=(Monomial)e2.getKey();
				if(m1.multiple(m2)) {
					Monomial m=(Monomial)m1.divide(m2);
					p.reduce(q,m,c1);
					continue loop;
				}
			}
			break;
		}
		return (PolynomialWithSugar)p.normalize();
	}

	PolynomialWithSugar reduceCompletely(Basis basis) {
		RationalPolynomialWithSugar p=(RationalPolynomialWithSugar)valueof(this);
		int n=basis.size();
		Monomial l=null;
		loop: while(p.signum()!=0) {
			Iterator it=l==null?p.content.entrySet().iterator(true):p.content.headMap(l).entrySet().iterator(true);
			while(it.hasNext()) {
				Map.Entry e1=(Map.Entry)it.next();
				Monomial m1=(Monomial)e1.getKey();
				Arithmetic c1=(Arithmetic)e1.getValue();
				for(int i=0;i<n;i++) {
					PolynomialWithSugar q=basis.polynomial(i);
					Map.Entry e2=q.headTerm();
					Monomial m2=(Monomial)e2.getKey();
					if(m1.multiple(m2)) {
						Monomial m=(Monomial)m1.divide(m2);
						p.reduce(q,m,c1);
						l=m1;
						continue loop;
					}
				}
			}
			break;
		}
		return (PolynomialWithSugar)p.normalize();
	}

	void reduce(PolynomialWithSugar p2, Monomial m2, Arithmetic c2) {
		Iterator it=p2.content.entrySet().iterator();
		while(it.hasNext()) {
			Map.Entry e=(Map.Entry)it.next();
			put(
				(Monomial)((Monomial)e.getKey()).multiply(m2),
				((Arithmetic)e.getValue()).multiply(c2).negate()
			);
		}
		sugar=Math.max(sugar,p2.sugar+m2.degree());
	}

	void put(Arithmetic arithmetic) {
		if(arithmetic instanceof RationalPolynomialWithSugar) {
			Polynomial p=(Polynomial)arithmetic;
			if(p.unknown==unknown && p.ordering==ordering && p.modulo==modulo) {

				Iterator it=p.content.entrySet().iterator();
				while(it.hasNext()) {
					Map.Entry e=(Map.Entry)it.next();
					put(
						(Monomial)e.getKey(),
						(Arithmetic)e.getValue()
					);
				}
			} else put(Expression.valueOf(arithmetic));
		} else if(arithmetic instanceof Expression) {
			Expression ex=(Expression)arithmetic;
			Iterator it=ex.content.entrySet().iterator();
			while(it.hasNext()) {
				Map.Entry e=(Map.Entry)it.next();
				Literal l=(Literal)e.getKey();
				JSCLInteger en=(JSCLInteger)e.getValue();
				Literal ll[]=l.separate(unknown);
				Monomial m=Monomial.valueOf(ll[1],unknown,ordering);
				l=ll[0];
				if(l.degree()>0);
				else put(m,Rational.valueOf(en));
			}
		} else put(Expression.valueOf(arithmetic));
	}

	protected Arithmetic newinstance() {
		return new RationalPolynomialWithSugar(unknown,ordering,modulo);
	}
}
*/
