package jscl.math;

import java.util.*;

public class Basis {
	static final Comparator comparator=SaccharineComparator.comparator;
	final Map content=new TreeMap(comparator);
	final Variable unknown[];
	final Comparator ordering;
	final int modulo;
	SortedMap pairs=new TreeMap();
//	Map considered=new TreeMap();
	int index;

	public Basis(Arithmetic arithmetic[], Variable unknown[], Comparator ordering, int modulo) {
		this.unknown=unknown;
		this.ordering=ordering;
		this.modulo=modulo;
		for(int i=0;i<arithmetic.length;i++) {
			Polynomial p=polynomial(arithmetic[i]).normalize();
			if(p.signum()!=0) {
				put(p);
			}
		}
	}

	public Polynomial polynomial(Arithmetic arithmetic) {
		return MultivariatePolynomial.valueOf(arithmetic,unknown,ordering,modulo);
	}

	public static Variable[] augmentUnknown(Variable unknown[], Arithmetic arithmetic[]) {
		Vector w=new Vector();
		for(int i=0;i<unknown.length;i++) {
			w.addElement(unknown[i]);
		}
		int n=0;
		for(int i=0;i<arithmetic.length;i++) {
			Variable va[]=arithmetic[i].variables();
			for(int j=0;j<va.length;j++) {
				Variable v=va[j];
				if(w.contains(v));
				else w.insertElementAt(v,n++);
			}
		}
		Variable in[]=new Variable[w.size()];
		w.copyInto(in);
		return in;
	}

	public void compute() {
		Debug.println(this);
		while(!pairs.isEmpty()) {
			Pair pa=(Pair)pairs.firstKey();
			if(!b_criterion(pa)) {
				Debug.println(pa);
				Debug.increment();
				Polynomial p=s_polynomial(pa).reduceCompletely(this);
				if(p.signum()!=0) {
					if(p.degree()==0) {
						content.clear();
						pairs.clear();
						pairs.put(pa,null);
					}
					put(p);
				}
				Debug.decrement();
			}
			pairs.remove(pa);
//			considered.put(pa,null);
//			if(pa.multiple(0)) remove(pa.handle[0]);
//			else if(pa.multiple(1)) remove(pa.handle[1]);
		}
		reduce();
	}

//	void remove(Handle handle) {
//		content.remove(handle);
//		Iterator it=pairs.entrySet().iterator();
//		while(it.hasNext()) {
//			Map.Entry e=(Map.Entry)it.next();
//			Pair pa=(Pair)e.getKey();
//			if(pa.handle[0].compareTo(handle)==0 || pa.handle[1].compareTo(handle)==0) it.remove();
//		}
//	}

	Polynomial s_polynomial(Pair pair) {
		Polynomial p1=(Polynomial)content.get(pair.handle[1]);
		Polynomial p2=(Polynomial)content.get(pair.handle[0]);
		return p1.s_polynomial(p2);
	}

	public void put(Polynomial polynomial) {
		Handle h=new Handle(polynomial,index++);
		makePairs(h);
		Debug.println(h);
		content.put(h,polynomial);
	}

	void makePairs(Handle handle) {
		Iterator it=content.keySet().iterator();
		while(it.hasNext()) {
			Handle h=(Handle)it.next();
			Pair pa=new Pair(h,handle);
			if(!a_criterion(pa)) pairs.put(pa,null);
//			else considered.put(pa,null);
		}
	}

	boolean a_criterion(Pair pair) {
		return pair.handle[0].monomial.gcd(pair.handle[1].monomial).degree()==0;
	}

	boolean b_criterion(Pair pair) {
		Iterator it=content.keySet().iterator();
		while(it.hasNext()) {
			Handle h=(Handle)it.next();
			if(pair.scm.multiple(h.monomial)) {
				Pair pa1=new Pair(pair.handle[0],h);
				Pair pa2=new Pair(h,pair.handle[1]);
				if(considered(pa1) && considered(pa2)) return true;
			}
		}
		return false;
	}

	boolean considered(Pair pair) {
		return !pairs.containsKey(pair);
//		return considered.containsKey(pair);
	}

	void reduce() {
		Debug.println("reduce");
		Map map=newTreeMap(content);
		Iterator it=map.entrySet().iterator();
		while(it.hasNext()) {
			Map.Entry e=(Map.Entry)it.next();
			Handle h=(Handle)e.getKey();
			content.remove(h);
			Polynomial p=(Polynomial)e.getValue();
			p=p.reduceCompletely(this);
			if(p.signum()!=0) {
				Debug.println(h);
				content.put(h,p);
			}
		}
	}

	static Map newTreeMap(Map map) {
		Map m=new TreeMap();
		Iterator it=map.entrySet().iterator();
		while(it.hasNext()) {
			Map.Entry e=(Map.Entry)it.next();
			m.put(e.getKey(),e.getValue());
		}
		return m;
	}

	public Polynomial[] elements() {
		Map map=newTreeMap(content);
		Polynomial p[]=new Polynomial[map.size()];
		Iterator it=map.values().iterator();
		for(int i=0;it.hasNext();i++) {
			p[i]=(Polynomial)it.next();
		}
		return p;
	}

	public String toString() {
		StringBuffer buffer=new StringBuffer();
		buffer.append("{");
		Iterator it=content.values().iterator();
		while(it.hasNext()) {
			Polynomial p=(Polynomial)it.next();
			buffer.append(p).append(it.hasNext()?", ":"");
		}
		buffer.append("}, {");
		for(int i=0;i<unknown.length;i++) {
			buffer.append(unknown[i]).append(i<unknown.length-1?", ":"");
		}
		buffer.append("}");
		return buffer.toString();
	}
}

class Pair implements Comparable {
	Handle handle[];
	Monomial scm;
	int sugar;

	Pair(Handle handle[]) {
		this.handle=handle;
		scm=handle[0].monomial.scm(handle[1].monomial);
		sugar=Math.max(handle[0].saccharine,handle[1].saccharine)+scm.degree();
	}

	Pair(Handle handle1, Handle handle2) {
		this(Basis.comparator.compare(handle1,handle2)<0?new Handle[] {handle1,handle2}:new Handle[] {handle2,handle1});
	}

	boolean multiple() {
		return handle[0].monomial.compareTo(handle[1].monomial)<0?multiple(1):multiple(0);
	}

	boolean multiple(int n) {
		return handle[n].monomial.multiple(handle[(n+1)%2].monomial);
	}

	public int compareTo(Object comparable) {
		Pair pa=(Pair)comparable;
		if(sugar<pa.sugar) return -1;
		else if(sugar>pa.sugar) return 1;
		else {
			int c=scm.compareTo(pa.scm);
			if(c<0) return -1;
			else if(c>0) return 1;
			else {
				c=Basis.comparator.compare(handle[1],pa.handle[1]);
				if(c<0) return -1;
				else if(c>0) return 1;
				else {
					c=Basis.comparator.compare(handle[0],pa.handle[0]);
					if(c<0) return -1;
					else if(c>0) return 1;
					else return 0;
				}
			}
		}
	}

	public String toString() {
		return "{"+handle[0].index+", "+handle[1].index+"}, "+sugar+", "+multiple();
	}
}

class Handle implements Comparable {
	Monomial monomial;
	int saccharine;
	int index;

	Handle(Polynomial polynomial, int index) {
		monomial=polynomial.headMonomial();
		saccharine=polynomial.sugar()-polynomial.degree();
		this.index=index;
	}

	public int compareTo(Object comparable) {
		Handle h=(Handle)comparable;
		int c=monomial.compareTo(h.monomial);
		if(c<0) return -1;
		else if(c>0) return 1;
		else {
			if(index<h.index) return -1;
			else if(index>h.index) return 1;
			else return 0;
		}
	}

	public String toString() {
		return "("+monomial+", "+saccharine+", "+index+")";
	}
}

class SaccharineComparator implements Comparator {
	public static final Comparator comparator=new SaccharineComparator();

	private SaccharineComparator() {}

	public int compare(Object o1, Object o2) {
		Handle h1=(Handle)o1;
		Handle h2=(Handle)o2;
		if(h1.saccharine<h2.saccharine) return -1;
		else if(h1.saccharine>h2.saccharine) return 1;
		else {
			if(h1.index<h2.index) return -1;
			else if(h1.index>h2.index) return 1;
			else return 0;
		}
	}
}
