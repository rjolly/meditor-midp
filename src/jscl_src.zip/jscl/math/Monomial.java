package jscl.math;

import java.util.*;
import jscl.math.function.*;
import jscl.util.*;

public class Monomial implements jscl.util.Comparable {
	public static final jscl.util.Comparator lexicographic=Lexicographic.comparator;
	public static final jscl.util.Comparator totalDegreeLexicographic=TotalDegreeLexicographic.comparator;
	public static final jscl.util.Comparator degreeReverseLexicographic=DegreeReverseLexicographic.comparator;
	final Variable unknown[];
	final jscl.util.Comparator ordering;
	int keys[];
	int elements[];
	int size;
	int degree;

	Monomial(Variable unknown[], jscl.util.Comparator ordering) {
		this.unknown=unknown;
		this.ordering=ordering;
		keys=new int[unknown.length];
		elements=new int[unknown.length];
	}

	static int variable(Variable v, Variable unknown[]) {
		int i=0;
		for(;i<unknown.length;i++) if(unknown[i].equals(v)) break;
		return i;
	}

	public Monomial multiply(Monomial monomial) {
		Monomial m=valueof(this);
		m.put(monomial);
		m.pack();
		return m;
	}

	public Monomial divide(Monomial monomial) throws ArithmeticException {
		Monomial m=valueof(this);
		for(int i=0;i<monomial.size;i++) {
			int v=monomial.keys[i];
			int c=monomial.elements[i];
			int c2=get(v);
			if(c>c2) throw new NotDivisibleException();
			else m.put(v,-c);
		}
		m.pack();
		return m;
	}

	public Monomial gcd(Monomial monomial) {
		Monomial m=newinstance();
		for(int i=0;i<monomial.size;i++) {
			int v=monomial.keys[i];
			int c2=monomial.elements[i];
			int c=get(v);
			if(c>0) m.put(v,Math.min(c,c2));
		}
		m.pack();
		return m;
	}

	public Monomial scm(Monomial monomial) {
		Monomial m=valueof(this);
		for(int i=0;i<monomial.size;i++) {
			int v=monomial.keys[i];
			int c2=monomial.elements[i];
			int c=get(v);
			if(c2>c) m.put(v,c2-c);
		}
		m.pack();
		return m;
	}

	protected Monomial valueof(Monomial monomial) {
		Monomial m=newinstance();
//		m.put(monomial);
		System.arraycopy(monomial.keys,0,m.keys,0,monomial.size);
		System.arraycopy(monomial.elements,0,m.elements,0,monomial.size);
		m.size=monomial.size;
		m.degree=monomial.degree;
		return m;
	}

	public int degree() {
		return degree;
	}

	public int compareTo(jscl.util.Comparable comparable) {
		return ordering.compare(this,comparable);
	}

	public static Monomial valueOf(Literal literal, Variable unknown[], jscl.util.Comparator ordering) {
		Monomial m=new Monomial(unknown,ordering);
		Enumeration k=literal.content.keys();
		Enumeration e=literal.content.elements();
		while(k.hasMoreElements()) {
			Variable v=(Variable)k.nextElement();
			Integer in=((Integer)e.nextElement());
			m.put(variable(v,unknown),in.intValue());
		}
		m.pack();
		return m;
	}

	void put(Monomial monomial) {
		for(int i=0;i<monomial.size;i++) {
			put(
				monomial.keys[i],
				monomial.elements[i]
			);
		}
	}

	void put(int variable, int integer) {
		int c=get(variable);
		int c2=c+integer;
		if(c2==0) {
			if(c>0) remove(variable);
		} else {
			content_put(variable,c2);
		}
		int d=c2-c;
		degree+=d;
	}

	void pack() {
		int keys[]=new int[size];
		int elements[]=new int[size];
		System.arraycopy(this.keys,0,keys,0,size);
		System.arraycopy(this.elements,0,elements,0,size);
		this.keys=keys;
		this.elements=elements;
	}

	int get(int key) {
		int n=index(key);
		if(n>0?keys[n-1]==key:false) return elements[n-1];
		else return 0;
	}

	void content_put(int key, int element) {
		int n=index(key);
		if(n>0?keys[n-1]==key:false) elements[n-1]=element;
		else {
			System.arraycopy(keys,n,keys,n+1,size-n);
			System.arraycopy(elements,n,elements,n+1,size-n);
			keys[n]=key;
			elements[n]=element;
			size++;
		}
	}

	void remove(int key) {
		int n=index(key);
		if(n>0?keys[n-1]==key:false) {
			System.arraycopy(keys,n,keys,n-1,size-n);
			System.arraycopy(elements,n,elements,n-1,size-n);
			size--;
		}
	}

	int index(int key) {
		int n=0;
		for(;n<size;n++) if(keys[n]>key) break;
		return n;
	}

	public String toString() {
		StringBuffer buffer=new StringBuffer();
		if(degree==0) buffer.append("1");
		for(int i=0;i<size;i++) {
			if(i>0) buffer.append("*");
			Variable v=unknown[keys[i]];
			int c=elements[i];
			if(c==1) buffer.append(v);
			else {
				if(v instanceof Frac) {
					buffer.append("(").append(v).append(")");
				} else buffer.append(v);
				buffer.append("^").append(c);
			}
		}
		return buffer.toString();
	}

	public String toMathML(Object data) {
		IndentedBuffer buffer=new IndentedBuffer();
		if(degree==0) buffer.append("<mn>1</mn>\n");
		for(int i=0;i<size;i++) {
			Variable v=unknown[keys[i]];
			int c=elements[i];
			buffer.append(v.toMathML(new Integer(c)));
		}
		return buffer.toString();
	}

	protected Monomial newinstance() {
		return new Monomial(unknown,ordering);
	}
}

class Lexicographic extends jscl.util.Comparator {
	public static final jscl.util.Comparator comparator=new Lexicographic();

	private Lexicographic() {}

	public int compare(Object o1, Object o2) {
		Monomial m1=(Monomial)o1;
		Monomial m2=(Monomial)o2;
		int i1=m1.size;
		int i2=m2.size;
		while(true) {
			i1--;
			i2--;
			boolean b1=i1<0;
			boolean b2=i2<0;
			if(b1 && b2) return 0;
			else if(b1) return -1;
			else if(b2) return 1;
			else {
				int v1=m1.keys[i1];
				int v2=m2.keys[i2];
				if(v1<v2) return -1;
				else if(v1>v2) return 1;
				else {
					int c1=m1.elements[i1];
					int c2=m2.elements[i2];
					if(c1<c2) return -1;
					else if(c1>c2) return 1;
				}
			}
		}
	}
}

class TotalDegreeLexicographic extends jscl.util.Comparator {
	public static final jscl.util.Comparator comparator=new TotalDegreeLexicographic();

	private TotalDegreeLexicographic() {}

	public int compare(Object o1, Object o2) {
		Monomial m1=(Monomial)o1;
		Monomial m2=(Monomial)o2;
		if(m1.degree()<m2.degree()) return -1;
		else if(m1.degree()>m2.degree()) return 1;
		int i1=m1.size;
		int i2=m2.size;
		while(true) {
			i1--;
			i2--;
			boolean b1=i1<0;
			boolean b2=i2<0;
			if(b1 && b2) return 0;
			else if(b1) return -1;
			else if(b2) return 1;
			else {
				int v1=m1.keys[i1];
				int v2=m2.keys[i2];
				if(v1<v2) return -1;
				else if(v1>v2) return 1;
				else {
					int c1=m1.elements[i1];
					int c2=m2.elements[i2];
					if(c1<c2) return -1;
					else if(c1>c2) return 1;
				}
			}
		}
	}
}

class DegreeReverseLexicographic extends jscl.util.Comparator {
	public static final jscl.util.Comparator comparator=new DegreeReverseLexicographic();

	private DegreeReverseLexicographic() {}

	public int compare(Object o1, Object o2) {
		Monomial m1=(Monomial)o1;
		Monomial m2=(Monomial)o2;
		if(m1.degree()<m2.degree()) return -1;
		else if(m1.degree()>m2.degree()) return 1;
		int s1=m1.size-1;
		int s2=m2.size-1;
		for(int i=0;;i++) {
			boolean b1=i>s1;
			boolean b2=i>s2;
			if(b1 && b2) return 0;
			else if(b1) return 1;
			else if(b2) return -1;
			else {
				int v1=m1.keys[i];
				int v2=m2.keys[i];
				if(v1<v2) return -1;
				else if(v1>v2) return 1;
				else {
					int c1=m1.elements[i];
					int c2=m2.elements[i];
					if(c1<c2) return 1;
					else if(c1>c2) return -1;
				}
			}
		}
	}
}
