package jscl.math;

import java.util.*;
import jscl.math.function.*;
import jscl.util.*;

public class Monomial implements jscl.util.Comparable {
	public static final jscl.util.Comparator lexicographic=Lexicographic.comparator;
	public static final jscl.util.Comparator totalDegreeLexicographic=TotalDegreeLexicographic.comparator;
	public static final jscl.util.Comparator degreeReverseLexicographic=DegreeReverseLexicographic.comparator;
	final Variable unknown[];
	final jscl.util.Comparator ordering;
	int element[];
	int degree;

	Monomial(Variable unknown[], jscl.util.Comparator ordering) {
		this.unknown=unknown;
		this.ordering=ordering;
		element=new int[unknown.length];
	}

	static int variable(Variable v, Variable unknown[]) {
		int i=0;
		for(;i<unknown.length;i++) if(unknown[i].equals(v)) break;
		return i;
	}

	public Monomial multiply(Monomial monomial) {
		Monomial m=newinstance();
		for(int i=0;i<element.length;i++) {
			m.put(i,element[i]+monomial.element[i]);
		}
		return m;
	}

	public Monomial divide(Monomial monomial) throws ArithmeticException {
		Monomial m=newinstance();
		for(int i=0;i<element.length;i++) {
			int n=element[i]-monomial.element[i];
			if(n<0) throw new NotDivisibleException();
			else m.put(i,n);
		}
		return m;
	}

	public Monomial gcd(Monomial monomial) {
		Monomial m=newinstance();
		for(int i=0;i<element.length;i++) {
			m.put(i,Math.min(element[i],monomial.element[i]));
		}
		return m;
	}

	public Monomial scm(Monomial monomial) {
		Monomial m=newinstance();
		for(int i=0;i<element.length;i++) {
			m.put(i,Math.max(element[i],monomial.element[i]));
		}
		return m;
	}

	public int degree() {
		return degree;
	}

	public Monomial valueof(Monomial monomial) {
		Monomial m=newinstance();
		System.arraycopy(monomial.element, 0, m.element, 0, m.element.length);
		m.degree=monomial.degree;
		return m;
	}

	public int compareTo(jscl.util.Comparable comparable) {
		return ordering.compare(this,comparable);
	}

	public static Monomial valueOf(Literal literal, Variable unknown[], jscl.util.Comparator ordering) {
		Monomial m=new Monomial(unknown,ordering);
		Enumeration k=literal.content.keys();
		Enumeration e=literal.content.elements();
		while(k.hasMoreElements()) {
			Variable v=(Variable)k.nextElement();
			Integer in=((Integer)e.nextElement());
			m.put(variable(v,unknown),in.intValue());
		}
		return m;
	}

	public static Monomial valueOf(int element[], Variable unknown[], jscl.util.Comparator ordering) {
		Monomial m=new Monomial(unknown,ordering);
		for(int i=0;i<element.length;i++) {
			m.put(i,element[i]);
		}
		return m;
	}

	void put(int n, int integer) {
		int c=element[n];
		int c2=c+integer;
		element[n]=c2;
		int d=c2-c;
		degree+=d;
	}

	int get(int n) {
		return element[n];
	}

	public String toString() {
		StringBuffer buffer=new StringBuffer();
		if(degree==0) buffer.append("1");
		boolean b=false;
		for(int i=0;i<element.length;i++) if(element[i]>0) {
			if(b) buffer.append("*");
			else b=true;
			Variable v=unknown[i];
			int c=element[i];
			if(c==1) buffer.append(v);
			else {
				if(v instanceof Frac) {
					buffer.append("(").append(v).append(")");
				} else buffer.append(v);
				buffer.append("^").append(c);
			}
		}
		return buffer.toString();
	}

	public String toMathML(Object data) {
		IndentedBuffer buffer=new IndentedBuffer();
		if(degree==0) buffer.append("<mn>1</mn>\n");
		for(int i=0;i<element.length;i++) if(element[i]>0) {
			int c=element[i];
			buffer.append(unknown[i].toMathML(new Integer(c)));
		}
		return buffer.toString();
	}

	protected Monomial newinstance() {
		return new Monomial(unknown,ordering);
	}
}

class Lexicographic extends jscl.util.Comparator {
	public static final jscl.util.Comparator comparator=new Lexicographic();

	private Lexicographic() {}

	public int compare(Object o1, Object o2) {
		Monomial m1=(Monomial)o1;
		Monomial m2=(Monomial)o2;
		int n=m1.element.length;
		for(int i=n-1;i>=0;i--) {
			if(m1.element[i]<m2.element[i]) return -1;
			else if(m1.element[i]>m2.element[i]) return 1;
		}
		return 0;
	}
}

class TotalDegreeLexicographic extends jscl.util.Comparator {
	public static final jscl.util.Comparator comparator=new TotalDegreeLexicographic();

	private TotalDegreeLexicographic() {}

	public int compare(Object o1, Object o2) {
		Monomial m1=(Monomial)o1;
		Monomial m2=(Monomial)o2;
		if(m1.degree()<m2.degree()) return -1;
		else if(m1.degree()>m2.degree()) return 1;
		else {
			int n=m1.element.length;
			for(int i=n-1;i>=0;i--) {
				if(m1.element[i]<m2.element[i]) return -1;
				else if(m1.element[i]>m2.element[i]) return 1;
			}
			return 0;
		}
	}
}

class DegreeReverseLexicographic extends jscl.util.Comparator {
	public static final jscl.util.Comparator comparator=new DegreeReverseLexicographic();

	private DegreeReverseLexicographic() {}

	public int compare(Object o1, Object o2) {
		Monomial m1=(Monomial)o1;
		Monomial m2=(Monomial)o2;
		if(m1.degree()<m2.degree()) return -1;
		else if(m1.degree()>m2.degree()) return 1;
		else {
			int n=m1.element.length;
			for(int i=0;i<n;i++) {
				if(m1.element[i]>m2.element[i]) return -1;
				else if(m1.element[i]<m2.element[i]) return 1;
			}
			return 0;
		}
	}
}
