package jscl.math;

public class NestedPolynomial extends UnivariatePolynomial {
	final Variable variable[];

	NestedPolynomial(Variable variable[]) {
		super(variable[0]);
		this.variable=variable;
	}

	protected Arithmetic uncoefficient(Arithmetic arithmetic) {
		if(arithmetic instanceof PolynomialWrapper) {
			return ((PolynomialWrapper)arithmetic).content().arithmeticValue();
		} else {
			return arithmetic;
		}
	}

	public static NestedPolynomial valueOf(Arithmetic arithmetic, Variable variable[]) {
		NestedPolynomial p=new NestedPolynomial(variable);
		p.put(arithmetic);
		return p;
	}

	protected Arithmetic coefficient(Arithmetic arithmetic) {
		if(variable.length>1) {
			Variable var[]=new Variable[variable.length-1];
			for(int i=0;i<var.length;i++) var[i]=variable[i+1];
			return new PolynomialWrapper(valueOf(arithmetic,var));
		} else {
			return arithmetic;
		}
	}

	protected Polynomial newinstance() {
		return new NestedPolynomial(variable);
	}
}

final class PolynomialWrapper extends Arithmetic {
	final Polynomial content;

	PolynomialWrapper(Polynomial polynomial) {
		content=polynomial;
	}

	Polynomial content() {
		return content;
	}

	public Arithmetic add(Arithmetic arithmetic) {
		if(arithmetic instanceof PolynomialWrapper) {
			return new PolynomialWrapper(content.add(((PolynomialWrapper)arithmetic).content));
		} else {
			return add(valueof(arithmetic));
		}
	}

	public Arithmetic subtract(Arithmetic arithmetic) {
		if(arithmetic instanceof PolynomialWrapper) {
			return new PolynomialWrapper(content.subtract(((PolynomialWrapper)arithmetic).content));
		} else {
			return subtract(valueof(arithmetic));
		}
	}

	public Arithmetic multiply(Arithmetic arithmetic) {
		if(arithmetic instanceof PolynomialWrapper) {
			return new PolynomialWrapper(content.multiply(((PolynomialWrapper)arithmetic).content));
		} else {
			return multiply(valueof(arithmetic));
		}
	}

	public Arithmetic divide(Arithmetic arithmetic) throws ArithmeticException {
		if(arithmetic instanceof PolynomialWrapper) {
			return new PolynomialWrapper(content.divide(((PolynomialWrapper)arithmetic).content));
		} else {
			return divide(valueof(arithmetic));
		}
	}

	public Arithmetic gcd(Arithmetic arithmetic) {
		if(arithmetic instanceof PolynomialWrapper) {
			return new PolynomialWrapper(content.gcd(((PolynomialWrapper)arithmetic).content));
		} else {
			return gcd(valueof(arithmetic));
		}
	}

	public Arithmetic gcd() {
		return content.gcd();
	}

	public Arithmetic negate() {
		return new PolynomialWrapper(content.negate());
	}

	public int signum() {
		return content.signum();
	}

	public int degree() {
		return content.degree();
	}

	public Arithmetic antiderivative(Variable variable) throws NotIntegrableException {
		return null;
	}

	public Arithmetic derivative(Variable variable) {
		return null;
	}

	public Arithmetic substitute(Variable variable, Arithmetic arithmetic) {
		return null;
	}

	public Arithmetic expand() {
		return null;
	}

	public Arithmetic factorize() {
		return null;
	}

	public Arithmetic elementary() {
		return null;
	}

	public Arithmetic simplify() {
		return null;
	}

	public Arithmetic numeric() {
		return null;
	}

	public Arithmetic valueof(Arithmetic arithmetic) {
		if(arithmetic instanceof PolynomialWrapper) {
			return new PolynomialWrapper(content.valueof(((PolynomialWrapper)arithmetic).content));
		} else {
			return new PolynomialWrapper(content.valueof(arithmetic));
		}
	}

	public Arithmetic[] sumValue() {
		return null;
	}

	public Arithmetic[] productValue() throws NotProductException {
		return null;
	}

	public Object[] powerValue() throws NotPowerException {
		return null;
	}

	public Expression expressionValue() throws NotExpressionException {
		throw new NotExpressionException();
	}

	public JSCLInteger integerValue() throws NotIntegerException {
		throw new NotIntegerException();
	}

	public Variable variableValue() throws NotVariableException {
		throw new NotVariableException();
	}

	public Variable[] variables() {
		return new Variable[0];
	}

	public boolean isPolynomial(Variable variable) {
		return false;
	}

	public boolean isConstant(Variable variable) {
		return false;
	}

	public int compareTo(Object comparable) {
		if(comparable instanceof PolynomialWrapper) {
			return content.compareTo(((PolynomialWrapper)comparable).content);
		} else {
			return compareTo(valueof((Arithmetic)comparable));
		}
	}

	public String toString() {
		StringBuffer buffer=new StringBuffer();
		if(signum()<0) buffer.append("-").append(negate());
		else buffer.append("(").append(content).append(")");
		return buffer.toString();
	}

	public String toJava() {
		return null;
	}

	public String toMathML(Object data) {
		return null;
	}

	protected Arithmetic newinstance() {
		return null;
	}
}
