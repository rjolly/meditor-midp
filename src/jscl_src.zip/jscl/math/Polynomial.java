package jscl.math;

import java.math.*;
import java.util.*;
import jscl.util.*;

public class Polynomial extends Arithmetic {
	final Variable unknown[];
	final jscl.util.Comparator ordering;
	final int modulo;
	final Betatree content=new Betatree(16,GenericComparator.comparator);
	int degree;

	Polynomial(Variable unknown[], jscl.util.Comparator ordering, int modulo) {
		this.unknown=unknown;
		this.ordering=ordering;
		this.modulo=modulo;
	}

	public static Variable[] unknown(Arithmetic arithmetic) {
		Vector w=new Vector();
		Literal l=Expression.valueOf(arithmetic).variables();
		Enumeration k=l.content.keys();
		while(k.hasMoreElements()) {
			Variable v=(Variable)k.nextElement();
			w.addElement(v);
		}
		Variable in[]=new Variable[w.size()];
		w.copyInto(in);
		return in;
	}

	public Arithmetic add(Arithmetic arithmetic) {
		if(arithmetic instanceof Polynomial) {
			Polynomial p=(Polynomial)arithmetic;
			Polynomial p2=(Polynomial)valueof(this);
			Enumeration k=p.content.keys();
			Enumeration e=p.content.elements();
			while(k.hasMoreElements()) {
				p2.put(
					(Monomial)k.nextElement(),
					(Arithmetic)e.nextElement()
				);
			}
			return p2;
		} else return add(valueof(arithmetic));
	}

	public Arithmetic subtract(Arithmetic arithmetic) {
		if(arithmetic instanceof Polynomial) {
			Polynomial p=(Polynomial)arithmetic;
			Polynomial p2=(Polynomial)valueof(this);
			Enumeration k=p.content.keys();
			Enumeration e=p.content.elements();
			while(k.hasMoreElements()) {
				p2.put(
					(Monomial)k.nextElement(),
					((Arithmetic)e.nextElement()).negate()
				);
			}
			return p2;
		} else return subtract(valueof(arithmetic));
	}

	public Arithmetic multiply(Arithmetic arithmetic) {
		if(arithmetic instanceof Polynomial) {
			Polynomial p=(Polynomial)arithmetic;
			Polynomial p2=(Polynomial)newinstance();
			Enumeration k2=p.content.keys();
			Enumeration e2=p.content.elements();
			while(k2.hasMoreElements()) {
				Monomial m=(Monomial)k2.nextElement();
				Arithmetic a=(Arithmetic)e2.nextElement();
				Enumeration k=content.keys();
				Enumeration e=content.elements();
				while(k.hasMoreElements()) {
					p2.put(
						(Monomial)((Monomial)k.nextElement()).multiply(m),
						((Arithmetic)e.nextElement()).multiply(a)
					);
				}
			}
			return p2;
		} else {
			Polynomial p=(Polynomial)newinstance();
			Enumeration k=content.keys();
			Enumeration e=content.elements();
			while(k.hasMoreElements()) {
				p.put(
					(Monomial)k.nextElement(),
					((Arithmetic)e.nextElement()).multiply(arithmetic)
				);
			}
			return p;
		}
	}

	public Arithmetic divide(Arithmetic arithmetic) throws ArithmeticException {
		if(arithmetic instanceof Polynomial) {
			return null;
		} else {
			Polynomial p=(Polynomial)newinstance();
			Enumeration k=content.keys();
			Enumeration e=content.elements();
			while(k.hasMoreElements()) {
				p.put(
					(Monomial)k.nextElement(),
					((Arithmetic)e.nextElement()).divide(arithmetic)
				);
			}
			return p;
		}
	}

	public Arithmetic[] divideAndRemainder(Arithmetic arithmetic) throws ArithmeticException {
		return null;
	}

	public Arithmetic gcd(Arithmetic arithmetic) {
		return null;
	}

	public Arithmetic gcd() {
		Arithmetic a=JSCLInteger.valueOf(0);
		for(Enumeration e=content.elements();e.hasMoreElements();) {
			a=a.gcd((Arithmetic)e.nextElement());
		}
		return a;
	}

	public Arithmetic[] gcdAndNormalize() {
		if(modulo>0 && signum()!=0) try {
			JSCLInteger en=((Arithmetic)content.elements(true).nextElement()).integerValue();
			return new Arithmetic[] {null,multiply(en.modInverse(JSCLInteger.valueOf(modulo)))};
		} catch (NotIntegerException e) {
		} catch (ArithmeticException e) {}
		return super.gcdAndNormalize();
	}

	public Arithmetic negate() {
		Polynomial p=(Polynomial)newinstance();
		return p.subtract(this);
	}

	public int signum() {
		if(content.isEmpty()) return 0;
		else return ((Arithmetic)content.elements().nextElement()).signum();
	}

	public int degree() {
		return degree;
	}

	public Arithmetic antiderivative(Variable variable) throws NotIntegrableException {
		return null;
	}

	public Arithmetic derivative(Variable variable) {
		return null;
	}

	public Arithmetic substitute(Variable variable, Arithmetic arithmetic) {
		Arithmetic a=Expression.valueOf(this).substitute(variable,arithmetic);
		return valueof(a);
	}

	public Arithmetic expand() {
		Arithmetic a=Expression.valueOf(this).expand();
		return valueof(a);
	}

	public Factorized factorize() {
		return null;
	}

	public Arithmetic elementary() {
		Arithmetic a=Expression.valueOf(this).elementary();
		return valueof(a);
	}

	public Arithmetic simplify() {
		Arithmetic a=Expression.valueOf(this).simplify();
		return valueof(a);
	}

	public Arithmetic valueof(Arithmetic arithmetic) {
		Polynomial p=(Polynomial)newinstance();
		p.put(arithmetic);
		return p;
	}

	public Arithmetic[] sumValue() {
		return null;
	}

	public Arithmetic[] productValue() throws NotProductException {
		return null;
	}

	public Object[] powerValue() throws NotPowerException {
		return null;
	}

	public JSCLInteger integerValue() throws NotIntegerException {
		return null;
	}

	public Variable variableValue() throws NotVariableException {
		return null;
	}

	public boolean isPolynomial(Variable variable) {
		return false;
	}

	public boolean isConstant(Variable variable) {
		return false;
	}

	public int compareTo(jscl.util.Comparable comparable) {
		if(comparable instanceof Polynomial) {
			Polynomial p=(Polynomial)comparable;
			Enumeration k1=content.keys(true);
			Enumeration e1=content.elements(true);
			Enumeration k2=p.content.keys(true);
			Enumeration e2=p.content.elements(true);
			while(true) {
				boolean b1=!k1.hasMoreElements();
				boolean b2=!k2.hasMoreElements();
				if(b1 && b2) return 0;
				else if(b1) return -1;
				else if(b2) return 1;
				else {
					Monomial m1=(Monomial)k1.nextElement();
					Monomial m2=(Monomial)k2.nextElement();
					int c=m1.compareTo(m2);
					if(c<0) return -1;
					else if(c>0) return 1;
					else {
						Arithmetic a1=(Arithmetic)e1.nextElement();
						Arithmetic a2=(Arithmetic)e2.nextElement();
						c=a1.compareTo(a2);
						if(c<0) return -1;
						else if(c>0) return 1;
					}
				}
			}
		} else {
			return compareTo(valueof((Arithmetic)comparable));
		}
	}

	public Arithmetic[] element() {
		Arithmetic a[]=new Arithmetic[content.size()];
		Enumeration e=content.elements();
		for(int i=0;e.hasMoreElements();i++) {
			a[i]=(Arithmetic)e.nextElement();
		}
		return a;
	}

	public static Polynomial valueOf(Arithmetic arithmetic, Variable unknown[], jscl.util.Comparator ordering, int modulo) {
		Polynomial p=new Polynomial(unknown,ordering,modulo);
		p.put(arithmetic);
		return p;
	}

	void put(Arithmetic arithmetic) {
		if(arithmetic instanceof Polynomial) {
			Polynomial p=(Polynomial)arithmetic;
			if(p.unknown==unknown && p.ordering==ordering && p.modulo==modulo) {

				Enumeration k=p.content.keys();
				Enumeration e=p.content.elements();
				while(k.hasMoreElements()) {
					put(
						(Monomial)k.nextElement(),
						(Arithmetic)e.nextElement()
					);
				}
			} else put(Expression.valueOf(arithmetic));
		} else if(arithmetic instanceof Expression) {
			Expression ex=(Expression)arithmetic;
			Enumeration k=ex.content.keys();
			Enumeration e=ex.content.elements();
			while(k.hasMoreElements()) {
				Literal l=(Literal)k.nextElement();
				JSCLInteger en=(JSCLInteger)e.nextElement();
				Literal ll[]=l.separate(unknown);
				Monomial m=Monomial.valueOf(ll[1],unknown,ordering);
				l=ll[0];
				if(l.degree()>0) {
					Expression ex2=new Expression();
					ex2.put(l,en);
					put(m,ex2);
				} else {
					put(m,modulo>0?modularInteger(en):en);
				}
			}
		} else put(Expression.valueOf(arithmetic));
	}

	ModularInteger modularInteger(JSCLInteger integer) {
		ModularInteger e=new ModularInteger(modulo);
		e.put(integer.content);
		return e;
	}

	static Arithmetic unmodulo(Arithmetic arithmetic) {
		if(arithmetic instanceof JSCLInteger) {
			JSCLInteger e=new JSCLInteger();
			e.put(((JSCLInteger)arithmetic).content);
			return e;
		} else return arithmetic;
	}

	void put(Monomial monomial, Arithmetic arithmetic) {
		if(content.containsKey(monomial)) {
			Arithmetic a=arithmetic.add((Arithmetic)content.get(monomial));
			if(a.signum()==0) content.remove(monomial);
			else content.put(monomial,a);
		} else {
			if(arithmetic.signum()==0);
			else content.put(monomial,arithmetic);
		}
		if(signum()==0) degree=0;
		else degree=((Monomial)content.keys(true).nextElement()).degree();
	}

	public String toString() {
		StringBuffer buffer=new StringBuffer();
		if(signum()==0) buffer.append("0");
		Enumeration k=content.keys();
		Enumeration e=content.elements();
		for(int i=0;k.hasMoreElements();i++) {
			Monomial m=(Monomial)k.nextElement();
			Arithmetic a=(Arithmetic)e.nextElement();
			if(a instanceof Expression) a=a.signum()==1?new ExpressionVariable(a).expressionValue():new ExpressionVariable(a.negate()).expressionValue().negate();
			if(a.signum()==1 && i>0) buffer.append("+");
			if(m.degree()==0) buffer.append(a);
			else {
				if(a.compareTo(JSCLInteger.valueOf(1))==0);
				else if(a.compareTo(JSCLInteger.valueOf(-1))==0) buffer.append("-");
				else buffer.append(a).append("*");
				buffer.append(m);
			}
		}
		return buffer.toString();
	}

	public String toMathML(Object data) {
		IndentedBuffer buffer=new IndentedBuffer();
		buffer.append("<mrow>\n");
		if(signum()==0) buffer.append(1,"<mn>0</mn>\n");
		Enumeration k=content.keys();
		Enumeration e=content.elements();
		for(int i=0;k.hasMoreElements();i++) {
			Monomial m=(Monomial)k.nextElement();
			Arithmetic a=(Arithmetic)e.nextElement();
			if(a instanceof Expression) a=a.signum()==1?new ExpressionVariable(a).expressionValue():new ExpressionVariable(a.negate()).expressionValue().negate();
			if(a.signum()==1 && i>0) buffer.append(1,"<mo>+</mo>\n");
			if(m.degree()==0) buffer.append(1,Expression.separateSign(a));
			else {
				if(a.compareTo(JSCLInteger.valueOf(1))==0);
				else if(a.compareTo(JSCLInteger.valueOf(-1))==0) buffer.append(1,"<mo>-</mo>\n");
				else buffer.append(1,Expression.separateSign(a));
				buffer.append(1,m.toMathML(null));
			}
		}
		buffer.append("</mrow>\n");
		return buffer.toString();
	}

	protected Arithmetic newinstance() {
		return new Polynomial(unknown,ordering,modulo);
	}
}

class ModularInteger extends JSCLInteger {
	final int modulo;

	public ModularInteger(int modulo) {
		this.modulo=modulo;
		mod=BigInteger.valueOf(modulo);
	}

	void put(BigInteger b) {
		super.put(b.mod(mod));
	}

	protected Arithmetic newinstance() {
		return new ModularInteger(modulo);
	}

	private BigInteger mod;
}
