package jscl.math;

import java.math.*;
import java.util.*;
import jscl.util.*;

public class Polynomial extends Arithmetic {
	final Variable unknown[];
	final Comparator ordering;
	final int modulo;
	final MySortedMap content=new MyTreeMap();
	int degree;

	Polynomial(Variable unknown[], Comparator ordering, int modulo) {
		this.unknown=unknown;
		this.ordering=ordering;
		this.modulo=modulo;
	}

	public static Variable[] unknown(Arithmetic arithmetic) {
		Vector w=new Vector();
		Literal l=Expression.valueOf(arithmetic).variables();
		Iterator it=l.content.keySet().iterator();
		while(it.hasNext()) {
			Variable v=(Variable)it.next();
			w.addElement(v);
		}
		Variable in[]=new Variable[w.size()];
		w.copyInto(in);
		return in;
	}

	public Arithmetic add(Arithmetic arithmetic) {
		if(arithmetic instanceof Polynomial) {
			Polynomial p=(Polynomial)arithmetic;
			Polynomial p2=(Polynomial)valueof(this);
			Iterator it=p.content.entrySet().iterator();
			while(it.hasNext()) {
				Map.Entry e=(Map.Entry)it.next();
				p2.put(
					(Monomial)e.getKey(),
					(Arithmetic)e.getValue()
				);
			}
			return p2;
		} else return add(valueof(arithmetic));
	}

	public Arithmetic subtract(Arithmetic arithmetic) {
		if(arithmetic instanceof Polynomial) {
			Polynomial p=(Polynomial)arithmetic;
			Polynomial p2=(Polynomial)valueof(this);
			Iterator it=p.content.entrySet().iterator();
			while(it.hasNext()) {
				Map.Entry e=(Map.Entry)it.next();
				p2.put(
					(Monomial)e.getKey(),
					((Arithmetic)e.getValue()).negate()
				);
			}
			return p2;
		} else return subtract(valueof(arithmetic));
	}

	public Arithmetic multiply(Arithmetic arithmetic) {
		if(arithmetic instanceof Polynomial) {
			Polynomial p=(Polynomial)arithmetic;
			Polynomial p2=(Polynomial)newinstance();
			Iterator it2=p.content.entrySet().iterator();
			while(it2.hasNext()) {
				Map.Entry e2=(Map.Entry)it2.next();
				Monomial m=(Monomial)e2.getKey();
				Arithmetic a=(Arithmetic)e2.getValue();
				Iterator it=content.entrySet().iterator();
				while(it.hasNext()) {
					Map.Entry e=(Map.Entry)it.next();
					p2.put(
						(Monomial)((Monomial)e.getKey()).multiply(m),
						((Arithmetic)e.getValue()).multiply(a)
					);
				}
			}
			return p2;
		} else {
			Polynomial p=(Polynomial)newinstance();
			Iterator it=content.entrySet().iterator();
			while(it.hasNext()) {
				Map.Entry e=(Map.Entry)it.next();
				p.put(
					(Monomial)e.getKey(),
					((Arithmetic)e.getValue()).multiply(arithmetic)
				);
			}
			return p;
		}
	}

	public Arithmetic divide(Arithmetic arithmetic) throws ArithmeticException {
		if(arithmetic instanceof Polynomial) {
			return null;
		} else {
			Polynomial p=(Polynomial)newinstance();
			Iterator it=content.entrySet().iterator();
			while(it.hasNext()) {
				Map.Entry e=(Map.Entry)it.next();
				p.put(
					(Monomial)e.getKey(),
					((Arithmetic)e.getValue()).divide(arithmetic)
				);
			}
			return p;
		}
	}

	public Arithmetic[] divideAndRemainder(Arithmetic arithmetic) throws ArithmeticException {
		return null;
	}

	public Arithmetic gcd(Arithmetic arithmetic) {
		return null;
	}

	public Arithmetic gcd() {
		Arithmetic a=JSCLInteger.valueOf(0);
		for(Iterator it=content.values().iterator();it.hasNext();) {
			a=a.gcd((Arithmetic)it.next());
		}
		return a;
	}

	public Arithmetic[] gcdAndNormalize() {
		if(modulo>0 && signum()!=0) try {
			JSCLInteger en=((Arithmetic)headTerm().getValue()).integerValue();
			return new Arithmetic[] {null,multiply(en.modInverse(JSCLInteger.valueOf(modulo)))};
		} catch (NotIntegerException e) {
		} catch (ArithmeticException e) {}
		return super.gcdAndNormalize();
	}

	Map.Entry headTerm() {
		return (Map.Entry)content.entrySet().iterator(true).next();
	}

	public Arithmetic negate() {
		Polynomial p=(Polynomial)newinstance();
		return p.subtract(this);
	}

	public int signum() {
		if(content.isEmpty()) return 0;
		else return ((Arithmetic)content.values().iterator().next()).signum();
	}

	public int degree() {
		return degree;
	}

	public Arithmetic antiderivative(Variable variable) throws NotIntegrableException {
		return null;
	}

	public Arithmetic derivative(Variable variable) {
		return null;
	}

	public Arithmetic substitute(Variable variable, Arithmetic arithmetic) {
		Arithmetic a=Expression.valueOf(this).substitute(variable,arithmetic);
		return valueof(a);
	}

	public Arithmetic expand() {
		Arithmetic a=Expression.valueOf(this).expand();
		return valueof(a);
	}

	public Factorized factorize() {
		return null;
	}

	public Arithmetic elementary() {
		Arithmetic a=Expression.valueOf(this).elementary();
		return valueof(a);
	}

	public Arithmetic simplify() {
		Arithmetic a=Expression.valueOf(this).simplify();
		return valueof(a);
	}

	public Arithmetic valueof(Arithmetic arithmetic) {
		Polynomial p=(Polynomial)newinstance();
		p.put(arithmetic);
		return p;
	}

	public Arithmetic[] sumValue() {
		return null;
	}

	public Arithmetic[] productValue() throws NotProductException {
		return null;
	}

	public Object[] powerValue() throws NotPowerException {
		return null;
	}

	public JSCLInteger integerValue() throws NotIntegerException {
		return null;
	}

	public Variable variableValue() throws NotVariableException {
		return null;
	}

	public boolean isPolynomial(Variable variable) {
		return false;
	}

	public boolean isConstant(Variable variable) {
		return false;
	}

	public int compareTo(Object comparable) {
		if(comparable instanceof Polynomial) {
			Polynomial p=(Polynomial)comparable;
			Iterator it1=content.entrySet().iterator(true);
			Iterator it2=p.content.entrySet().iterator(true);
			while(true) {
				boolean b1=!it1.hasNext();
				boolean b2=!it2.hasNext();
				if(b1 && b2) return 0;
				else if(b1) return -1;
				else if(b2) return 1;
				else {
					Map.Entry e1=(Map.Entry)it1.next();
					Map.Entry e2=(Map.Entry)it2.next();
					Monomial m1=(Monomial)e1.getKey();
					Monomial m2=(Monomial)e2.getKey();
					int c=m1.compareTo(m2);
					if(c<0) return -1;
					else if(c>0) return 1;
					else {
						Arithmetic a1=(Arithmetic)e1.getValue();
						Arithmetic a2=(Arithmetic)e2.getValue();
						c=a1.compareTo(a2);
						if(c<0) return -1;
						else if(c>0) return 1;
					}
				}
			}
		} else {
			return compareTo(valueof((Arithmetic)comparable));
		}
	}

	public Arithmetic[] element() {
		Arithmetic a[]=new Arithmetic[content.size()];
		Iterator it=content.values().iterator();
		for(int i=0;it.hasNext();i++) {
			a[i]=(Arithmetic)it.next();
		}
		return a;
	}

	public static Polynomial valueOf(Arithmetic arithmetic, Variable unknown[], Comparator ordering, int modulo) {
		Polynomial p=new Polynomial(unknown,ordering,modulo);
		p.put(arithmetic);
		return p;
	}

	void put(Arithmetic arithmetic) {
		if(arithmetic instanceof Polynomial) {
			Polynomial p=(Polynomial)arithmetic;
			if(p.unknown==unknown && p.ordering==ordering && p.modulo==modulo) {

				Iterator it=p.content.entrySet().iterator();
				while(it.hasNext()) {
					Map.Entry e=(Map.Entry)it.next();
					put(
						(Monomial)e.getKey(),
						(Arithmetic)e.getValue()
					);
				}
			} else put(Expression.valueOf(arithmetic));
		} else if(arithmetic instanceof Expression) {
			Expression ex=(Expression)arithmetic;
			Iterator it=ex.content.entrySet().iterator();
			while(it.hasNext()) {
				Map.Entry e=(Map.Entry)it.next();
				Literal l=(Literal)e.getKey();
				JSCLInteger en=(JSCLInteger)e.getValue();
				Literal ll[]=l.separate(unknown);
				Monomial m=Monomial.valueOf(ll[1],unknown,ordering);
				l=ll[0];
				if(l.degree()>0) {
					Expression ex2=new Expression();
					ex2.put(l,en);
					put(m,ex2);
				} else {
					put(m,modulo>0?modularInteger(en):en);
				}
			}
		} else put(Expression.valueOf(arithmetic));
	}

	ModularInteger modularInteger(JSCLInteger integer) {
		ModularInteger e=new ModularInteger(modulo);
		e.put(integer.content);
		return e;
	}

	static Arithmetic unmodulo(Arithmetic arithmetic) {
		if(arithmetic instanceof JSCLInteger) {
			JSCLInteger e=new JSCLInteger();
			e.put(((JSCLInteger)arithmetic).content);
			return e;
		} else return arithmetic;
	}

	void put(Monomial monomial, Arithmetic arithmetic) {
//		Object o=content.get(monomial);
//		if(o!=null) {
//			Arithmetic a=arithmetic.add((Arithmetic)o);
		Map.Entry e=content.myGetEntry(monomial);
		if(e!=null) {
			Arithmetic a=arithmetic.add((Arithmetic)e.getValue());
			if(a.signum()==0) content.remove(monomial);
//			else content.put(monomial,a);
			else e.setValue(a);
		} else {
			if(arithmetic.signum()==0);
			else content.put(monomial,arithmetic);
		}
		if(content.isEmpty()) degree=0;
		else degree=((Monomial)content.lastKey()).degree();
	}

	public String toString() {
		StringBuffer buffer=new StringBuffer();
		if(signum()==0) buffer.append("0");
		Iterator it=content.entrySet().iterator();
		for(int i=0;it.hasNext();i++) {
			Map.Entry e=(Map.Entry)it.next();
			Monomial m=(Monomial)e.getKey();
			Arithmetic a=(Arithmetic)e.getValue();
			if(a instanceof Expression) a=a.signum()==1?new ExpressionVariable(a).expressionValue():new ExpressionVariable(a.negate()).expressionValue().negate();
			if(a.signum()==1 && i>0) buffer.append("+");
			if(m.degree()==0) buffer.append(a);
			else {
				if(a.compareTo(JSCLInteger.valueOf(1))==0);
				else if(a.compareTo(JSCLInteger.valueOf(-1))==0) buffer.append("-");
				else buffer.append(a).append("*");
				buffer.append(m);
			}
		}
		return buffer.toString();
	}

	public String toMathML(Object data) {
		IndentedBuffer buffer=new IndentedBuffer();
		buffer.append("<mrow>\n");
		if(signum()==0) buffer.append(1,"<mn>0</mn>\n");
		Iterator it=content.entrySet().iterator();
		for(int i=0;it.hasNext();i++) {
			Map.Entry e=(Map.Entry)it.next();
			Monomial m=(Monomial)e.getKey();
			Arithmetic a=(Arithmetic)e.getValue();
			if(a instanceof Expression) a=a.signum()==1?new ExpressionVariable(a).expressionValue():new ExpressionVariable(a.negate()).expressionValue().negate();
			if(a.signum()==1 && i>0) buffer.append(1,"<mo>+</mo>\n");
			if(m.degree()==0) buffer.append(1,Expression.separateSign(a));
			else {
				if(a.compareTo(JSCLInteger.valueOf(1))==0);
				else if(a.compareTo(JSCLInteger.valueOf(-1))==0) buffer.append(1,"<mo>-</mo>\n");
				else buffer.append(1,Expression.separateSign(a));
				buffer.append(1,m.toMathML(null));
			}
		}
		buffer.append("</mrow>\n");
		return buffer.toString();
	}

	protected Arithmetic newinstance() {
		return new Polynomial(unknown,ordering,modulo);
	}
}

class ModularInteger extends JSCLInteger {
	final int modulo;

	public ModularInteger(int modulo) {
		this.modulo=modulo;
		mod=BigInteger.valueOf(modulo);
	}

	void put(BigInteger b) {
		super.put(b.mod(mod));
	}

	protected Arithmetic newinstance() {
		return new ModularInteger(modulo);
	}

	private BigInteger mod;
}
