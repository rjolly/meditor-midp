package jscl.math;

public class NotVariableException extends ArithmeticException {
	public NotVariableException() {}

	public NotVariableException(String s) {
		super(s);
	}
}
