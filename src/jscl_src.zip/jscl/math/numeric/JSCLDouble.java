package jscl.math.numeric;

public final class JSCLDouble extends Numeric {
	double content;

	JSCLDouble(double val) {
		content=val;
	}

	public Numeric add(Numeric numeric) {
		if(numeric instanceof JSCLDouble) {
			return new JSCLDouble(content+((JSCLDouble)numeric).content);
		} else {
			return numeric.valueof(this).add(numeric);
		}
	}

	public Numeric subtract(Numeric numeric) {
		if(numeric instanceof JSCLDouble) {
			return new JSCLDouble(content-((JSCLDouble)numeric).content);
		} else {
			return numeric.valueof(this).subtract(numeric);
		}
	}

	public Numeric multiply(Numeric numeric) {
		if(numeric instanceof JSCLDouble) {
			return new JSCLDouble(content*((JSCLDouble)numeric).content);
		} else {
			return numeric.multiply(this);
		}
	}

	public Numeric divide(Numeric numeric) throws ArithmeticException {
		if(numeric instanceof JSCLDouble) {
			return new JSCLDouble(content/((JSCLDouble)numeric).content);
		} else {
			return numeric.valueof(this).divide(numeric);
		}
	}

	public Numeric negate() {
		return new JSCLDouble(-content);
	}

	public int signum() {
		return content==0.?0:(content<0.?-1:1);
	}

	public Numeric log() {
		return new JSCLDouble(Math.log(content));
	}

	public Numeric exp() {
		return new JSCLDouble(Math.exp(content));
	}

	public Numeric sqrt() {
		if(signum()>=0) {
			return new JSCLDouble(Math.sqrt(content));
		} else {
			return Complex.valueOf(0,1).multiply(negate().sqrt());
		}
	}

	public Numeric acos() {
		return new JSCLDouble(Math.acos(content));
	}

	public Numeric asin() {
		return new JSCLDouble(Math.asin(content));
	}

	public Numeric atan() {
		return new JSCLDouble(Math.atan(content));
	}

	public Numeric cos() {
		return new JSCLDouble(Math.cos(content));
	}

	public Numeric sin() {
		return new JSCLDouble(Math.sin(content));
	}

	public Numeric tan() {
		return new JSCLDouble(Math.tan(content));
	}

	public Numeric valueof(Numeric numeric) {
		if(numeric instanceof JSCLDouble) {
			return new JSCLDouble(((JSCLDouble)numeric).content);
		} else throw new ArithmeticException();
	}

	public double doubleValue() {
		return content;
	}

	public int compareTo(Object comparable) {
		if(comparable instanceof JSCLDouble) {
			JSCLDouble d=(JSCLDouble)comparable;
			if(content<d.content) return -1;
			else if(content>d.content) return 1;
			else if(content==d.content) return 0;
			else throw new ArithmeticException();
		} else {
			return ((Numeric)comparable).valueof(this).compareTo(comparable);
		}
	}

	public static JSCLDouble valueOf(double val) {
		return new JSCLDouble(val);
	}

	public String toString() {
		return new Double(content).toString();
	}

	protected Numeric newinstance() {
		return null;
	}
}
