package jscl.math.numeric;

public final class Complex extends Numeric {
	double real, imag;

	Complex(double real, double imag) {
		this.real=real;
		this.imag=imag;
	}

	public Numeric add(Numeric numeric) {
		if(numeric instanceof Complex) {
			Complex c=(Complex)numeric;
			return new Complex(real+c.real,imag+c.imag);
		} else if(numeric instanceof JSCLDouble) {
			return add(valueof(numeric));
		} else {
			return numeric.valueof(this).add(numeric);
		}
	}

	public Numeric subtract(Numeric numeric) {
		if(numeric instanceof Complex) {
			Complex c=(Complex)numeric;
			return new Complex(real-c.real,imag-c.imag);
		} else if(numeric instanceof JSCLDouble) {
			return subtract(valueof(numeric));
		} else {
			return numeric.valueof(this).subtract(numeric);
		}
	}

	public Numeric multiply(Numeric numeric) {
		if(numeric instanceof Complex) {
			Complex c=(Complex)numeric;
			return new Complex(real*c.real-imag*c.imag,real*c.imag+imag*c.real);
		} else if(numeric instanceof JSCLDouble) {
			return multiply(valueof(numeric));
		} else {
			return numeric.multiply(this);
		}
	}

	public Numeric divide(Numeric numeric) {
		if(numeric instanceof Complex) {
			return multiply(((Complex)numeric).inverse());
		} else if(numeric instanceof JSCLDouble) {
			return divide(valueof(numeric));
		} else {
			return numeric.valueof(this).divide(numeric);
		}
	}

	public Numeric negate() {
		return new Complex(-real,-imag);
	}

	public int signum() {
		return imag==0.?(real==0.?0:(real<0.?-1:1)):(imag<0.?-1:1);
	}

	public Numeric valueof(Numeric numeric) {
		if(numeric instanceof Complex) {
			Complex c=(Complex)numeric;
			return new Complex(c.real,c.imag);
		} else if(numeric instanceof JSCLDouble) {
			JSCLDouble d=(JSCLDouble)numeric;
			return new Complex(d.content,0.);
		} else throw new ArithmeticException();
	}

	public double magnitude() {
		return Math.sqrt(real*real+imag*imag);
	}

	public double magnitude2() {
		return real*real+imag*imag;
	}

	public double angle() {
		return Math.atan2(imag,real);
	}

	public Numeric log() {
		return new Complex(Math.log(magnitude()),angle());
	}

	public Numeric exp() {
		return new Complex(Math.cos(imag),Math.sin(imag)).multiply(Math.exp(real));
	}

	Complex multiply(double d) {
		return new Complex(real*d,imag*d);
	}

	public Numeric conjugate() {
		return new Complex(real,-imag);
	}

	public Complex inverse() {
		return ((Complex)conjugate()).divide(magnitude2());
	}

	Complex divide(double d) {
		return new Complex(real/d,imag/d);
	}

	public double realPart() {
		return real;
	}

	public double imaginaryPart() {
		return imag;
	}

	public int compareTo(Object comparable) {
		if(comparable instanceof Complex) {
			Complex c=(Complex)comparable;
			if(imag<c.imag) return -1;
			else if(imag>c.imag) return 1;
			else if(imag==c.imag) {
				if(real<c.real) return -1;
				else if(real>c.real) return 1;
				else if(real==c.real) return 0;
				else throw new ArithmeticException();
			} else throw new ArithmeticException();
		} else if(comparable instanceof JSCLDouble) {
			return compareTo(valueof((Numeric)comparable));
		} else {
			return ((Numeric)comparable).valueof(this).compareTo(comparable);
		}
	}

	public static Complex valueOf(double real, double imag) {
		return new Complex(real,imag);
	}

	public String toString() {
		StringBuffer buffer=new StringBuffer();
		if(imag==0.) {
			buffer.append(real);
		} else {
			if(real==0.);
			else {
				buffer.append(real);
				if(imag>0.) buffer.append("+");
			}
			if(imag==1.);
			else if(imag==-1.) buffer.append("-");
			else {
				buffer.append(imag);
				buffer.append("*");
			}
			buffer.append("sqrt(-1)");
		}
		return buffer.toString();
	}

	protected Numeric newinstance() {
		return null;
	}
}
