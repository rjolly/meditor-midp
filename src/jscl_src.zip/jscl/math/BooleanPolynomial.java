package jscl.math;

import java.util.*;
import jscl.util.*;

public class BooleanPolynomial extends MultivariatePolynomial {
	static final JSCLInteger ZERO=JSCLInteger.valueOf(0);
	static final JSCLInteger ONE=JSCLInteger.valueOf(1);
	static final JSCLInteger mod=JSCLInteger.valueOf(2);

	BooleanPolynomial(Variable unknown[], Comparator ordering) {
		super(unknown,ordering);
	}

	public Polynomial normalize() {
		return this;
	}

	public Polynomial s_polynomial(Polynomial polynomial) {
		BooleanPolynomial p2=(BooleanPolynomial)polynomial;
		Monomial m1=headMonomial();
		Monomial m2=p2.headMonomial();
		Monomial m=m1.scm(m2);
		m1=m.divide(m1);
		m2=m.divide(m2);
		BooleanPolynomial p=(BooleanPolynomial)multiply(m1);
		p.mutableReduce(p2,m2);
		return p;
	}

	public Polynomial reduce(Basis basis) {
		BooleanPolynomial p=(BooleanPolynomial)valueof(this);
		loop: while(p.signum()!=0) {
			Monomial m1=p.headMonomial();
			Iterator it=basis.content.values().iterator();
			while(it.hasNext()) {
				BooleanPolynomial q=(BooleanPolynomial)it.next();
				Monomial m2=q.headMonomial();
				if(m1.multiple(m2)) {
					Monomial m=m1.divide(m2);
					p.mutableReduce(q,m);
					continue loop;
				}
			}
			break;
		}
		return p;
	}

	public Polynomial reduceCompletely(Basis basis) {
		BooleanPolynomial p=(BooleanPolynomial)valueof(this);
		Monomial l=null;
		loop: while(p.signum()!=0) {
			Iterator it=(l==null?p.content:p.content.headMap(l)).entrySet().iterator(true);
			while(it.hasNext()) {
				Map.Entry e1=(Map.Entry)it.next();
				Monomial m1=(Monomial)e1.getKey();
				Iterator it2=basis.content.values().iterator();
				while(it2.hasNext()) {
					BooleanPolynomial q=(BooleanPolynomial)it2.next();
					Monomial m2=q.headMonomial();
					if(m1.multiple(m2)) {
						Monomial m=m1.divide(m2);
						p.mutableReduce(q,m);
						l=m1;
						continue loop;
					}
				}
			}
			break;
		}
		return p;
	}

	void mutableReduce(BooleanPolynomial p2, Monomial m2) {
		Iterator it=p2.content.entrySet().iterator();
		while(it.hasNext()) {
			Map.Entry e=(Map.Entry)it.next();
			put(
				((Monomial)e.getKey()).multiply(m2),
				(Arithmetic)e.getValue()
			);
		}
		sugar=Math.max(sugar,p2.sugar+m2.degree());
	}

	protected Arithmetic uncoefficient(Arithmetic arithmetic) {
		return arithmetic;
	}

	protected Arithmetic coefficient(Arithmetic arithmetic) {
		return ((JSCLInteger)arithmetic).mod(mod);
	}

	void put(Monomial monomial, Arithmetic arithmetic) {
		if(arithmetic.signum()==0) return;
		Object o=content.get(monomial);
		if(o!=null) content.remove(monomial);
		else content.put(monomial,ONE);
		if(content.isEmpty()) degree=0;
		else degree=headMonomial().degree();
	}

	protected Polynomial newinstance() {
		return new BooleanPolynomial(unknown,ordering);
	}
}
