package jscl.math;

import java.util.*;

public class BooleanPolynomial extends ModularPolynomial {
	static final Integer ONE=new Integer(1);

	BooleanPolynomial(Variable unknown[], Comparator ordering) {
		super(unknown,ordering,2);
	}

	public Polynomial normalize() {
		return this;
	}

	public Polynomial s_polynomial(Polynomial polynomial) {
		BooleanPolynomial p2=(BooleanPolynomial)polynomial;
		Monomial m1=headMonomial();
		Monomial m2=p2.headMonomial();
		Monomial m=m1.gcd(m2);
		m1=m1.divide(m);
		m2=m2.divide(m);
		BooleanPolynomial p=(BooleanPolynomial)multiply(m2);
		p.mutableReduce(p2,m1);
		return p;
	}

	public Polynomial reduce(Basis basis, boolean completely, boolean tail) {
		BooleanPolynomial p=(BooleanPolynomial)valueof(this);
		Monomial l=null;
		loop: while(p.signum()!=0) {
			Iterator it=p.subContent(l,completely,tail).entrySet().iterator(true);
			while(it.hasNext()) {
				Map.Entry e1=(Map.Entry)it.next();
				Monomial m1=(Monomial)e1.getKey();
				Iterator it2=basis.content.values().iterator();
				while(it2.hasNext()) {
					BooleanPolynomial q=(BooleanPolynomial)it2.next();
					Monomial m2=q.headMonomial();
					if(m1.multiple(m2)) {
						Monomial m=m1.divide(m2);
						p.mutableReduce(q,m);
						l=m1;
						continue loop;
					}
				}
			}
			break;
		}
		return p;
	}

	void mutableReduce(BooleanPolynomial p, Monomial m) {
		Iterator it=p.content.entrySet().iterator();
		while(it.hasNext()) {
			Map.Entry e=(Map.Entry)it.next();
			put(
				((Monomial)e.getKey()).multiply(m),
				((Integer)e.getValue()).intValue()
			);
		}
		sugar=Math.max(sugar,p.sugar+m.degree());
	}

	Monomial monomial(Literal literal) {
		Monomial m=ordering==Monomial.lexicographic?new BooleanMonomial(unknown):new Monomial(unknown,ordering);
		Iterator it=literal.content.entrySet().iterator();
		while(it.hasNext()) {
			Map.Entry e=(Map.Entry)it.next();
			Variable v=(Variable)e.getKey();
			int c=((Integer)e.getValue()).intValue();
			int n=Monomial.variable(v,unknown);
			if(n<unknown.length) m.put(n,c);
		}
		return m;
	}

	void put(Monomial monomial, int n) {
		if(n==0) return;
		Object o=content.get(monomial);
		if(o!=null) content.remove(monomial);
		else content.put(monomial,ONE);
		if(content.isEmpty()) degree=0;
		else degree=headMonomial().degree();
	}

	protected Polynomial newinstance() {
		return new BooleanPolynomial(unknown,ordering);
	}
}

class BooleanMonomial extends Monomial {
	BooleanMonomial(Variable unknown[]) {
		super(new int[((unknown.length-1)>>4)+1],unknown,lexicographic);
	}

	public Monomial multiply(Monomial monomial) {
		Monomial m=newinstance();
		for(int i=0;i<unknown.length;i++) {
			int q=i>>4;
			int r=(i&0xf)<<1;
			int c=(element[q]>>r)&0x3;
			int c2=(monomial.element[q]>>r)&0x3;
			int n=(c+c2)&0x3;
			m.element[q]|=n<<r;
		}
		m.degree=degree+monomial.degree;
		return m;
	}

	public boolean multiple(Monomial monomial) {
		for(int i=0;i<unknown.length;i++) {
			int q=i>>4;
			int r=(i&0xf)<<1;
			int c=(element[q]>>r)&0x3;
			int c2=(monomial.element[q]>>r)&0x3;
			if(c<c2) return false;
		}
		return true;
	}

	public Monomial divide(Monomial monomial) throws ArithmeticException {
		Monomial m=newinstance();
		for(int i=0;i<unknown.length;i++) {
			int q=i>>4;
			int r=(i&0xf)<<1;
			int c=(element[q]>>r)&0x3;
			int c2=(monomial.element[q]>>r)&0x3;
			int n=c-c2;
			if(n<0) throw new NotDivisibleException();
			m.element[q]|=n<<r;
		}
		m.degree=degree-monomial.degree;
		return m;
	}

	public Monomial gcd(Monomial monomial) {
		Monomial m=newinstance();
		for(int i=0;i<unknown.length;i++) {
			int q=i>>4;
			int r=(i&0xf)<<1;
			int c=(element[q]>>r)&0x3;
			int c2=(monomial.element[q]>>r)&0x3;
			int n=Math.min(c,c2);
			m.element[q]|=n<<r;
			m.degree+=n;
		}
		return m;
	}

	public Monomial scm(Monomial monomial) {
		Monomial m=newinstance();
		for(int i=0;i<unknown.length;i++) {
			int q=i>>4;
			int r=(i&0xf)<<1;
			int c=(element[q]>>r)&0x3;
			int c2=(monomial.element[q]>>r)&0x3;
			int n=Math.max(c,c2);
			m.element[q]|=n<<r;
			m.degree+=n;
		}
		return m;
	}

	public int degree() {
		return degree;
	}

	public Monomial valueof(Monomial monomial) {
		Monomial m=newinstance();
		System.arraycopy(monomial.element, 0, m.element, 0, m.element.length);
		m.degree=monomial.degree;
		return m;
	}

	public Literal literalValue() {
		Literal l=new Literal();
		for(int i=0;i<unknown.length;i++) {
			int c=get(i);
			if(c>0) l.put(
				unknown[i],
				new Integer(c)
			);
		}
		return l;
	}

	public int compareTo(Monomial monomial) {
		int c1[]=element;
		int c2[]=monomial.element;
		int n=c1.length;
		for(int i=n-1;i>=0;i--) {
			long l1=c1[i]&0xffffffffl;
			long l2=c2[i]&0xffffffffl;
			if(l1<l2) return -1;
			else if(l1>l2) return 1;
		}
		return 0;
	}

	public int compareTo(Object o) {
		return compareTo((Monomial)o);
	}

	int get(int n) {
		int q=n>>4;
		int r=(n&0xf)<<1;
		return (element[q]>>r)&0x3;
	}

	void put(int n, int integer) {
		int q=n>>4;
		int r=(n&0xf)<<1;
		int c=(element[q]>>r)&0x3;
		c=(c+integer)&0x3;
		element[q]|=c<<r;
		degree+=integer;
	}

	protected Monomial newinstance() {
		return new BooleanMonomial(unknown);
	}
}
