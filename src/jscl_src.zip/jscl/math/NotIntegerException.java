package jscl.math;

public class NotIntegerException extends ArithmeticException {
	public NotIntegerException() {}

	public NotIntegerException(String s) {
		super(s);
	}
}
