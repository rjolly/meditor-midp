package jscl.math;

import jscl.text.*;

public class MatrixVariable extends ArithmeticVariable {
	public static final Parser parser=MatrixVariableParser.parser;

	public MatrixVariable(Matrix matrix) {
		super(matrix);
	}

	public Arithmetic elementary() {
		ArithmeticVariable v=(ArithmeticVariable)newinstance();
		v.content=content.elementary();
		return v.expressionValue();
	}

	public Arithmetic simplify() {
		ArithmeticVariable v=(ArithmeticVariable)newinstance();
		v.content=content.simplify();
		return v.expressionValue();
	}

	public String toString() {
		return content.toString();
	}

	public String toMathML(Object data) {
		return content.toMathML(data);
	}

	protected Variable newinstance() {
		return new MatrixVariable(null);
	}
}

class MatrixVariableParser extends Parser {
	public static final Parser parser=new MatrixVariableParser();

	private MatrixVariableParser() {}

	public Object parse(String str, int pos[]) throws ParseException {
		Matrix m;
		try {
			m=(Matrix)Matrix.parser.parse(str,pos);
		} catch (ParseException e) {
			throw e;
		}
		return new MatrixVariable(m);
	}
}
