package jscl.math;

import java.util.*;
import jscl.math.function.*;
import jscl.util.*;

public abstract class Factorized extends Arithmetic {
	Arithmetic coefficient=JSCLInteger.valueOf(1);
	final Betatree content=new Betatree();
	int degree;

	Factorized() {}

	public Arithmetic unfactorize() {
		Arithmetic a=JSCLInteger.valueOf(1);
		Enumeration k=content.keys();
		Enumeration e=content.elements();
		while(k.hasMoreElements()) {
			Arithmetic a2=(Arithmetic)k.nextElement();
			int c=((Integer)e.nextElement()).intValue();
			a=a.multiply(a2.pow(c));
		}
		a=a.multiply(coefficient);
		return a;
	}

	public Arithmetic add(Arithmetic arithmetic) {
		Arithmetic gcd=gcd(arithmetic);
		if(gcd.signum()==0) return this;
		Factorized f=(Factorized)divide(gcd);
		Factorized f2=(Factorized)arithmetic.divide(gcd);
		return gcd.multiply(f.unfactorize().add(f2.unfactorize()).factorize());
	}

	public Arithmetic multiply(Arithmetic arithmetic) {
		if(signum()==0) return this;
		else if(arithmetic.signum()==0) return arithmetic;
		else {
			Factorized f=(Factorized)valueof(this);
			f.put(arithmetic);
			return f;
		}
	}

	public Arithmetic divide(Arithmetic arithmetic) throws ArithmeticException {
		if(arithmetic.signum()==0);
		else if(signum()==0) return this;
		Factorized f=(Factorized)valueof(this);
		Factorized f2=(Factorized)arithmetic;
		Enumeration k=f2.content.keys();
		Enumeration e=f2.content.elements();
		while(k.hasMoreElements()) {
			Arithmetic a=(Arithmetic)k.nextElement();
			int c=((Integer)e.nextElement()).intValue();
			if(content.containsKey(a)) {
				int c2=((Integer)content.get(a)).intValue();
				if(c>c2) throw new NotDivisibleException();
				else f.put(a,new Integer(-c));
			} else throw new NotDivisibleException();
		}
		f.coefficient=coefficient.divide(f2.coefficient);
		return f;
	}

	public Arithmetic[] divideAndRemainder(Arithmetic arithmetic) throws ArithmeticException {
		return null;
	}

	public Arithmetic gcd(Arithmetic arithmetic) {
		if(signum()==0) return arithmetic;
		else if(arithmetic.signum()==0) return this;
		Factorized f=(Factorized)newinstance();
		Factorized f2=(Factorized)arithmetic;
		Enumeration k=f2.content.keys();
		Enumeration e=f2.content.elements();
		while(k.hasMoreElements()) {
			Arithmetic a=(Arithmetic)k.nextElement();
			int c2=((Integer)e.nextElement()).intValue();
			if(content.containsKey(a)) {
				int c=((Integer)content.get(a)).intValue();
				f.put(a,new Integer(Math.min(c,c2)));
			}
		}
		f.coefficient=coefficient.gcd(f2.coefficient);
		return f;
	}

	public Arithmetic gcd() {
		return coefficient;
	}

	public Arithmetic negate() {
		Factorized f=(Factorized)valueof(this);
		f.coefficient=coefficient.negate();
		return f;
	}

	public int signum() {
		return coefficient.signum();
	}

	public int degree() {
		return degree;
	}

	public Arithmetic antiderivative(Variable variable) throws NotIntegrableException {
		return null;
	}

	public Arithmetic derivative(Variable variable) {
		return null;
	}

	public Arithmetic substitute(Variable variable, Arithmetic arithmetic) {
		return null;
	}

	public Arithmetic expand() {
		return null;
	}

	public Factorized factorize() {
		return this;
	}

	public Arithmetic elementary() {
		return null;
	}

	public Arithmetic simplify() {
		return null;
	}

	public Arithmetic valueof(Arithmetic arithmetic) {
		Factorized f=(Factorized)newinstance();
		f.put(arithmetic);
		return f;
	}

	public Arithmetic[] sumValue() {
		if(signum()==0) return new Arithmetic[0];
		else return new Arithmetic[] {this};
	}

	public Arithmetic[] productValue() throws NotProductException {
		Arithmetic p[]=new Arithmetic[content.size()];
		Enumeration k=content.keys();
		Enumeration e=content.elements();
		for(int i=0;i<p.length;i++) {
			Arithmetic a=(Arithmetic)k.nextElement();
			int c=((Integer)e.nextElement()).intValue();
			p[i]=valueof(a).pow(c);
		}
		if(coefficient.compareTo(JSCLInteger.valueOf(1))==0) return p;
		else {
			Arithmetic a[]=new Arithmetic[p.length+1];
			for(int i=0;i<p.length;i++) a[i+1]=p[i];
			a[0]=coefficient;
			return a;
		}
	}

	public Object[] powerValue() throws NotPowerException {
		int n=content.size();
		if(n==0) return new Object[] {coefficient,new Integer(1)};
		else if(n==1) {
			Arithmetic a=(Arithmetic)content.keys().nextElement();
			Integer in=(Integer)content.elements().nextElement();
			if(coefficient.compareTo(JSCLInteger.valueOf(1))==0) return new Object[] {a,in};
			else throw new NotPowerException();
		} else throw new NotPowerException();
	}

	public JSCLInteger integerValue() throws NotIntegerException {
		return null;
	}

	public Variable variableValue() throws NotVariableException {
		return null;
	}

	public boolean isPolynomial(Variable variable) {
		return false;
	}

	public boolean isConstant(Variable variable) {
		return false;
	}

	public int compareTo(jscl.util.Comparable comparable) {
		Factorized f=(Factorized)comparable;
		Enumeration k1=content.keys(true);
		Enumeration e1=content.elements(true);
		Enumeration k2=f.content.keys(true);
		Enumeration e2=f.content.elements(true);
		while(true) {
			boolean b1=!k1.hasMoreElements();
			boolean b2=!k2.hasMoreElements();
			if(b1 && b2) return coefficient.compareTo(f.coefficient);
			else if(b1) return -1;
			else if(b2) return 1;
			else {
				Arithmetic a1=(Arithmetic)k1.nextElement();
				Arithmetic a2=(Arithmetic)k2.nextElement();
				int c=a1.compareTo(a2);
				if(c<0) return -1;
				else if(c>0) return 1;
				else {
					int c1=((Integer)e1.nextElement()).intValue();
					int c2=((Integer)e2.nextElement()).intValue();
					if(c1<c2) return -1;
					else if(c1>c2) return 1;
				}
			}
		}
	}

	void put(Arithmetic arithmetic) {
		if(arithmetic instanceof Factorized) {
			Factorized f=(Factorized)arithmetic;
			coefficient=coefficient.multiply(f.coefficient);
			if(coefficient.signum()==0) remove();
			else {
				Enumeration k=f.content.keys();
				Enumeration e=f.content.elements();
				while(k.hasMoreElements()) {
					put(
						(Arithmetic)k.nextElement(),
						(Integer)e.nextElement()
					);
				}
			}
		} else {
			Arithmetic a[]=arithmetic.gcdAndNormalize();
			coefficient=coefficient.multiply(a[0]);
			if(coefficient.signum()==0) remove();
			else put(a[1],new Integer(1));
		}
	}

	void put(Arithmetic arithmetic, Integer integer) {
		if(arithmetic.compareTo(JSCLInteger.valueOf(1))==0);
		else {
			int c=content.containsKey(arithmetic)?((Integer)content.get(arithmetic)).intValue():0;
			int c2=c+integer.intValue();
			if(c2==0) {
				if(c>0) content.remove(arithmetic);
			} else {
				content.put(arithmetic,new Integer(c2));
			}
			int d=c2-c;
			degree+=d*arithmetic.degree();
		}
	}

	void remove() {
		Vector v=new Vector();
		for(Enumeration k=content.keys();k.hasMoreElements();) {
			v.addElement(k.nextElement());
		}
		for(Enumeration e=v.elements();e.hasMoreElements();) {
			content.remove(
				(Arithmetic)e.nextElement()
			);
		}
	}

	public String toString() {
		StringBuffer buffer=new StringBuffer();
		if(content.isEmpty()) buffer.append(coefficient);
		else {
			boolean multiply=false;
			if(coefficient.compareTo(JSCLInteger.valueOf(1))==0);
			else if(coefficient.compareTo(JSCLInteger.valueOf(-1))==0) buffer.append("-");
			else {
				buffer.append(coefficient);
				multiply=true;
			}
			Enumeration k=content.keys();
			Enumeration e=content.elements();
			for(int i=0;k.hasMoreElements();i++) {
				Arithmetic a=(Arithmetic)k.nextElement();
				int c=((Integer)e.nextElement()).intValue();
				if(multiply || i>0) buffer.append("*");
				try {
					JSCLInteger en=a.integerValue();
					buffer.append(en);
				} catch (NotIntegerException e1) {
					try {
						Variable v=a.variableValue();
						if(v instanceof Frac || v instanceof Pow) {
							buffer.append(new ExpressionVariable(a));
						} else buffer.append(v);
					} catch (NotVariableException e2) {
						buffer.append(new ExpressionVariable(a));
					}
				}
				if(c==1);
				else buffer.append("^").append(c);
			}
		}
		return buffer.toString();
	}

	public String toMathML(Object data) {
		IndentedBuffer buffer=new IndentedBuffer();
		buffer.append("<mrow>\n");
		if(content.isEmpty()) buffer.append(1,coefficient.toMathML(null));
		else {
			if(coefficient.compareTo(JSCLInteger.valueOf(1))==0);
			else if(coefficient.compareTo(JSCLInteger.valueOf(-1))==0) buffer.append(1,"<mo>-</mo>\n");
			else {
				buffer.append(1,coefficient.toMathML(null));
			}
			Enumeration k=content.keys();
			Enumeration e=content.elements();
			for(int i=0;k.hasMoreElements();i++) {
				Arithmetic a=(Arithmetic)k.nextElement();
				int c=((Integer)e.nextElement()).intValue();
				try {
					JSCLInteger en=a.integerValue();
					buffer.append(1,en.toMathML(new Integer(c)));
				} catch (NotIntegerException e1) {
					try {
						Variable v=a.variableValue();
						if(v instanceof Frac || v instanceof Pow) {
							buffer.append(1,new ExpressionVariable(a).toMathML(new Integer(c)));
						} else buffer.append(1,v.toMathML(new Integer(c)));
					} catch (NotVariableException e2) {
						buffer.append(1,new ExpressionVariable(a).toMathML(new Integer(c)));
					}
				}
			}
		}
		buffer.append("</mrow>\n");
		return buffer.toString();
	}
}
