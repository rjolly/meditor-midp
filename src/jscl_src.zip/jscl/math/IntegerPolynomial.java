package jscl.math;

import java.util.*;
import jscl.util.*;

public class IntegerPolynomial extends MultivariatePolynomial {
	IntegerPolynomial(Variable unknown[], Comparator ordering) {
		super(unknown,ordering);
	}

	void mutableDivide(Arithmetic arithmetic) throws ArithmeticException {
		if(arithmetic.compareTo(JSCLInteger.valueOf(1))==0) return;
		Iterator it=content.entrySet().iterator();
		while(it.hasNext()) {
			Map.Entry e=(Map.Entry)it.next();
			e.setValue(((Arithmetic)e.getValue()).divide(arithmetic));
		}
	}

	public Arithmetic gcd() {
		Arithmetic a=JSCLInteger.valueOf(0);
		for(Iterator it=content.values().iterator(true);it.hasNext();) {
			a=a.gcd((Arithmetic)it.next());
			if(a.abs().compareTo(JSCLInteger.valueOf(1))==0) break;
		}
		return a;
	}

	void mutableNormalize() {
		Arithmetic gcd=gcd();
		if(gcd.signum()==0) return;
		if(gcd.signum()!=signum()) gcd=gcd.negate();
		mutableDivide(gcd);
	}

	public Polynomial s_polynomial(Polynomial polynomial) {
		IntegerPolynomial p2=(IntegerPolynomial)polynomial;
		Map.Entry e1=headTerm();
		Monomial m1=(Monomial)e1.getKey();
		Arithmetic c1=(Arithmetic)e1.getValue();
		Map.Entry e2=p2.headTerm();
		Monomial m2=(Monomial)e2.getKey();
		Arithmetic c2=(Arithmetic)e2.getValue();
		Monomial m=m1.scm(m2);
		m1=m.divide(m1);
		m2=m.divide(m2);
		Arithmetic c=c1.scm(c2);
		c1=c.divide(c1);
		c2=c.divide(c2);
		IntegerPolynomial p=(IntegerPolynomial)multiply(m1,c1);
		p.mutableReduce(JSCLInteger.valueOf(1),p2,m2,c2);
		p.mutableNormalize();
		return p;
	}

	public Polynomial reduce(Basis basis) {
		IntegerPolynomial p=(IntegerPolynomial)valueof(this);
		loop: while(p.signum()!=0) {
			Map.Entry e1=p.headTerm();
			Monomial m1=(Monomial)e1.getKey();
			Arithmetic c1=(Arithmetic)e1.getValue();
			Iterator it=basis.content.values().iterator();
			while(it.hasNext()) {
				IntegerPolynomial q=(IntegerPolynomial)it.next();
				Map.Entry e2=q.headTerm();
				Monomial m2=(Monomial)e2.getKey();
				if(m1.multiple(m2)) {
					Arithmetic c2=(Arithmetic)e2.getValue();
					Monomial m=m1.divide(m2);
					Arithmetic c=c1.scm(c2);
					c1=c.divide(c1);
					c2=c.divide(c2);
					p.mutableReduce(c1,q,m,c2);
					continue loop;
				}
			}
			break;
		}
		p.mutableNormalize();
		return p;
	}

	public Polynomial reduceCompletely(Basis basis) {
		IntegerPolynomial p=(IntegerPolynomial)valueof(this);
		Monomial l=null;
		loop: while(p.signum()!=0) {
			Iterator it=(l==null?p.content:p.content.headMap(l)).entrySet().iterator(true);
			while(it.hasNext()) {
				Map.Entry e1=(Map.Entry)it.next();
				Monomial m1=(Monomial)e1.getKey();
				Arithmetic c1=(Arithmetic)e1.getValue();
				Iterator it2=basis.content.values().iterator();
				while(it2.hasNext()) {
					IntegerPolynomial q=(IntegerPolynomial)it2.next();
					Map.Entry e2=q.headTerm();
					Monomial m2=(Monomial)e2.getKey();
					if(m1.multiple(m2)) {
						Arithmetic c2=(Arithmetic)e2.getValue();
						Monomial m=m1.divide(m2);
						Arithmetic c=c1.scm(c2);
						c1=c.divide(c1);
						c2=c.divide(c2);
						p.mutableReduce(c1,q,m,c2);
						l=m1;
						continue loop;
					}
				}
			}
			break;
		}
		p.mutableNormalize();
		return p;
	}

	void mutableReduce(Arithmetic c1, IntegerPolynomial p2, Monomial m2, Arithmetic c2) {
		if(c1.compareTo(JSCLInteger.valueOf(1))==0);
		else {
			Iterator it=content.entrySet().iterator();
			while(it.hasNext()) {
				Map.Entry e=(Map.Entry)it.next();
				e.setValue(((Arithmetic)e.getValue()).multiply(c1));
			}
		}
		Iterator it=p2.content.entrySet().iterator();
		while(it.hasNext()) {
			Map.Entry e=(Map.Entry)it.next();
			put(
				((Monomial)e.getKey()).multiply(m2),
				((Arithmetic)e.getValue()).multiply(c2).negate()
			);
		}
		sugar=Math.max(sugar,p2.sugar+m2.degree());
	}

	protected Arithmetic uncoefficient(Arithmetic arithmetic) {
		return arithmetic;
	}

	protected Arithmetic coefficient(Arithmetic arithmetic) {
		return (JSCLInteger)arithmetic;
	}

	protected Polynomial newinstance() {
		return new IntegerPolynomial(unknown,ordering);
	}
}
