package jscl.math;

import java.util.*;
import jscl.util.*;

public class RationalPolynomial extends MultivariatePolynomial {
	RationalPolynomial(Variable unknown[], Comparator ordering) {
		super(unknown,ordering);
	}

	void mutableMultiply(Arithmetic arithmetic) {
		if(arithmetic.compareTo(JSCLInteger.valueOf(1))==0) return;
		Iterator it=content.entrySet().iterator();
		while(it.hasNext()) {
			Map.Entry e=(Map.Entry)it.next();
			e.setValue(((Arithmetic)e.getValue()).multiply(arithmetic));
		}
	}

	public Polynomial normalize() {
		RationalPolynomial p=(RationalPolynomial)valueof(this);
		p.mutableNormalize();
		return p;
	}

	void mutableNormalize() {
		if(signum()==0) return;
		mutableMultiply(((Rational)headCoefficient()).inverse());
	}

	public Polynomial s_polynomial(Polynomial polynomial) {
		RationalPolynomial p2=(RationalPolynomial)polynomial;
		Monomial m1=headMonomial();
		Monomial m2=p2.headMonomial();
		Monomial m=m1.scm(m2);
		m1=m.divide(m1);
		m2=m.divide(m2);
		RationalPolynomial p=(RationalPolynomial)multiply(m1);
		p.mutableReduce(p2,m2,Rational.valueOf(JSCLInteger.valueOf(1)));
		p.mutableNormalize();
		return p;
	}

	public Polynomial reduce(Basis basis) {
		return null;
	}

	public Polynomial reduceCompletely(Basis basis) {
		RationalPolynomial p=(RationalPolynomial)valueof(this);
		int n=basis.size();
		Monomial l=null;
		loop: while(p.signum()!=0) {
			MySortedMap map=p.content;
			Iterator it=(l==null?map:map.headMap(l)).entrySet().iterator(true);
			while(it.hasNext()) {
				Map.Entry e1=(Map.Entry)it.next();
				Monomial m1=(Monomial)e1.getKey();
				Arithmetic c1=(Arithmetic)e1.getValue();
				for(int i=0;i<n;i++) {
					RationalPolynomial q=(RationalPolynomial)basis.get(i);
					Monomial m2=q.headMonomial();
					if(m1.multiple(m2)) {
						Monomial m=m1.divide(m2);
						p.mutableReduce(q,m,c1);
						p.mutableNormalize();
						l=m1;
						continue loop;
					}
				}
			}
			break;
		}
		return p;
	}

	void mutableReduce(RationalPolynomial p2, Monomial m2, Arithmetic c2) {
		Iterator it=p2.content.entrySet().iterator();
		while(it.hasNext()) {
			Map.Entry e=(Map.Entry)it.next();
			put(
				((Monomial)e.getKey()).multiply(m2),
				((Arithmetic)e.getValue()).multiply(c2).negate()
			);
		}
		sugar=Math.max(sugar,p2.sugar+m2.degree());
	}

	Arithmetic uncoefficient(Arithmetic arithmetic) {
		return null;
	}

	Arithmetic coefficient(Arithmetic arithmetic) {
		return Rational.valueOf((JSCLInteger)arithmetic);
	}

	protected Polynomial newinstance() {
		return new RationalPolynomial(unknown,ordering);
	}
}
