package jscl.math;

import java.util.*;
import jscl.util.*;

public class RationalPolynomial extends MultivariatePolynomial {
	RationalPolynomial(Variable unknown[], Comparator ordering) {
		super(unknown,ordering);
	}

	void mutableMultiply(Arithmetic arithmetic) {
		if(arithmetic.compareTo(JSCLInteger.valueOf(1))==0) return;
		Iterator it=content.entrySet().iterator();
		while(it.hasNext()) {
			Map.Entry e=(Map.Entry)it.next();
			e.setValue(((Arithmetic)e.getValue()).multiply(arithmetic));
		}
	}

	void mutableNormalize() {
		Arithmetic gcd=gcd();
		if(gcd.signum()==0) return;
		if(gcd.signum()!=signum()) gcd=gcd.negate();
		mutableMultiply(((Rational)gcd).inverse());
	}

	public Polynomial s_polynomial(Polynomial polynomial) {
		RationalPolynomial p2=(RationalPolynomial)polynomial;
		Map.Entry e1=headTerm();
		Monomial m1=(Monomial)e1.getKey();
		Arithmetic c1=(Arithmetic)e1.getValue();
		Map.Entry e2=p2.headTerm();
		Monomial m2=(Monomial)e2.getKey();
		Arithmetic c2=(Arithmetic)e2.getValue();
		Monomial m=m1.scm(m2);
		m1=m.divide(m1);
		m2=m.divide(m2);
		RationalPolynomial p=(RationalPolynomial)multiply(m1);
		p.mutableReduce(p2,m2,c1.divide(c2));
		p.mutableNormalize();
		return p;
	}

	public Polynomial reduce(Basis basis) {
		RationalPolynomial p=(RationalPolynomial)valueof(this);
		loop: while(p.signum()!=0) {
			Map.Entry e1=p.headTerm();
			Monomial m1=(Monomial)e1.getKey();
			Arithmetic c1=(Arithmetic)e1.getValue();
			Iterator it=basis.content.values().iterator();
			while(it.hasNext()) {
				RationalPolynomial q=(RationalPolynomial)it.next();
				Map.Entry e2=q.headTerm();
				Monomial m2=(Monomial)e2.getKey();
				if(m1.multiple(m2)) {
					Arithmetic c2=(Arithmetic)e2.getValue();
					Monomial m=m1.divide(m2);
					p.mutableReduce(q,m,c1.divide(c2));
					continue loop;
				}
			}
			break;
		}
		p.mutableNormalize();
		return p;
	}

	public Polynomial reduceCompletely(Basis basis) {
		RationalPolynomial p=(RationalPolynomial)valueof(this);
		Monomial l=null;
		loop: while(p.signum()!=0) {
			Iterator it=(l==null?p.content:p.content.headMap(l)).entrySet().iterator(true);
			while(it.hasNext()) {
				Map.Entry e1=(Map.Entry)it.next();
				Monomial m1=(Monomial)e1.getKey();
				Arithmetic c1=(Arithmetic)e1.getValue();
				Iterator it2=basis.content.values().iterator();
				while(it2.hasNext()) {
					RationalPolynomial q=(RationalPolynomial)it2.next();
					Map.Entry e2=q.headTerm();
					Monomial m2=(Monomial)e2.getKey();
					if(m1.multiple(m2)) {
						Arithmetic c2=(Arithmetic)e2.getValue();
						Monomial m=m1.divide(m2);
						p.mutableReduce(q,m,c1.divide(c2));
						l=m1;
						continue loop;
					}
				}
			}
			break;
		}
		p.mutableNormalize();
		return p;
	}

	void mutableReduce(RationalPolynomial p2, Monomial m2, Arithmetic c2) {
		Iterator it=p2.content.entrySet().iterator();
		while(it.hasNext()) {
			Map.Entry e=(Map.Entry)it.next();
			put(
				((Monomial)e.getKey()).multiply(m2),
				((Arithmetic)e.getValue()).multiply(c2).negate()
			);
		}
		sugar=Math.max(sugar,p2.sugar+m2.degree());
	}

	protected Arithmetic uncoefficient(Arithmetic arithmetic) {
		return arithmetic.integerValue();
	}

	void put(Arithmetic arithmetic) {
		if(arithmetic instanceof Rational) {
			put(new Monomial(unknown,ordering),(Rational)arithmetic);
		} else super.put(arithmetic);
	}

	protected Arithmetic coefficient(Arithmetic arithmetic) {
		return Rational.valueOf((JSCLInteger)arithmetic);
	}

	protected Polynomial newinstance() {
		return new RationalPolynomial(unknown,ordering);
	}
}
