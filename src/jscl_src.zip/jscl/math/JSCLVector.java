package jscl.math;

import java.util.*;
import jscl.text.*;
import jscl.util.*;

public class JSCLVector extends Arithmetic {
	public static final Parser parser=VectorParser.parser;
	public static final Parser commaAndVector=CommaAndVector.parser;
	public Arithmetic element[];
	protected int n;

	public JSCLVector(Arithmetic element[]) {
		put(element);
	}

	void put(Arithmetic element[]) {
		this.element=element;
		n=element.length;
	}

	public Arithmetic add(Arithmetic arithmetic) {
		if(arithmetic instanceof JSCLVector) {
			JSCLVector v=(JSCLVector)arithmetic;
			JSCLVector v2=(JSCLVector)newinstance();
			for(int i=0;i<n;i++) v2.element[i]=element[i].add(v.element[i]);
			return v2;
		} else if(arithmetic instanceof Matrix) {
			return null;
		} else {
			return add(valueof(arithmetic));
		}
	}

	public Arithmetic subtract(Arithmetic arithmetic) {
		if(arithmetic instanceof JSCLVector) {
			JSCLVector v=(JSCLVector)arithmetic;
			JSCLVector v2=(JSCLVector)newinstance();
			for(int i=0;i<n;i++) v2.element[i]=element[i].subtract(v.element[i]);
			return v2;
		} else if(arithmetic instanceof Matrix) {
			return null;
		} else {
			return subtract(valueof(arithmetic));
		}
	}

	public Arithmetic multiply(Arithmetic arithmetic) {
		if(arithmetic instanceof JSCLVector) {
			return scalarProduct((JSCLVector)arithmetic);
		} else if(arithmetic instanceof Matrix) {
			return ((Matrix)arithmetic).transpose().multiply(this);
		} else {
			JSCLVector v=(JSCLVector)newinstance();
			for(int i=0;i<n;i++) v.element[i]=element[i].multiply(arithmetic);
			return v;
		}
	}

	public Arithmetic divide(Arithmetic arithmetic) throws ArithmeticException {
		if(arithmetic instanceof JSCLVector) {
			return null;
		} else if(arithmetic instanceof Matrix) {
			return null;
		} else {
			JSCLVector v=(JSCLVector)newinstance();
			for(int i=0;i<n;i++) v.element[i]=element[i].divide(arithmetic);
			return v;
		}
	}

	public Arithmetic[] divideAndRemainder(Arithmetic arithmetic) throws ArithmeticException {
		return null;
	}

	public Arithmetic gcd(Arithmetic arithmetic) {
		return null;
	}

	public Arithmetic gcd() {
		return null;
	}

	public Arithmetic negate() {
		JSCLVector v=(JSCLVector)newinstance();
		for(int i=0;i<n;i++) v.element[i]=element[i].negate();
		return v;
	}

	public int signum() {
		return 0;
	}

	public int degree() {
		return 0;
	}

	public Arithmetic antiderivative(Variable variable) throws NotIntegrableException {
		JSCLVector v=(JSCLVector)newinstance();
		for(int i=0;i<n;i++) v.element[i]=element[i].antiderivative(variable);
		return v;
	}

	public Arithmetic derivative(Variable variable) {
		JSCLVector v=(JSCLVector)newinstance();
		for(int i=0;i<n;i++) v.element[i]=element[i].derivative(variable);
		return v;
	}

	public Arithmetic substitute(Variable variable, Arithmetic arithmetic) {
		JSCLVector v=(JSCLVector)newinstance();
		for(int i=0;i<n;i++) v.element[i]=element[i].substitute(variable,arithmetic);
		return v;
	}

	public Arithmetic expand() {
		JSCLVector v=(JSCLVector)newinstance();
		for(int i=0;i<n;i++) v.element[i]=element[i].expand();
		return v;
	}

	public Arithmetic factorize() {
		JSCLVector v=(JSCLVector)newinstance();
		for(int i=0;i<n;i++) v.element[i]=element[i].factorize();
		return v;
	}

	public Arithmetic elementary() {
		JSCLVector v=(JSCLVector)newinstance();
		for(int i=0;i<n;i++) v.element[i]=element[i].elementary();
		return v;
	}

	public Arithmetic simplify() {
		JSCLVector v=(JSCLVector)newinstance();
		for(int i=0;i<n;i++) v.element[i]=element[i].simplify();
		return v;
	}

	public Arithmetic valueof(Arithmetic arithmetic) {
		JSCLVector v=(JSCLVector)unity(n).multiply(arithmetic);
		JSCLVector v2=(JSCLVector)newinstance();
		for(int i=0;i<n;i++) v2.element[i]=v.element[i];
		return v2;
	}

	public Arithmetic[] sumValue() {
		return new Arithmetic[] {this};
	}

	public Arithmetic[] productValue() throws NotProductException {
		return new Arithmetic[] {this};
	}

	public Object[] powerValue() throws NotPowerException {
		return new Object[] {this,new Integer(1)};
	}

	public Expression expressionValue() throws NotExpressionException {
		throw new NotExpressionException();
	}

	public JSCLInteger integerValue() throws NotIntegerException {
		throw new NotIntegerException();
	}

	public Variable variableValue() throws NotVariableException {
		throw new NotVariableException();
	}

	public Variable[] variables() {
		return null;
	}

	public boolean isPolynomial(Variable variable) {
		return false;
	}

	public boolean isConstant(Variable variable) {
		return false;
	}

	public Arithmetic norm2() {
		return scalarProduct(this);
	}

	public Arithmetic scalarProduct(JSCLVector vector) {
		Arithmetic a=JSCLInteger.valueOf(0);
		for(int i=0;i<n;i++) {
			a=a.add(element[i].multiply(vector.element[i]));
		}
		return a;
	}

	public Arithmetic vectorProduct(JSCLVector vector) {
		JSCLVector v2=(JSCLVector)newinstance();
		Arithmetic m[][]={
			{JSCLInteger.valueOf(0),element[2].negate(),element[1]},
			{element[2],JSCLInteger.valueOf(0),element[0].negate()},
			{element[1].negate(),element[0],JSCLInteger.valueOf(0)}
		};
		JSCLVector v=(JSCLVector)new Matrix(m).multiply(vector);
		for(int i=0;i<n;i++) v2.element[i]=i<v.n?v.element[i]:JSCLInteger.valueOf(0);
		return v2;
	}

	public Arithmetic divergence(Variable variable[]) {
		Arithmetic a=JSCLInteger.valueOf(0);
		for(int i=0;i<n;i++) a=a.add(element[i].derivative(variable[i]));
		return a;
	}

	public Arithmetic jacobi(Variable variable[]) {
		Matrix m=new Matrix(new Arithmetic[n][variable.length]);
		for(int i=0;i<n;i++) {
			for(int j=0;j<variable.length;j++) {
				m.element[i][j]=element[i].derivative(variable[j]);
			}
		}
		return m;
	}

	public Arithmetic curl(Variable variable[]) {
		JSCLVector v=(JSCLVector)newinstance();
		v.element[0]=element[2].derivative(variable[1]).subtract(element[1].derivative(variable[2]));
		v.element[1]=element[0].derivative(variable[2]).subtract(element[2].derivative(variable[0]));
		v.element[2]=element[1].derivative(variable[0]).subtract(element[0].derivative(variable[1]));
		for(int i=3;i<n;i++) v.element[i]=element[i];
		return v;
	}

	public int compareTo(Object comparable) {
		return ArrayComparator.comparator.compare(element,((JSCLVector)comparable).element);
	}

	public static JSCLVector unity(int dimension) {
		JSCLVector v=new JSCLVector(new Arithmetic[dimension]);
		for(int i=0;i<v.n;i++) {
			if(i==0) v.element[i]=JSCLInteger.valueOf(1);
			else v.element[i]=JSCLInteger.valueOf(0);
		}
		return v;
	}

	public String toString() {
		StringBuffer buffer=new StringBuffer();
		buffer.append("{");
		for(int i=0;i<n;i++) {
			buffer.append(element[i]).append(i<n-1?", ":"");
		}
		buffer.append("}");
		return buffer.toString();
	}

	public String toMathML(Object data) {
		IndentedBuffer buffer=new IndentedBuffer();
		int exponent=data instanceof Integer?((Integer)data).intValue():1;
		if(exponent==1) {
			buffer.append(bodyToMathML());
		} else {
			buffer.append("<msup>\n");
			buffer.append(1,bodyToMathML());
			buffer.append(1,"<mn>").append(exponent).append("</mn>\n");
			buffer.append("</msup>\n");
		}
		return buffer.toString();
	}

	protected String bodyToMathML() {
		IndentedBuffer buffer=new IndentedBuffer();
		buffer.append("<mrow>\n");
		buffer.append(1,"<mo>(</mo>\n");
		buffer.append(1,"<mtable>\n");
		for(int i=0;i<n;i++) {
			buffer.append(2,"<mtr>\n");
			buffer.append(3,"<mtd>\n");
			buffer.append(4,element[i].toMathML(null));
			buffer.append(3,"</mtd>\n");
			buffer.append(2,"</mtr>\n");
		}
		buffer.append(1,"</mtable>\n");
		buffer.append(1,"<mo>)</mo>\n");
		buffer.append("</mrow>\n");
		return buffer.toString();
	}

	protected Arithmetic newinstance() {
		return newinstance(n);
	}

	protected Arithmetic newinstance(int n) {
		return new JSCLVector(new Arithmetic[n]);
	}
}

class VectorParser extends Parser {
	public static final Parser parser=new VectorParser();

	private VectorParser() {}

	public Object parse(String str, int pos[]) throws ParseException {
		int pos0=pos[0];
		Vector vector=new Vector();
		skipWhitespaces(str,pos);
		if(pos[0]<str.length() && str.charAt(pos[0])=='{') {
			str.charAt(pos[0]++);
		} else {
			pos[0]=pos0;
			throw new ParseException();
		}
		try {
			Arithmetic a=(Arithmetic)Expression.parser.parse(str,pos);
			vector.addElement(a);
		} catch (ParseException e) {
			pos[0]=pos0;
			throw e;
		}
		while(true) {
			try {
				Arithmetic a=(Arithmetic)Expression.commaAndExpression.parse(str,pos);
				vector.addElement(a);
			} catch (ParseException e) {
				break;
			}
		}
		skipWhitespaces(str,pos);
		if(pos[0]<str.length() && str.charAt(pos[0])=='}') {
			str.charAt(pos[0]++);
		} else {
			pos[0]=pos0;
			throw new ParseException();
		}
		Arithmetic element[]=new Arithmetic[vector.size()];
		vector.copyInto(element);
		return new JSCLVector(element);
	}
}

class CommaAndVector extends Parser {
	public static final Parser parser=new CommaAndVector();

	private CommaAndVector() {}

	public Object parse(String str, int pos[]) throws ParseException {
		int pos0=pos[0];
		JSCLVector v;
		skipWhitespaces(str,pos);
		if(pos[0]<str.length() && str.charAt(pos[0])==',') {
			str.charAt(pos[0]++);
		} else {
			pos[0]=pos0;
			throw new ParseException();
		}
		try {
			v=(JSCLVector)VectorParser.parser.parse(str,pos);
		} catch (ParseException e) {
			pos[0]=pos0;
			throw e;
		}
		return v;
	}
}
