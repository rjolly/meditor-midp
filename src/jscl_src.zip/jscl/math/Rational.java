package jscl.math;

import java.math.*;
import jscl.text.*;

public class Rational extends Arithmetic {
	BigInteger numerator;
	BigInteger denominator;

	Rational() {}

	public Arithmetic add(Arithmetic arithmetic) {
		if(arithmetic instanceof Rational) {
			Rational r=(Rational)newinstance();
			Rational r2=(Rational)arithmetic;
			BigInteger gcd=denominator.gcd(r2.denominator);
			BigInteger c=denominator.divide(gcd);
			BigInteger c2=r2.denominator.divide(gcd);
			r.put(numerator.multiply(c2).add(r2.numerator.multiply(c)),denominator.multiply(c2));
			r.reduce();
			return r;
		} else if(arithmetic instanceof JSCLInteger) {
			return add(valueof(arithmetic));
		} else {
			return arithmetic.valueof(this).add(arithmetic);
		}
	}

	void reduce() {
		BigInteger gcd=numerator.gcd(denominator);
		if(gcd.signum()==0) return;
		if(gcd.signum()!=denominator.signum()) gcd=gcd.negate();
		numerator=numerator.divide(gcd);
		denominator=denominator.divide(gcd);
	}

	public Arithmetic multiply(Arithmetic arithmetic) {
		if(arithmetic instanceof Rational) {
			Rational r=(Rational)newinstance();
			Rational r2=(Rational)arithmetic;
			BigInteger gcd=numerator.gcd(r2.denominator);
			BigInteger gcd2=denominator.gcd(r2.numerator);
			r.put(numerator.divide(gcd).multiply(r2.numerator.divide(gcd2)),denominator.divide(gcd2).multiply(r2.denominator.divide(gcd)));
			return r;
		} else if(arithmetic instanceof JSCLInteger) {
			return multiply(valueof(arithmetic));
		} else {
			return arithmetic.multiply(this);
		}
	}

	public Arithmetic divide(Arithmetic arithmetic) throws ArithmeticException {
		if(arithmetic instanceof Rational) {
			return multiply(((Rational)arithmetic).inverse());
		} else if(arithmetic instanceof JSCLInteger) {
			return divide(valueof(arithmetic));
		} else {
			return arithmetic.valueof(this).divide(arithmetic);
		}
	}

	public Arithmetic inverse() {
		Rational r=(Rational)newinstance();
		if(signum()<0) r.put(denominator.negate(),numerator.negate());
		else r.put(denominator,numerator);
		return r;
	}

	public Arithmetic gcd(Arithmetic arithmetic) {
		if(arithmetic instanceof Rational) {
			Rational r=(Rational)newinstance();
			Rational r2=(Rational)arithmetic;
			r.put(numerator.gcd(r2.numerator),scm(denominator,r2.denominator));
			return r;
		} else if(arithmetic instanceof JSCLInteger) {
			return gcd(valueof(arithmetic));
		} else {
			return arithmetic.valueof(this).gcd(arithmetic);
		}
	}

	static BigInteger scm(BigInteger b1, BigInteger b2) {
		return b1.multiply(b2).divide(b1.gcd(b2));
	}

	public Arithmetic gcd() {
		return null;
	}

	public Arithmetic pow(int exponent) {
		return null;
	}

	public Arithmetic negate() {
		Rational r=(Rational)newinstance();
		r.put(numerator.negate(),denominator);
		return r;
	}

	public int signum() {
		return numerator.signum();
	}

	public int degree() {
		return 0;
	}

	public Arithmetic antiderivative(Variable variable) throws NotIntegrableException {
		return null;
	}

	public Arithmetic derivative(Variable variable) {
		return null;
	}

	public Arithmetic substitute(Variable variable, Arithmetic arithmetic) {
		return null;
	}

	public Arithmetic expand() {
		return null;
	}

	public Arithmetic factorize() {
		return null;
	}

	public Arithmetic elementary() {
		return null;
	}

	public Arithmetic simplify() {
		return null;
	}

	public Arithmetic numeric() {
		return new NumericWrapper(this);
	}

	public Arithmetic valueof(Arithmetic arithmetic) {
		Rational r=(Rational)newinstance();
		r.put(arithmetic);
		return r;
	}

	public Arithmetic[] sumValue() {
		try {
			if(integerValue().signum()==0) return new Arithmetic[0];
			else return new Arithmetic[] {this};
		} catch (NotIntegerException e) {
			return new Arithmetic[] {this};
		}
	}

	public Arithmetic[] productValue() throws NotProductException {
		try {
			if(integerValue().compareTo(JSCLInteger.valueOf(1))==0) return new Arithmetic[0];
			else return new Arithmetic[] {this};
		} catch (NotIntegerException e) {
			return new Arithmetic[] {this};
		}
	}

	public Object[] powerValue() throws NotPowerException {
		return new Object[] {this,new Integer(1)};
	}

	public Expression expressionValue() throws NotExpressionException {
		throw new NotExpressionException();
	}

	public JSCLInteger integerValue() throws NotIntegerException {
		if(denominator.compareTo(BigInteger.valueOf(1))==0) {
			JSCLInteger e=new JSCLInteger();
			e.put(numerator);
			return e;
		} else throw new NotIntegerException();
	}

	public Variable variableValue() throws NotVariableException {
		throw new NotVariableException();
	}

	public Variable[] variables() {
		return new Variable[0];
	}

	public boolean isPolynomial(Variable variable) {
		return true;
	}

	public boolean isConstant(Variable variable) {
		return true;
	}

	public int compareTo(Object comparable) {
		if(comparable instanceof Rational) {
			Rational r=(Rational)comparable;
			int c=denominator.compareTo(r.denominator);
			if(c<0) return -1;
			else if(c>0) return 1;
			else return numerator.compareTo(r.numerator);
		} else if(comparable instanceof JSCLInteger) {
			return compareTo(valueof((JSCLInteger)comparable));
		} else {
			return ((Arithmetic)comparable).valueof(this).compareTo(comparable);
		}
	}

	public static Rational valueOf(JSCLInteger integer) {
		Rational r=new Rational();
		r.put(integer);
		return r;
	}

	void put(Arithmetic arithmetic) {
		if(arithmetic instanceof Rational) {
			Rational r=(Rational)arithmetic;
			put(r.numerator,r.denominator);
		} else if(arithmetic instanceof JSCLInteger) { 
			JSCLInteger en=(JSCLInteger)arithmetic;
			put(en.content,BigInteger.valueOf(1));
		} else throw new ArithmeticException();
	}

	void put(BigInteger numerator, BigInteger denominator) {
		this.numerator=numerator;
		this.denominator=denominator;
	}

	public String toString() {
		StringBuffer buffer=new StringBuffer();
		try {
			buffer.append(integerValue());
		} catch (NotIntegerException e) {
			buffer.append(numerator);
			buffer.append("/");
			buffer.append(denominator);
		}
		return buffer.toString();
	}

	public String toJava() {
		return "JSCLDouble.valueOf("+numerator+"/"+denominator+")";
	}

	public String toMathML(Object data) {
		IndentedBuffer buffer=new IndentedBuffer();
		int exponent=data instanceof Integer?((Integer)data).intValue():1;
		if(exponent==1) {
			buffer.append(bodyToMathML());
		} else {
			buffer.append("<msup>\n");
			buffer.append(1,bodyToMathML());
			buffer.append(1,"<mn>").append(exponent).append("</mn>\n");
			buffer.append("</msup>\n");
		}
		return buffer.toString();
	}

	String bodyToMathML() {
		IndentedBuffer buffer=new IndentedBuffer();
		try {
			buffer.append("<mn>").append(integerValue()).append("</mn>\n");
		} catch (NotIntegerException e) {
			buffer.append("<mfrac>\n");
			buffer.append(1,"<mn>").append(numerator).append("</mn>\n");
			buffer.append(1,"<mn>").append(denominator).append("</mn>\n");
			buffer.append("</mfrac>\n");
		}
		return buffer.toString();
	}

	protected Arithmetic newinstance() {
		return new Rational();
	}
}
