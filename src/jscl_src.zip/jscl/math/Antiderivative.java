package jscl.math;

import java.util.*;
import jscl.math.function.*;

public class Antiderivative {
	Variable variable;
	Arithmetic result;

	public Antiderivative(Variable variable) {
		this.variable=variable;
	}

	public void compute(Frac frac) {
		Debug.println("antiderivative");
		Debug.increment();
		Arithmetic n=frac.parameter[0];
		Arithmetic d=frac.parameter[1];
		Arithmetic r[]=reduce(n,d);
		r=divideAndRemainder(r[0],r[1]);
		Arithmetic s=new Inv(r[2]).evaluate();
		Arithmetic p=r[0].multiply(s);
		Arithmetic a=r[1].multiply(s);
		result=p.antiderivative(variable).add(hermite(a,d));
		Debug.decrement();
	}

	public void compute(Root root) throws NotIntegrableException {
		int d=root.degree();
		Arithmetic a[]=root.parameter;
		boolean b=d>0;
		b=b && a[0].negate().isIdentity(variable);
		for(int i=1;i<d;i++) b=b && a[i].signum()==0;
		b=b && a[d].compareTo(JSCLInteger.valueOf(1))==0;
		if(b) {
			result=new Pow(
				a[0].negate(),
				new Inv(JSCLInteger.valueOf(d)).evaluate()
			).antiderivative(0);
		} else throw new NotIntegrableException();
	}

	Arithmetic[] reduce(Arithmetic n, Arithmetic d) {
		Debug.println("reduce("+n+", "+d+")");
		Polynomial pn=UnivariatePolynomial.valueOf(n,variable);
		Polynomial pd=UnivariatePolynomial.valueOf(d,variable);
		Polynomial gcd=pn.gcd(pd);
		return new Arithmetic[] {
			pn.divide(gcd).arithmeticValue(),
			pd.divide(gcd).arithmeticValue()
		};
	}

	Arithmetic[] divideAndRemainder(Arithmetic n, Arithmetic d) {
		Debug.println("divideAndRemainder("+n+", "+d+")");
		Polynomial pn=PolynomialWithSyzygy.valueOf(n,variable,0);
		Polynomial pd=PolynomialWithSyzygy.valueOf(d,variable,1);
		PolynomialWithSyzygy pr=(PolynomialWithSyzygy)pn.remainder(pd);
		return new Arithmetic[] {
			pr.syzygy[1].arithmeticValue().negate(),
			pr.arithmeticValue(),
			pr.syzygy[0].arithmeticValue()
		};
	}

	Arithmetic[] bezout(Arithmetic a, Arithmetic b) {
		Debug.println("bezout("+a+", "+b+")");
		Polynomial pa=PolynomialWithSyzygy.valueOf(a,variable,0);
		Polynomial pb=PolynomialWithSyzygy.valueOf(b,variable,1);
		PolynomialWithSyzygy gcd=(PolynomialWithSyzygy)pa.gcd(pb);
		return new Arithmetic[] {
			gcd.syzygy[0].arithmeticValue(),
			gcd.syzygy[1].arithmeticValue(),
			gcd.arithmeticValue()
		};
	}

	Arithmetic hermite(Arithmetic a, Arithmetic d) {
		Debug.println("hermite("+a+", "+d+")");
		UnivariatePolynomial sd[]=UnivariatePolynomial.valueOf(d,variable).squarefreeDecomposition();
		int m=sd.length-1;
		if(m<2) return trager(a,d);
		else {
			Arithmetic u=JSCLInteger.valueOf(1);
			for(int i=1;i<m;i++) {
				u=u.multiply(sd[i].arithmeticValue().pow(i));
			}
			Arithmetic v=sd[m].arithmeticValue();
			Arithmetic vprime=sd[m].derivative().arithmeticValue();
			Arithmetic uvprime=u.multiply(vprime);
			Arithmetic r[]=bezout(uvprime,v);
			Arithmetic b=r[0].multiply(a);
			Arithmetic c=r[1].multiply(a);
			Arithmetic s=r[2];
			r=divideAndRemainder(b,v);
			b=r[1];
			c=c.multiply(r[2]).add(r[0].multiply(uvprime));
			s=new Inv(s.multiply(r[2]).multiply(JSCLInteger.valueOf(1-m))).evaluate();
			b=b.multiply(s);
			c=c.multiply(s);
			Arithmetic bprime=UnivariatePolynomial.valueOf(b,variable).derivative().arithmeticValue();
			return new Frac(b,v.pow(m-1)).evaluate().add(hermite(JSCLInteger.valueOf(1-m).multiply(c).subtract(u.multiply(bprime)),u.multiply(v.pow(m-1))));
		}
	}

	Arithmetic trager(Arithmetic a, Arithmetic d) {
		Debug.println("trager("+a+", "+d+")");
		Variable t=new TechnicalVariable("t");
		UnivariatePolynomial pd=UnivariatePolynomial.valueOf(d,variable);
		UnivariatePolynomial pa=(UnivariatePolynomial)UnivariatePolynomial.valueOf(a,variable).subtract(pd.derivative().multiply(t.expressionValue()));
		UnivariatePolynomial rs[]=pd.remainderSequence(pa);
		for(int i=0;i<rs.length;i++) if(rs[i]!=null) rs[i]=UnivariatePolynomial.valueOf((i>0?rs[i].normalize():rs[i]).arithmeticValue(),t);
		UnivariatePolynomial q[]=rs[0].squarefreeDecomposition();
		int m=q.length-1;
		Arithmetic s=JSCLInteger.valueOf(0);
		for(int i=1;i<=m;i++) {
			for(int j=0;j<q[i].degree();j++) {
				Arithmetic a2=new Root(q[i],j).evaluate();
				s=s.add(a2.multiply(new Log(i==pd.degree()?d:rs[i].substitute(a2)).evaluate()));
			}
		}
		return s;
	}

	public Arithmetic getValue() {
		return result;
	}
}

class PolynomialWithSyzygy extends UnivariatePolynomial {
	Polynomial syzygy[]=new Polynomial[2];

	PolynomialWithSyzygy(Variable var) {
		super(var);
	}

	public Polynomial subtract(Polynomial polynomial) {
		PolynomialWithSyzygy p2=(PolynomialWithSyzygy)polynomial;
		PolynomialWithSyzygy p=(PolynomialWithSyzygy)super.subtract(p2);
		for(int i=0;i<syzygy.length;i++) p.syzygy[i]=syzygy[i].subtract(p2.syzygy[i]);
		return p;
	}

	public Polynomial multiply(Arithmetic arithmetic) {
		PolynomialWithSyzygy p=(PolynomialWithSyzygy)super.multiply(arithmetic);
		for(int i=0;i<syzygy.length;i++) p.syzygy[i]=syzygy[i].multiply(arithmetic);
		return p;
	}

	public Polynomial multiply(Monomial monomial, Arithmetic arithmetic) {
		PolynomialWithSyzygy p=(PolynomialWithSyzygy)super.multiply(monomial,arithmetic);
		for(int i=0;i<syzygy.length;i++) p.syzygy[i]=syzygy[i].multiply(monomial,arithmetic);
		return p;
	}

	public Polynomial remainder(Polynomial polynomial) throws ArithmeticException {
		Polynomial p=this;
		Polynomial q=polynomial;
		int d=p.degree();
		for(int i=d-q.degree()+1;i>0;) { i--;
			Arithmetic c1=p.headCoefficient();
			Arithmetic c2=q.headCoefficient();
			Arithmetic c=c1.scm(c2);
			c1=c.divide(c1);
			c2=c.divide(c2);
			p=p.multiply(c1).subtract(q.multiply(monomial(i),c2));
		}
		return p;
	}

	public Polynomial gcd(Polynomial polynomial) {
		Polynomial p=this;
		Polynomial q=polynomial;
		if(p.signum()==0) return q;
		while(q.signum()!=0) {
			Polynomial r=p.remainder(q);
			p=q;
			q=r;
		}
		return p;
	}

//	public Arithmetic headCoefficient() {
//		return get(degree());
//	}

	static PolynomialWithSyzygy valueOf(Arithmetic arithmetic, Variable var, int n) {
		PolynomialWithSyzygy p=new PolynomialWithSyzygy(var);
		p.put(arithmetic);
		p.initSyzygy(n);
		return p;
	}

	void initSyzygy(int n) {
		for(int i=0;i<syzygy.length;i++) syzygy[i]=UnivariatePolynomial.valueOf(JSCLInteger.valueOf(i==n?1:0),unknown[0]);
	}

	protected Polynomial newinstance() {
		return new PolynomialWithSyzygy(unknown[0]);
	}
}
