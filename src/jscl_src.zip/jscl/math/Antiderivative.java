package jscl.math;

import java.util.*;
import jscl.math.function.*;

public class Antiderivative {
	Variable variable;
	Arithmetic result;

	public Antiderivative(Variable variable) {
		this.variable=variable;
	}

	public void compute(Frac frac) {
		Debug.println("antiderivative");
		Debug.increment();
		Arithmetic n=frac.parameter[0];
		Arithmetic d=frac.parameter[1];
		Arithmetic r[]=reduce(n,d);
		r=divideAndRemainder(r[0],r[1]);
		Arithmetic s=new Inv(r[2]).evaluate();
		Arithmetic p=r[0].multiply(s);
		Arithmetic a=r[1].multiply(s);
		result=p.antiderivative(variable).add(hermite(a,d));
		Debug.decrement();
	}

	public void compute(Root root) throws NotIntegrableException {
		int d=root.degree();
		Arithmetic a[]=root.parameter;
		boolean b=d>0;
		b=b && a[0].negate().isIdentity(variable);
		for(int i=1;i<d;i++) b=b && a[i].signum()==0;
		b=b && a[d].compareTo(JSCLInteger.valueOf(1))==0;
		if(b) {
			result=new Pow(
				a[0].negate(),
				new Inv(JSCLInteger.valueOf(d)).evaluate()
			).antiderivative(0);
		} else throw new NotIntegrableException();
	}

	Arithmetic[] reduce(Arithmetic n, Arithmetic d) {
		Debug.println("reduce("+n+", "+d+")");
		UnivariatePolynomial pn=UnivariatePolynomial.valueOf(n,variable);
		UnivariatePolynomial pd=UnivariatePolynomial.valueOf(d,variable);
		UnivariatePolynomial gcd=(UnivariatePolynomial)pn.gcd(pd);
		return new Arithmetic[] {
			Expression.valueOf(pn.divide(gcd)),
			Expression.valueOf(pd.divide(gcd))
		};
	}

	Arithmetic[] divideAndRemainder(Arithmetic n, Arithmetic d) {
		Debug.println("divideAndRemainder("+n+", "+d+")");
		PolynomialWithSyzygy pn=PolynomialWithSyzygy.valueOf(n,variable,0);
		PolynomialWithSyzygy pd=PolynomialWithSyzygy.valueOf(d,variable,1);
		PolynomialWithSyzygy pr=(PolynomialWithSyzygy)pn.remainder(pd);
		return new Arithmetic[] {
			Expression.valueOf(pr.syzygy[1]).negate(),
			Expression.valueOf(pr),
			Expression.valueOf(pr.syzygy[0])
		};
	}

	Arithmetic[] bezout(Arithmetic a, Arithmetic b) {
		Debug.println("bezout("+a+", "+b+")");
		PolynomialWithSyzygy pa=PolynomialWithSyzygy.valueOf(a,variable,0);
		PolynomialWithSyzygy pb=PolynomialWithSyzygy.valueOf(b,variable,1);
		PolynomialWithSyzygy gcd=(PolynomialWithSyzygy)pa.gcd(pb);
		return new Arithmetic[] {
			Expression.valueOf(gcd.syzygy[0]),
			Expression.valueOf(gcd.syzygy[1]),
			Expression.valueOf(gcd)
		};
	}

	Arithmetic hermite(Arithmetic a, Arithmetic d) {
		Debug.println("hermite("+a+", "+d+")");
		UnivariatePolynomial sd[]=UnivariatePolynomial.valueOf(d,variable).squarefreeDecomposition();
		int m=sd.length-1;
		if(m<2) return trager(a,d);
		else {
			Arithmetic u=JSCLInteger.valueOf(1);
			for(int i=1;i<m;i++) {
				u=u.multiply(Expression.valueOf(sd[i]).pow(i));
			}
			Arithmetic v=Expression.valueOf(sd[m]);
			Arithmetic vprime=Expression.valueOf(sd[m].derivative());
			Arithmetic uvprime=u.multiply(vprime);
			Arithmetic r[]=bezout(uvprime,v);
			Arithmetic b=r[0].multiply(a);
			Arithmetic c=r[1].multiply(a);
			Arithmetic s=r[2];
			r=divideAndRemainder(b,v);
			b=r[1];
			c=c.multiply(r[2]).add(r[0].multiply(uvprime));
			s=new Inv(s.multiply(r[2]).multiply(JSCLInteger.valueOf(1-m))).evaluate();
			b=b.multiply(s);
			c=c.multiply(s);
			Arithmetic bprime=Expression.valueOf(UnivariatePolynomial.valueOf(b,variable).derivative());
			return new Frac(b,v.pow(m-1)).evaluate().add(hermite(JSCLInteger.valueOf(1-m).multiply(c).subtract(u.multiply(bprime)),u.multiply(v.pow(m-1))));
		}
	}

	Arithmetic trager(Arithmetic a, Arithmetic d) {
		Debug.println("trager("+a+", "+d+")");
		Variable t=new TechnicalVariable("t");
		UnivariatePolynomial pd=UnivariatePolynomial.valueOf(d,variable);
		UnivariatePolynomial pa=(UnivariatePolynomial)UnivariatePolynomial.valueOf(a,variable).subtract(t.expressionValue().multiply(pd.derivative()));
		UnivariatePolynomial rs[]=pd.remainderSequence(pa);
		for(int i=0;i<rs.length;i++) if(rs[i]!=null) rs[i]=UnivariatePolynomial.valueOf(i>0?rs[i].normalize():rs[i],t);
		UnivariatePolynomial q[]=rs[0].squarefreeDecomposition();
		int m=q.length-1;
		Arithmetic s=JSCLInteger.valueOf(0);
		for(int i=1;i<=m;i++) {
			for(int j=0;j<q[i].degree();j++) {
				Arithmetic a2=new Root(q[i],j).evaluate();
				s=s.add(a2.multiply(new Log(i==pd.degree()?d:rs[i].substitute(a2)).evaluate()));
			}
		}
		return s;
	}

	public Arithmetic getValue() {
		return result;
	}
}

class PolynomialWithSyzygy extends Polynomial {
	Arithmetic syzygy[]=new Arithmetic[2];

	PolynomialWithSyzygy(Variable var) {
		super(new Variable[] {var},Monomial.lexicographic,0);
	}

	Polynomial polynomial(Arithmetic arithmetic) {
		return polynomial(0,arithmetic);
	}

	Polynomial polynomial(int n, Arithmetic arithmetic) {
		return polynomial(monomial(n),arithmetic);
	}

	Polynomial polynomial(Monomial monomial, Arithmetic arithmetic) {
		Polynomial p=new Polynomial(unknown,ordering,modulo);
		p.put(monomial,arithmetic);
		return p;
	}

	Monomial monomial(int n) {
		return Monomial.valueOf(new int[] {n},unknown,ordering);
	}

	public Arithmetic gcd(Arithmetic arithmetic) {
		PolynomialWithSyzygy p=this;
		PolynomialWithSyzygy q=(PolynomialWithSyzygy)arithmetic;
		if(p.signum()==0) return q;
		while(q.signum()!=0) {
			PolynomialWithSyzygy r=p.remainder(q);
			p=q;
			q=r;
		}
		return p;
	}

	PolynomialWithSyzygy remainder(PolynomialWithSyzygy polynomial) {
		PolynomialWithSyzygy p=this;
		PolynomialWithSyzygy q=polynomial;
		int d=p.degree();
		for(int i=d-q.degree()+1;i>0;) { i--;
			Arithmetic c1=(Arithmetic)p.headTerm().getValue();
			Arithmetic c2=(Arithmetic)q.headTerm().getValue();
			Arithmetic c=c1.scm(c2);
			c1=c.divide(c1);
			c2=c.divide(c2);
			p=p.reduce(c1,q,monomial(i),c2);
		}
		return p;
	}

	PolynomialWithSyzygy reduce(Arithmetic c1, PolynomialWithSyzygy p2, Monomial m2, Arithmetic c2) {
		PolynomialWithSyzygy p=(PolynomialWithSyzygy)newinstance();
		Iterator it=content.entrySet().iterator();
		while(it.hasNext()) {
			Map.Entry e=(Map.Entry)it.next();
			p.put(
				(Monomial)e.getKey(),
				((Arithmetic)e.getValue()).multiply(c1)
			);
		}
		it=p2.content.entrySet().iterator();
		while(it.hasNext()) {
			Map.Entry e=(Map.Entry)it.next();
			p.put(
				(Monomial)((Monomial)e.getKey()).multiply(m2),
				((Arithmetic)e.getValue()).multiply(c2).negate()
			);
		}
		for(int i=0;i<p.syzygy.length;i++) p.syzygy[i]=syzygy[i].multiply(polynomial(c1)).subtract(p2.syzygy[i].multiply(polynomial(m2,c2)));
		return p;
	}

//	Arithmetic headCoefficient() {
//		return (Arithmetic)content.get(monomial(degree()));
//	}

	static PolynomialWithSyzygy valueOf(Arithmetic arithmetic, Variable var, int n) {
		PolynomialWithSyzygy p=new PolynomialWithSyzygy(var);
		p.put(arithmetic);
		for(int i=0;i<p.syzygy.length;i++) p.syzygy[i]=p.polynomial(JSCLInteger.valueOf(i==n?1:0));
		return p;
	}

	protected Arithmetic newinstance() {
		return new PolynomialWithSyzygy(unknown[0]);
	}
}
