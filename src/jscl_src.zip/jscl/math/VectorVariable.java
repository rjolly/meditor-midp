package jscl.math;

import jscl.text.*;

public class VectorVariable extends ArithmeticVariable {
	public static final Parser parser=VectorVariableParser.parser;

	public VectorVariable(JSCLVector vector) {
		super(vector);
	}

	public Arithmetic elementary() {
		ArithmeticVariable v=(ArithmeticVariable)newinstance();
		v.content=content.elementary();
		return v.expressionValue();
	}

	public Arithmetic simplify() {
		ArithmeticVariable v=(ArithmeticVariable)newinstance();
		v.content=content.simplify();
		return v.expressionValue();
	}

	public String toString() {
		return content.toString();
	}

	public String toMathML(Object data) {
		return content.toMathML(data);
	}

	protected Variable newinstance() {
		return new VectorVariable(null);
	}
}

class VectorVariableParser extends Parser {
	public static final Parser parser=new VectorVariableParser();

	private VectorVariableParser() {}

	public Object parse(String str, int pos[]) throws ParseException {
		JSCLVector v;
		try {
			v=(JSCLVector)JSCLVector.parser.parse(str,pos);
		} catch (ParseException e) {
			throw e;
		}
		return new VectorVariable(v);
	}
}
