package jscl.math;

import jscl.text.*;

public class VectorVariable extends GenericVariable {
	public static final Parser parser=VectorVariableParser.parser;

	public VectorVariable(Generic generic) {
		super(generic);
	}

	protected Variable newinstance() {
		return new VectorVariable(null);
	}
}

class VectorVariableParser extends Parser {
	public static final Parser parser=new VectorVariableParser();

	private VectorVariableParser() {}

	public Object parse(String str, int pos[]) throws ParseException {
		JSCLVector v;
		try {
			v=(JSCLVector)JSCLVector.parser.parse(str,pos);
		} catch (ParseException e) {
			throw e;
		}
		return new VectorVariable(v);
	}
}
