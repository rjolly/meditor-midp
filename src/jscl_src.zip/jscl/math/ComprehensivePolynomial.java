package jscl.math;

import java.util.*;

public abstract class ComprehensivePolynomial extends MultivariatePolynomial {
	ComprehensivePolynomial(Variable unknown[], Comparator ordering) {
		super(unknown,ordering);
	}

	Arithmetic uncoefficient(Arithmetic arithmetic) {
		return arithmetic;
	}

	Arithmetic coefficient(Arithmetic arithmetic) {
		return arithmetic;
	}
}
