package jscl.math;

import java.util.*;

public abstract class ComprehensivePolynomial extends MultivariatePolynomial {
	ComprehensivePolynomial(Variable unknown[], Comparator ordering) {
		super(unknown,ordering);
	}

	protected Arithmetic uncoefficient(Arithmetic arithmetic) {
		return arithmetic;
	}

	protected Arithmetic coefficient(Arithmetic arithmetic) {
		return arithmetic;
	}
}
