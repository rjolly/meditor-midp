package jscl.math;

public class NotIntegrableException extends ArithmeticException {
	public NotIntegrableException() {}

	public NotIntegrableException(String s) {
		super(s);
	}
}
