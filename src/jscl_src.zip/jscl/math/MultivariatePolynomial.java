package jscl.math;

import java.util.*;
import jscl.text.*;
import jscl.util.*;

public abstract class MultivariatePolynomial extends Polynomial {
	final Variable unknown[];
	final Comparator ordering;
	final MySortedMap content=new MyTreeMap();
	int degree;
	int sugar;

	MultivariatePolynomial(Variable unknown[], Comparator ordering) {
		this.unknown=unknown;
		this.ordering=ordering;
	}

	public Polynomial add(Polynomial polynomial) {
		MultivariatePolynomial p=(MultivariatePolynomial)valueof(this);
		MultivariatePolynomial p2=(MultivariatePolynomial)polynomial;
		Iterator it=p2.content.entrySet().iterator();
		while(it.hasNext()) {
			Map.Entry e=(Map.Entry)it.next();
			p.put(
				(Monomial)e.getKey(),
				(Arithmetic)e.getValue()
			);
		}
		p.sugar=Math.max(sugar,p2.sugar);
		return p;
	}

	public Polynomial subtract(Polynomial polynomial) {
		MultivariatePolynomial p=(MultivariatePolynomial)valueof(this);
		MultivariatePolynomial p2=(MultivariatePolynomial)polynomial;
		Iterator it=p2.content.entrySet().iterator();
		while(it.hasNext()) {
			Map.Entry e=(Map.Entry)it.next();
			p.put(
				(Monomial)e.getKey(),
				((Arithmetic)e.getValue()).negate()
			);
		}
		p.sugar=Math.max(sugar,p2.sugar);
		return p;
	}

	public Polynomial multiply(Polynomial polynomial) {
		MultivariatePolynomial p=(MultivariatePolynomial)newinstance();
		MultivariatePolynomial p2=(MultivariatePolynomial)polynomial;
		Iterator it2=p2.content.entrySet().iterator();
		while(it2.hasNext()) {
			Map.Entry e2=(Map.Entry)it2.next();
			Monomial m=(Monomial)e2.getKey();
			Arithmetic a=(Arithmetic)e2.getValue();
			Iterator it=content.entrySet().iterator();
			while(it.hasNext()) {
				Map.Entry e=(Map.Entry)it.next();
				p.put(
					((Monomial)e.getKey()).multiply(m),
					((Arithmetic)e.getValue()).multiply(a)
				);
			}
		}
		p.sugar=sugar*p2.sugar;
		return p;
	}

	public Polynomial multiply(Arithmetic arithmetic) {
		MultivariatePolynomial p=(MultivariatePolynomial)newinstance();
		Iterator it=content.entrySet().iterator();
		while(it.hasNext()) {
			Map.Entry e=(Map.Entry)it.next();
			p.put(
				(Monomial)e.getKey(),
				((Arithmetic)e.getValue()).multiply(arithmetic)
			);
		}
		p.sugar=sugar;
		return p;
	}

	public Polynomial multiply(Monomial monomial, Arithmetic arithmetic) {
		MultivariatePolynomial p=(MultivariatePolynomial)newinstance();
		Iterator it=content.entrySet().iterator();
		while(it.hasNext()) {
			Map.Entry e=(Map.Entry)it.next();
			p.put(
				((Monomial)e.getKey()).multiply(monomial),
				((Arithmetic)e.getValue()).multiply(arithmetic)
			);
		}
		p.sugar=sugar+monomial.degree();
		return p;
	}

	public Polynomial multiply(Monomial monomial) {
		MultivariatePolynomial p=(MultivariatePolynomial)newinstance();
		Iterator it=content.entrySet().iterator();
		while(it.hasNext()) {
			Map.Entry e=(Map.Entry)it.next();
			p.put(
				((Monomial)e.getKey()).multiply(monomial),
				(Arithmetic)e.getValue()
			);
		}
		p.sugar=sugar+monomial.degree();
		return p;
	}

	public Polynomial divide(Polynomial polynomial) throws ArithmeticException {
		return null;
	}

	public Polynomial divide(Arithmetic arithmetic) throws ArithmeticException {
		MultivariatePolynomial p=(MultivariatePolynomial)newinstance();
		Iterator it=content.entrySet().iterator();
		while(it.hasNext()) {
			Map.Entry e=(Map.Entry)it.next();
			p.put(
				(Monomial)e.getKey(),
				((Arithmetic)e.getValue()).divide(arithmetic)
			);
		}
		p.sugar=sugar;
		return p;
	}

	public Polynomial divide(Monomial monomial) throws ArithmeticException {
		MultivariatePolynomial p=(MultivariatePolynomial)newinstance();
		Iterator it=content.entrySet().iterator();
		while(it.hasNext()) {
			Map.Entry e=(Map.Entry)it.next();
			p.put(
				((Monomial)e.getKey()).divide(monomial),
				(Arithmetic)e.getValue()
			);
		}
		p.sugar=sugar-monomial.degree();
		return p;
	}

	public Polynomial[] divideAndRemainder(Polynomial polynomial) throws ArithmeticException {
		return null;
	}

	public Polynomial gcd(Polynomial polynomial) {
		return null;
	}

	public Arithmetic gcd() {
		Arithmetic a=coefficient(JSCLInteger.valueOf(0));
		for(Iterator it=content.values().iterator(true);it.hasNext();) {
			a=a.gcd((Arithmetic)it.next());
		}
		return a;
	}

	public Monomial monomialGcd() {
		Monomial m=tailMonomial();
		for(Iterator it=content.keySet().iterator();it.hasNext();) {
			m=m.gcd((Monomial)it.next());
		}
		return m;
	}

	public Polynomial negate() {
		return newinstance().subtract(this);
	}

	public int signum() {
		if(content.isEmpty()) return 0;
		else return tailCoefficient().signum();
	}

	public int degree() {
		return degree;
	}

	public int sugar() {
		return sugar;
	}

	public Polynomial valueof(Polynomial polynomial) {
		MultivariatePolynomial p=(MultivariatePolynomial)newinstance();
		p.put(polynomial);
		return p;
	}

	public Polynomial valueof(Arithmetic arithmetic) {
		MultivariatePolynomial p=(MultivariatePolynomial)newinstance();
		p.put(arithmetic);
		return p;
	}

	public Polynomial valueof(Monomial monomial) {
		MultivariatePolynomial p=(MultivariatePolynomial)newinstance();
		p.put(monomial);
		return p;
	}

	public Monomial headMonomial() {
		return (Monomial)content.lastKey();
	}

	public Monomial tailMonomial() {
		return (Monomial)content.firstKey();
	}

	public Arithmetic headCoefficient() {
		return (Arithmetic)content.values().iterator(true).next();
	}

	public Arithmetic tailCoefficient() {
		return (Arithmetic)content.values().iterator().next();
	}

	public Polynomial s_polynomial(Polynomial polynomial) {
		Monomial m1=headMonomial();
		Arithmetic c1=headCoefficient();
		Monomial m2=polynomial.headMonomial();
		Arithmetic c2=polynomial.headCoefficient();
		Monomial m=m1.scm(m2);
		m1=m.divide(m1);
		m2=m.divide(m2);
		Arithmetic c=c1.scm(c2);
		c1=c.divide(c1);
		c2=c.divide(c2);
		return multiply(m1,c1).subtract(polynomial.multiply(m2,c2)).normalize();
	}

	public Polynomial reduce(Basis basis) {
		Polynomial p=this;
		loop: while(p.signum()!=0) {
			Monomial m1=p.headMonomial();
			Arithmetic c1=p.headCoefficient();
			Iterator it=basis.content.values().iterator();
			while(it.hasNext()) {
				Polynomial q=(Polynomial)it.next();
				Monomial m2=q.headMonomial();
				if(m1.multiple(m2)) {
					Arithmetic c2=q.headCoefficient();
					Monomial m=m1.divide(m2);
					Arithmetic c=c1.scm(c2);
					c1=c.divide(c1);
					c2=c.divide(c2);
					p=p.multiply(c1).subtract(q.multiply(m,c2)).normalize();
					continue loop;
				}
			}
			break;
		}
		return p;
	}

	public Polynomial reduceCompletely(Basis basis) {
		Polynomial p=this;
		Monomial l=null;
		loop: while(p.signum()!=0) {
			Iterator it=(l==null?((MultivariatePolynomial)p).content:((MultivariatePolynomial)p).content.headMap(l)).entrySet().iterator(true);
			while(it.hasNext()) {
				Map.Entry e1=(Map.Entry)it.next();
				Monomial m1=(Monomial)e1.getKey();
				Arithmetic c1=(Arithmetic)e1.getValue();
//				if(l==null?false:m1.compareTo(l)>0) continue;
				Iterator it2=basis.content.values().iterator();
				while(it2.hasNext()) {
					Polynomial q=(Polynomial)it2.next();
					Monomial m2=q.headMonomial();
					if(m1.multiple(m2)) {
						Arithmetic c2=q.headCoefficient();
						Monomial m=m1.divide(m2);
						Arithmetic c=c1.scm(c2);
						c1=c.divide(c1);
						c2=c.divide(c2);
						p=p.multiply(c1).subtract(q.multiply(m,c2)).normalize();
						l=m1;
						continue loop;
					}
				}
			}
			break;
		}
		return p;
	}

	public Arithmetic arithmeticValue() {
		Arithmetic a=JSCLInteger.valueOf(0);
		Iterator it=content.entrySet().iterator();
		while(it.hasNext()) {
			Map.Entry e=(Map.Entry)it.next();
			Monomial m=(Monomial)e.getKey();
			Arithmetic a2=uncoefficient((Arithmetic)e.getValue());
			if(m.degree()>0) a=a.add(a2.multiply(Expression.valueOf(m.literalValue())));
			else a=a.add(a2);
		}
		return a;
	}

	public Arithmetic[] elements() {
		Arithmetic a[]=new Arithmetic[content.size()];
		Iterator it=content.values().iterator();
		for(int i=0;it.hasNext();i++) {
			a[i]=(Arithmetic)it.next();
		}
		return a;
	}

	public int compareTo(Object comparable) {
		MultivariatePolynomial p=(MultivariatePolynomial)comparable;
		Iterator it1=content.entrySet().iterator(true);
		Iterator it2=p.content.entrySet().iterator(true);
		while(true) {
			boolean b1=!it1.hasNext();
			boolean b2=!it2.hasNext();
			if(b1 && b2) return 0;
			else if(b1) return -1;
			else if(b2) return 1;
			else {
				Map.Entry e1=(Map.Entry)it1.next();
				Map.Entry e2=(Map.Entry)it2.next();
				Monomial m1=(Monomial)e1.getKey();
				Monomial m2=(Monomial)e2.getKey();
				int c=m1.compareTo(m2);
				if(c<0) return -1;
				else if(c>0) return 1;
				else {
					Arithmetic a1=(Arithmetic)e1.getValue();
					Arithmetic a2=(Arithmetic)e2.getValue();
					c=a1.compareTo(a2);
					if(c<0) return -1;
					else if(c>0) return 1;
				}
			}
		}
	}

	void put(Polynomial polynomial) {
		Iterator it=((MultivariatePolynomial)polynomial).content.entrySet().iterator();
		while(it.hasNext()) {
			Map.Entry e=(Map.Entry)it.next();
			put(
				(Monomial)e.getKey(),
				(Arithmetic)e.getValue()
			);
		}
		sugar=polynomial.sugar();
	}

	public static MultivariatePolynomial valueOf(Arithmetic arithmetic, Variable unknown[], Comparator ordering) {
		return valueOf(arithmetic,unknown,ordering,0);
	}

	public static MultivariatePolynomial valueOf(Arithmetic arithmetic, Variable unknown[], Comparator ordering, int modulo) {
		MultivariatePolynomial p;
		switch(modulo) {
		case 0:
			p=new IntegerPolynomial(unknown,ordering);
			break;
		case 1:
			p=new RationalPolynomial(unknown,ordering);
			break;
		case 2:
			p=new BooleanPolynomial(unknown,ordering);
			break;
		default:
			p=new ModularPolynomial(unknown,ordering,modulo);
		}
		p.put(arithmetic);
		return p;
	}

	void put(Arithmetic arithmetic) {
		if(arithmetic instanceof Expression) {
			Expression ex=(Expression)arithmetic;
			Iterator it=ex.content.entrySet().iterator();
			while(it.hasNext()) {
				Map.Entry e=(Map.Entry)it.next();
				Literal l=(Literal)e.getKey();
				JSCLInteger en=(JSCLInteger)e.getValue();
				Monomial m=monomial(l);
				l=l.divide(m.literalValue());
				if(l.degree()>0) put(m,coefficient(en.multiply(Expression.valueOf(l))));
				else put(m,coefficient(en));
				sugar=Math.max(sugar,m.degree());
			}
		} else if(arithmetic instanceof JSCLInteger) {
			JSCLInteger en=(JSCLInteger)arithmetic;
			put(new Monomial(unknown,ordering),coefficient(en));
		} else throw new ArithmeticException();
	}

	Monomial monomial(Literal literal) {
		Monomial m=new Monomial(unknown,ordering);
		Iterator it=literal.content.entrySet().iterator();
		while(it.hasNext()) {
			Map.Entry e=(Map.Entry)it.next();
			Variable v=(Variable)e.getKey();
			int c=((Integer)e.getValue()).intValue();
			int n=Monomial.variable(v,unknown);
			if(n<unknown.length) m.put(n,c);
		}
		return m;
	}

	void put(Monomial monomial) {
		put(monomial,coefficient(JSCLInteger.valueOf(1)));
		sugar=monomial.degree();
	}

	void put(Monomial monomial, Arithmetic arithmetic) {
//		Object o=content.get(monomial);
//		if(o!=null) {
//			Arithmetic a=arithmetic.add((Arithmetic)o);
		Map.Entry e=content.myGetEntry(monomial);
		if(e!=null) {
			Arithmetic a=arithmetic.add((Arithmetic)e.getValue());
			if(a.signum()==0) content.remove(monomial);
//			else content.put(monomial,a);
			else e.setValue(a);
		} else {
			if(arithmetic.signum()==0);
			else content.put(monomial,arithmetic);
		}
		if(content.isEmpty()) degree=0;
		else degree=headMonomial().degree();
	}

	public String toString() {
		StringBuffer buffer=new StringBuffer();
		if(signum()==0) buffer.append("0");
		Iterator it=content.entrySet().iterator();
		for(int i=0;it.hasNext();i++) {
			Map.Entry e=(Map.Entry)it.next();
			Monomial m=(Monomial)e.getKey();
			Arithmetic a=(Arithmetic)e.getValue();
			if(a instanceof Expression) a=a.signum()>0?new ExpressionVariable(a).expressionValue():new ExpressionVariable(a.negate()).expressionValue().negate();
			if(a.signum()==1 && i>0) buffer.append("+");
			if(m.degree()==0) buffer.append(a);
			else {
				if(a.compareTo(JSCLInteger.valueOf(1))==0);
				else if(a.compareTo(JSCLInteger.valueOf(-1))==0) buffer.append("-");
				else buffer.append(a).append("*");
				buffer.append(m);
			}
		}
		return buffer.toString();
	}

	public String toMathML(Object data) {
		IndentedBuffer buffer=new IndentedBuffer();
		buffer.append("<mrow>\n");
		if(signum()==0) buffer.append(1,"<mn>0</mn>\n");
		Iterator it=content.entrySet().iterator();
		for(int i=0;it.hasNext();i++) {
			Map.Entry e=(Map.Entry)it.next();
			Monomial m=(Monomial)e.getKey();
			Arithmetic a=(Arithmetic)e.getValue();
			if(a instanceof Expression) a=a.signum()>0?new ExpressionVariable(a).expressionValue():new ExpressionVariable(a.negate()).expressionValue().negate();
			if(a.signum()==1 && i>0) buffer.append(1,"<mo>+</mo>\n");
			if(m.degree()==0) buffer.append(1,Expression.separateSign(a));
			else {
				if(a.compareTo(JSCLInteger.valueOf(1))==0);
				else if(a.compareTo(JSCLInteger.valueOf(-1))==0) buffer.append(1,"<mo>-</mo>\n");
				else buffer.append(1,Expression.separateSign(a));
				buffer.append(1,m.toMathML(null));
			}
		}
		buffer.append("</mrow>\n");
		return buffer.toString();
	}
}
