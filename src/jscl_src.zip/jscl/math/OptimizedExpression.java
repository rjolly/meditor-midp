package jscl.math;

import java.util.*;

public class OptimizedExpression extends Expression {
	OptimizedExpression() {}

	public Arithmetic multiplyAndAdd(Arithmetic arithmetic1, Arithmetic arithmetic2) {
		if(arithmetic1 instanceof Expression && arithmetic2 instanceof Expression) {
			Expression ex1=(Expression)arithmetic1;
			Expression ex2=(Expression)arithmetic2;
			Expression ex=(Expression)valueof(this);
			Iterator it=ex2.content.entrySet().iterator();
			while(it.hasNext()) {
				Map.Entry e=(Map.Entry)it.next();
				Literal l=(Literal)e.getKey();
				JSCLInteger en=(JSCLInteger)e.getValue();
				Iterator it2=ex1.content.entrySet().iterator();
				while(it2.hasNext()) {
					Map.Entry e2=(Map.Entry)it2.next();
					ex.put(
						(Literal)l.multiply((Literal)e2.getKey()),
						(JSCLInteger)en.multiply((JSCLInteger)e2.getValue())
					);
				}
			}
			return ex;
		} else return add(arithmetic1.multiply(arithmetic2));
	}

	public Arithmetic multiplyAndSubtract(Arithmetic arithmetic1, Arithmetic arithmetic2) {
		if(arithmetic1 instanceof Expression && arithmetic2 instanceof Expression) {
			Expression ex1=(Expression)arithmetic1;
			Expression ex2=(Expression)arithmetic2;
			Expression ex=(Expression)valueof(this);
			Iterator it=ex2.content.entrySet().iterator();
			while(it.hasNext()) {
				Map.Entry e=(Map.Entry)it.next();
				Literal l=(Literal)e.getKey();
				JSCLInteger en=(JSCLInteger)e.getValue();
				Iterator it2=ex1.content.entrySet().iterator();
				while(it2.hasNext()) {
					Map.Entry e2=(Map.Entry)it2.next();
					ex.put(
						(Literal)l.multiply((Literal)e2.getKey()),
						(JSCLInteger)en.multiply((JSCLInteger)e2.getValue()).negate()
					);
				}
			}
			return ex;
		} else return subtract(arithmetic1.multiply(arithmetic2));
	}

	public static OptimizedExpression valueOf(Expression expression) {
		OptimizedExpression ex=new OptimizedExpression();
		ex.put(expression);
		return ex;
	}

	protected Arithmetic newinstance() {
		return new OptimizedExpression();
	}
}
