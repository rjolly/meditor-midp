package jscl.math;

import java.util.*;

public class OptimizedExpression extends Expression {
	OptimizedExpression() {}

	public Arithmetic multiplyAndAdd(Arithmetic arithmetic1, Arithmetic arithmetic2) {
		if(arithmetic1 instanceof Expression && arithmetic2 instanceof Expression) {
			Expression ex1=(Expression)arithmetic1;
			Expression ex2=(Expression)arithmetic2;
			Expression ex=(Expression)valueof(this);
			Enumeration k=ex2.content.keys();
			Enumeration e=ex2.content.elements();
			while(k.hasMoreElements()) {
				Literal l=(Literal)k.nextElement();
				JSCLInteger en=(JSCLInteger)e.nextElement();
				Enumeration k2=ex1.content.keys();
				Enumeration e2=ex1.content.elements();
				while(k2.hasMoreElements()) {
					ex.put(
						(Literal)l.multiply((Literal)k2.nextElement()),
						(JSCLInteger)en.multiply((JSCLInteger)e2.nextElement())
					);
				}
			}
			return ex;
		} else return add(arithmetic1.multiply(arithmetic2));
	}

	public Arithmetic multiplyAndSubtract(Arithmetic arithmetic1, Arithmetic arithmetic2) {
		if(arithmetic1 instanceof Expression && arithmetic2 instanceof Expression) {
			Expression ex1=(Expression)arithmetic1;
			Expression ex2=(Expression)arithmetic2;
			Expression ex=(Expression)valueof(this);
			Enumeration k=ex2.content.keys();
			Enumeration e=ex2.content.elements();
			while(k.hasMoreElements()) {
				Literal l=(Literal)k.nextElement();
				JSCLInteger en=(JSCLInteger)e.nextElement();
				Enumeration k2=ex1.content.keys();
				Enumeration e2=ex1.content.elements();
				while(k2.hasMoreElements()) {
					ex.put(
						(Literal)l.multiply((Literal)k2.nextElement()),
						(JSCLInteger)en.multiply((JSCLInteger)e2.nextElement()).negate()
					);
				}
			}
			return ex;
		} else return subtract(arithmetic1.multiply(arithmetic2));
	}

	public static OptimizedExpression valueOf(Expression expression) {
		OptimizedExpression ex=new OptimizedExpression();
		ex.put(expression);
		return ex;
	}

	protected Arithmetic newinstance() {
		return new OptimizedExpression();
	}
}
