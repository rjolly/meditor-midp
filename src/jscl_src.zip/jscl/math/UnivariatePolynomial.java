package jscl.math;

import java.util.*;
import jscl.math.function.*;

public class UnivariatePolynomial extends Polynomial {
	UnivariatePolynomial(Variable var) {
		super(new Variable[] {var},Monomial.lexicographic,0);
	}

	public Arithmetic multiply(Arithmetic arithmetic) {
		if(arithmetic instanceof UnivariatePolynomial) {
			UnivariatePolynomial p=(UnivariatePolynomial)newinstance();
			UnivariatePolynomial q=(UnivariatePolynomial)arithmetic;
			for(int i=degree();i>=0;i--) {
				for(int j=q.degree();j>=0;j--) p.put(i+j,get(i).multiply(q.get(j)));
			}
			return p;
		} else return super.multiply(arithmetic);
	}

	public Arithmetic divide(Arithmetic arithmetic) throws ArithmeticException {
		if(arithmetic instanceof UnivariatePolynomial) {
			UnivariatePolynomial p[]=(UnivariatePolynomial[])divideAndRemainder(arithmetic);
			if(p[1].signum()==0) return p[0];
			else throw new NotDivisibleException();
		} else return super.divide(arithmetic);
	}

	public Arithmetic[] divideAndRemainder(Arithmetic arithmetic) throws ArithmeticException {
		UnivariatePolynomial p[]={(UnivariatePolynomial)newinstance(),this};
		UnivariatePolynomial q=(UnivariatePolynomial)arithmetic;
		int d=p[1].degree();
		int d2=q.degree();
		for(int i=d-d2+1;i>0;) { i--;
			p[0].put(i,p[1].get(i+d2).divide(q.get(d2)));
			UnivariatePolynomial r=(UnivariatePolynomial)newinstance();
			for(int j=i+d2;j>0;) { j--;
				Arithmetic a=p[1].get(j);
				r.put(j,a.subtract(q.get(j-i).multiply(p[0].get(i))));
			}
			p[1]=r;
		}
		return p;
	}

	public Arithmetic gcd(Arithmetic arithmetic) {
		UnivariatePolynomial p=this;
		UnivariatePolynomial q=(UnivariatePolynomial)arithmetic;
		if(p.signum()==0) return q;
		else if(q.signum()==0) return p;
		if(p.degree()<q.degree()) {
			UnivariatePolynomial r=p;
			p=q;
			q=r;
		}
		int d=p.degree()-q.degree();
		Arithmetic phi=JSCLInteger.valueOf(-1);
		Arithmetic beta=JSCLInteger.valueOf(-1).pow(d+1);
		Arithmetic a1[]=p.gcdAndNormalize();
		Arithmetic a2[]=q.gcdAndNormalize();
		Arithmetic gcd1=a1[0];
		Arithmetic gcd2=a2[0];
		p=(UnivariatePolynomial)a1[1];
		q=(UnivariatePolynomial)a2[1];
		while(q.degree()>0) {
			UnivariatePolynomial r=(UnivariatePolynomial)p.remainder(q).divide(beta);
			if(d>1) phi=q.get(q.degree()).negate().pow(d).divide(phi.pow(d-1));
			else phi=q.get(q.degree()).negate().pow(d).multiply(phi.pow(1-d));
			p=q;
			q=r;
			d=p.degree()-q.degree();
			beta=p.get(p.degree()).negate().multiply(phi.pow(d));
		}
		if(q.signum()==0) {
			p=(UnivariatePolynomial)p.normalize();
		} else {
			p=(UnivariatePolynomial)newinstance();
			p.put(0,JSCLInteger.valueOf(1));
		}
		return p.multiply(gcd1.gcd(gcd2));
	}

	UnivariatePolynomial remainder(UnivariatePolynomial polynomial) {
		UnivariatePolynomial p=this;
		UnivariatePolynomial q=polynomial;
		int d=p.degree();
		for(int i=d-q.degree()+1;i>0;) { i--;
			UnivariatePolynomial r=(UnivariatePolynomial)newinstance();
			for(int j=i+q.degree();j>0;) { j--;
				Arithmetic a=p.get(j).multiply(q.get(q.degree()));
				r.put(j,a.subtract(q.get(j-i).multiply(p.get(i+q.degree()))));
			}
			p=r;
		}
		return p;
	}

	public Arithmetic derivative(Variable variable) {
		return derivative().multiply(unknown[0].derivative(variable));
	}

	public Arithmetic[] identification(Arithmetic arithmetic) {
		UnivariatePolynomial p=this;
		UnivariatePolynomial q=(UnivariatePolynomial)arithmetic;
		if(p.degree()<q.degree() || (p.degree()==0 && q.signum()==0)) {
			UnivariatePolynomial r=p;
			p=q;
			q=r;
		}
		UnivariatePolynomial r=p.remainder(q);
		Arithmetic a[]=new Arithmetic[r.degree()+1];
		for(int i=r.degree();i>=0;i--) a[r.degree()-i]=r.get(i);
		return a;
	}

	public Arithmetic resultant(Arithmetic arithmetic) {
		UnivariatePolynomial p=this;
		UnivariatePolynomial q=(UnivariatePolynomial)arithmetic;
		if(p.degree()<q.degree() || (p.degree()==0 && q.signum()==0)) {
			UnivariatePolynomial r=p;
			p=q;
			q=r;
		}
		int d=p.degree()-q.degree();
		Arithmetic phi=JSCLInteger.valueOf(-1);
		Arithmetic beta=JSCLInteger.valueOf(-1).pow(d+1);
		while(q.degree()>0) {
			UnivariatePolynomial r=(UnivariatePolynomial)p.remainder(q).divide(beta);
			if(d>1) phi=q.get(q.degree()).negate().pow(d).divide(phi.pow(d-1));
			else phi=q.get(q.degree()).negate().pow(d).multiply(phi.pow(1-d));
			p=q;
			q=r;
			d=p.degree()-q.degree();
			beta=p.get(p.degree()).negate().multiply(phi.pow(d));
		}
		return q.get(0);
	}

	public UnivariatePolynomial[] remainderSequence(Arithmetic arithmetic) {
		UnivariatePolynomial p=this;
		UnivariatePolynomial q=(UnivariatePolynomial)arithmetic;
		if(p.degree()<q.degree() || (p.degree()==0 && q.signum()==0)) {
			UnivariatePolynomial r=p;
			p=q;
			q=r;
		}
		UnivariatePolynomial s[]=new UnivariatePolynomial[q.degree()+1];
		s[q.degree()]=q;
		int d=p.degree()-q.degree();
		Arithmetic phi=JSCLInteger.valueOf(-1);
		Arithmetic beta=JSCLInteger.valueOf(-1).pow(d+1);
		while(q.degree()>0) {
			UnivariatePolynomial r=(UnivariatePolynomial)p.remainder(q).divide(beta);
			if(d>1) phi=q.get(q.degree()).negate().pow(d).divide(phi.pow(d-1));
			else phi=q.get(q.degree()).negate().pow(d).multiply(phi.pow(1-d));
			p=q;
			q=r;
			s[q.degree()]=q;
			d=p.degree()-q.degree();
			beta=p.get(p.degree()).negate().multiply(phi.pow(d));
		}
		return s;
	}

	public Arithmetic squarefree() {
		return divide(gcd(derivative()));
	}

	public UnivariatePolynomial[] squarefreeDecomposition() {
		SquarefreeDecomposition s=new SquarefreeDecomposition();
		s.compute(this);
		return s.getValue();
	}

	public Arithmetic antiderivative() {
		UnivariatePolynomial p=(UnivariatePolynomial)newinstance();
		for(int i=degree();i>=0;i--) {
			p.put(i+1,get(i).multiply(new Inv(JSCLInteger.valueOf(i+1)).evaluate()));
		}
		return p;
	}

	public Arithmetic derivative() {
		UnivariatePolynomial p=(UnivariatePolynomial)newinstance();
		for(int i=degree();i>0;) { i--;
			p.put(i,get(i+1).multiply(JSCLInteger.valueOf(i+1)));
		}
		return p;
	}

	public Arithmetic substitute(Arithmetic arithmetic) {
		Arithmetic s=JSCLInteger.valueOf(0);
		for(int i=degree();i>=0;i--) {
			s=s.add(get(i).multiply(arithmetic.pow(i)));
		}
		return s;
	}

	public Arithmetic[] element() {
		Arithmetic a[]=new Arithmetic[degree()+1];
		for(int i=degree();i>=0;i--) a[i]=get(i);
		return a;
	}

	Arithmetic solve() {
		if(degree()==1) {
			return get(0).multiply(new Inv(get(1)).evaluate()).negate();
		} else return null;
	}

	public static UnivariatePolynomial valueOf(Arithmetic arithmetic, Variable var) {
		UnivariatePolynomial p=new UnivariatePolynomial(var);
		p.put(arithmetic);
		return p;
	}

	public static UnivariatePolynomial valueOf(Arithmetic arithmetic[], Variable var) {
		UnivariatePolynomial p=new UnivariatePolynomial(var);
		for(int i=0;i<arithmetic.length;i++) p.put(i,arithmetic[i]);
		return p;
	}

	void put(int n, Arithmetic arithmetic) {
		put(monomial(n),arithmetic);
	}

	public Arithmetic get(int n) {
		if(n<0) return JSCLInteger.valueOf(0);
		Monomial m=monomial(n);
		Object o=content.get(m);
		if(o!=null) return (Arithmetic)o;
		else return JSCLInteger.valueOf(0);
	}

	Monomial monomial(int n) {
		return Monomial.valueOf(new int[] {n},unknown,ordering);
	}

	protected Arithmetic newinstance() {
		return new UnivariatePolynomial(unknown[0]);
	}
}

class SquarefreeDecomposition {
	Vector vector;

	void compute(UnivariatePolynomial polynomial) {
		vector=new Vector();
		vector.addElement(null);
		process(polynomial);
	}

	void process(UnivariatePolynomial polynomial) {
		UnivariatePolynomial r=(UnivariatePolynomial)polynomial.gcd(polynomial.derivative());
		UnivariatePolynomial s=(UnivariatePolynomial)polynomial.divide(r);
		vector.addElement(s.divide(s.gcd(r)));
		if(r.degree()==0);
		else process(r);
	}

	UnivariatePolynomial[] getValue() {
		UnivariatePolynomial p[]=new UnivariatePolynomial[vector.size()];
		vector.copyInto(p);
		return p;
	}
}
