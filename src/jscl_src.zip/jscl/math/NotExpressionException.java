package jscl.math;

public class NotExpressionException extends ArithmeticException {
	public NotExpressionException() {}

	public NotExpressionException(String s) {
		super(s);
	}
}
