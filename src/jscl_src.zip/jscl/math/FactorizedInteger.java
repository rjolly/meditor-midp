package jscl.math;

import jscl.util.*;

public class FactorizedInteger extends Factorized {
	FactorizedInteger() {}

	public Arithmetic add(Arithmetic arithmetic) {
		if(arithmetic instanceof FactorizedInteger) {
			return super.add(arithmetic);
		} else if(arithmetic instanceof JSCLInteger) {
			return add(arithmetic.factorize());
		} else {
			return arithmetic.valueof(this).add(arithmetic);
		}
	}

	public Arithmetic multiply(Arithmetic arithmetic) {
		if(arithmetic instanceof FactorizedInteger) {
			return super.multiply(arithmetic);
		} else if(arithmetic instanceof JSCLInteger) {
			return multiply(arithmetic.factorize());
		} else {
			return arithmetic.multiply(this);
		}
	}

	public Arithmetic divide(Arithmetic arithmetic) throws ArithmeticException {
		if(arithmetic instanceof FactorizedInteger) {
			return super.divide(arithmetic);
		} else if(arithmetic instanceof JSCLInteger) {
			return divide(arithmetic.factorize());
		} else {
			return arithmetic.valueof(this).divide(arithmetic);
		}
	}

	public Arithmetic gcd(Arithmetic arithmetic) {
		if(arithmetic instanceof FactorizedInteger) {
			return super.gcd(arithmetic);
		} else if(arithmetic instanceof JSCLInteger) {
			return gcd(arithmetic.factorize());
		} else {
			return arithmetic.valueof(this).gcd(arithmetic);
		}
	}

	public int compareTo(jscl.util.Comparable comparable) {
		if(comparable instanceof FactorizedInteger) {
			return super.compareTo(comparable);
		} else if(comparable instanceof JSCLInteger) {
			return compareTo(((Arithmetic)comparable).factorize());
		} else {
			return ((Arithmetic)comparable).valueof(this).compareTo(comparable);
		}
	}

	protected Arithmetic newinstance() {
		return new FactorizedInteger();
	}
}
