package jscl.math;

import java.util.*;
import jscl.math.function.*;
import jscl.math.operator.*;
import jscl.util.*;

public class Expression extends Arithmetic {
	public static final Parser userInput=UserInputWithEqual.parser;
	public static final Parser parser=ExpressionParser.parser;
	public static final Parser commaAndExpression=CommaAndExpression.parser;
	final MyMap content=new MyTreeMap();

	Expression() {}

	public Arithmetic add(Arithmetic arithmetic) {
		if(arithmetic instanceof Expression) {
			Expression ex=(Expression)valueof(this);
			ex.put(arithmetic);
			return ex;
		} else if(arithmetic instanceof JSCLInteger) {
			return add(valueof(arithmetic));
		} else {
			return arithmetic.valueof(this).add(arithmetic);
		}
	}

	public Arithmetic subtract(Arithmetic arithmetic) {
		if(arithmetic instanceof Expression) {
			Expression ex=(Expression)arithmetic;
			Expression ex2=(Expression)valueof(this);
			Iterator it=ex.content.entrySet().iterator();
			while(it.hasNext()) {
				Map.Entry e=(Map.Entry)it.next();
				ex2.put(
					(Literal)e.getKey(),
					(JSCLInteger)((JSCLInteger)e.getValue()).negate()
				);
			}
			return ex2;
		} else if(arithmetic instanceof JSCLInteger) {
			return subtract(valueof(arithmetic));
		} else {
			return arithmetic.valueof(this).subtract(arithmetic);
		}
	}

	public Arithmetic multiply(Arithmetic arithmetic) {
		if(arithmetic instanceof Expression) {
			Expression ex=(Expression)arithmetic;
			Expression ex2=(Expression)newinstance();
			Iterator it=content.entrySet().iterator();
			while(it.hasNext()) {
				Map.Entry e=(Map.Entry)it.next();
				Literal l=(Literal)e.getKey();
				JSCLInteger en=(JSCLInteger)e.getValue();
				Iterator it2=ex.content.entrySet().iterator();
				while(it2.hasNext()) {
					Map.Entry e2=(Map.Entry)it2.next();
					ex2.put(
						(Literal)l.multiply((Literal)e2.getKey()),
						(JSCLInteger)en.multiply((JSCLInteger)e2.getValue())
					);
				}
			}
			return ex2;
		} else if(arithmetic instanceof JSCLInteger) {
			Expression ex=(Expression)newinstance();
			Iterator it=content.entrySet().iterator();
			while(it.hasNext()) {
				Map.Entry e=(Map.Entry)it.next();
				ex.put(
					(Literal)e.getKey(),
					(JSCLInteger)((JSCLInteger)e.getValue()).multiply(arithmetic)
				);
			}
			return ex;
		} else {
			return arithmetic.multiply(this);
		}
	}

	public Arithmetic divide(Arithmetic arithmetic) throws ArithmeticException {
		if(arithmetic instanceof Expression) {
			Expression ex=(Expression)arithmetic;
			Literal l1=variables();
			Literal l2=ex.variables();
			Literal l=(Literal)l1.gcd(l2);
			Variable v=l.variable();
			if(v==null) {
				if(signum()==0) return this;
				else try {
					return divide(ex.integerValue());
				} catch (NotIntegerException e) {
					throw new NotDivisibleException();
				}
			} else return valueof(UnivariatePolynomial.valueOf(this,v).divide(UnivariatePolynomial.valueOf(ex,v)));
		} else if(arithmetic instanceof JSCLInteger) {
			Expression ex=(Expression)newinstance();
			Iterator it=content.entrySet().iterator();
			while(it.hasNext()) {
				Map.Entry e=(Map.Entry)it.next();
				ex.put(
					(Literal)e.getKey(),
					(JSCLInteger)((JSCLInteger)e.getValue()).divide(arithmetic)
				);
			}
			return ex;
		} else {
			return arithmetic.valueof(this).divide(arithmetic);
		}
	}

	public Arithmetic[] divideAndRemainder(Arithmetic arithmetic) throws ArithmeticException {
		return null;
	}

	public Arithmetic gcd(Arithmetic arithmetic) {
		if(arithmetic instanceof Expression) {
			Expression ex=(Expression)arithmetic;
			Literal l1=variables();
			Literal l2=ex.variables();
			Literal l=(Literal)l1.gcd(l2);
			Variable v=l.variable();
			if(v==null) {
				if(signum()==0) return ex;
				else return gcd(ex.gcd());
			} else return valueof(UnivariatePolynomial.valueOf(this,v).gcd(UnivariatePolynomial.valueOf(ex,v)));
		} else if(arithmetic instanceof JSCLInteger) {
			if(arithmetic.signum()==0) return this;
			else return gcd().gcd(arithmetic);
		} else {
			return arithmetic.valueof(this).gcd(arithmetic);
		}
	}

	public Arithmetic gcd() {
		Arithmetic a=JSCLInteger.valueOf(0);
		for(Iterator it=content.values().iterator();it.hasNext();) {
			a=a.gcd((JSCLInteger)it.next());
		}
		return a;
	}

	public Arithmetic negate() {
		Expression ex=(Expression)newinstance();
		return ex.subtract(this);
	}

	public int signum() {
		if(content.isEmpty()) return 0;
		else return ((Arithmetic)content.values().iterator().next()).signum();
	}

	public int degree() {
		return 0;
	}

	public Arithmetic antiderivative(Variable variable) throws NotIntegrableException {
		if(isPolynomial(variable)) {
			return valueof(UnivariatePolynomial.valueOf(this,variable).antiderivative());
		} else {
			try {
				Variable v=variableValue();
				try {
					return v.antiderivative(variable);
				} catch (NotIntegrableException e) {}
			} catch (NotVariableException e) {}
		}
		throw new NotIntegrableException();
	}

	public Arithmetic derivative(Variable variable) {
		Arithmetic s=JSCLInteger.valueOf(0);
		Literal l=variables();
		Iterator it=l.content.keySet().iterator();
		while(it.hasNext()) {
			Variable v=(Variable)it.next();
			Arithmetic a=UnivariatePolynomial.valueOf(this,v).derivative(variable);
			s=s.add(valueof(a));
		}
		return s;
	}

	public Arithmetic substitute(Variable variable, Arithmetic arithmetic) {
		Literal l=variables();
		Iterator it=l.content.keySet().iterator();
		while(it.hasNext()) {
			Variable v=(Variable)it.next();
			l.content.put(v,v.substitute(variable,arithmetic));
		}
		return substitute(l.content);
	}

	Arithmetic substitute(MyMap map) {
		Arithmetic s=JSCLInteger.valueOf(0);
		Iterator it=content.entrySet().iterator();
		while(it.hasNext()) {
			Map.Entry e=(Map.Entry)it.next();
			Literal l=(Literal)e.getKey();
			JSCLInteger en=(JSCLInteger)e.getValue();
			Arithmetic a=en;
			Iterator it2=l.content.entrySet().iterator();
			while(it2.hasNext()) {
				Map.Entry e2=(Map.Entry)it2.next();
				Variable v=(Variable)e2.getKey();
				int c=((Integer)e2.getValue()).intValue();
				Arithmetic a2=(Arithmetic)map.get(v);
				a=a.multiply(a2.pow(c));
			}
			s=s.add(a);
		}
		return s;
	}

	public Arithmetic expand() {
		Literal l=variables();
		Iterator it=l.content.keySet().iterator();
		while(it.hasNext()) {
			Variable v=(Variable)it.next();
			l.content.put(v,v.expand());
		}
		return substitute(l.content);
	}

	public Factorized factorize() {
		Factorization s=new Factorization();
		s.compute(this);
		return s.getValue();
	}

	public Arithmetic elementary() {
		Literal l=variables();
		Iterator it=l.content.keySet().iterator();
		while(it.hasNext()) {
			Variable v=(Variable)it.next();
			l.content.put(v,v.elementary());
		}
		return substitute(l.content);
	}

	public Arithmetic simplify() {
		Simplification s=new Simplification();
		s.compute(this);
		return s.getValue();
	}

	public Arithmetic valueof(Arithmetic arithmetic) {
		Expression ex=(Expression)newinstance();
		ex.put(arithmetic);
		return ex;
	}

	public Arithmetic[] sumValue() {
		Arithmetic a[]=new Arithmetic[content.size()];
		Iterator it=content.entrySet().iterator();
		for(int i=0;i<a.length;i++) {
			Map.Entry e=(Map.Entry)it.next();
			Literal l=(Literal)e.getKey();
			JSCLInteger en=(JSCLInteger)e.getValue();
			Expression ex=(Expression)newinstance();
			ex.put(l,en);
			a[i]=ex;
		}
		return a;
	}

	public Arithmetic[] productValue() throws NotProductException {
		int n=content.size();
		if(n==0) return new Arithmetic[] {JSCLInteger.valueOf(0)};
		else if(n==1) {
			Map.Entry e=(Map.Entry)content.entrySet().iterator().next();
			Literal l=(Literal)e.getKey();
			JSCLInteger en=(JSCLInteger)e.getValue();
			Arithmetic p[]=l.productValue();
			if(en.compareTo(JSCLInteger.valueOf(1))==0) return p;
			else {
				Arithmetic a[]=new Arithmetic[p.length+1];
				for(int i=0;i<p.length;i++) a[i+1]=p[i];
				a[0]=en;
				return a;
			}
		} else throw new NotProductException();
	}

	public Object[] powerValue() throws NotPowerException {
		int n=content.size();
		if(n==0) return new Object[] {JSCLInteger.valueOf(0),new Integer(1)};
		else if(n==1) {
			Map.Entry e=(Map.Entry)content.entrySet().iterator().next();
			Literal l=(Literal)e.getKey();
			JSCLInteger en=(JSCLInteger)e.getValue();
			if(en.compareTo(JSCLInteger.valueOf(1))==0) return l.powerValue();
			else if(l.degree()==0) return en.powerValue();
			else throw new NotPowerException();
		} else throw new NotPowerException();
	}

	public JSCLInteger integerValue() throws NotIntegerException {
		int n=content.size();
		if(n==0) return JSCLInteger.valueOf(0);
		else if(n==1) {
			Map.Entry e=(Map.Entry)content.entrySet().iterator().next();
			Literal l=(Literal)e.getKey();
			JSCLInteger en=(JSCLInteger)e.getValue();
			if(l.degree()==0) return en;
			else throw new NotIntegerException();
		} else throw new NotIntegerException();
	}

	public Variable variableValue() throws NotVariableException {
		int n=content.size();
		if(n==0) throw new NotVariableException();
		else if(n==1) {
			Map.Entry e=(Map.Entry)content.entrySet().iterator().next();
			Literal l=(Literal)e.getKey();
			JSCLInteger en=(JSCLInteger)e.getValue();
			if(en.compareTo(JSCLInteger.valueOf(1))==0) return l.variableValue();
			else throw new NotVariableException();
		} else throw new NotVariableException();
	}

	public boolean isPolynomial(Variable variable) {
		boolean s=true;
		Literal l=variables();
		Iterator it=l.content.keySet().iterator();
		while(it.hasNext()) {
			Variable v=(Variable)it.next();
			s=s && (v.isConstant(variable) || v.isIdentity(variable));
		}
		return s;
	}

	public boolean isConstant(Variable variable) {
		boolean s=true;
		Literal l=variables();
		Iterator it=l.content.keySet().iterator();
		while(it.hasNext()) {
			Variable v=(Variable)it.next();
			s=s && v.isConstant(variable);
		}
		return s;
	}

	public Arithmetic grad(Variable variable[]) {
		JSCLVector v=new JSCLVector(new Arithmetic[variable.length]);
		for(int i=0;i<variable.length;i++) v.element[i]=derivative(variable[i]);
		return v;
	}

	Literal variables() {
		Literal l=new Literal();
		for(Iterator it=content.keySet().iterator();it.hasNext();) {
			l=l.scm((Literal)it.next());
		}
		return l;
	}

	public int compareTo(Object comparable) {
		if(comparable instanceof Expression) {
			Expression ex=(Expression)comparable;
			Iterator it1=content.entrySet().iterator(true);
			Iterator it2=ex.content.entrySet().iterator(true);
			while(true) {
				boolean b1=!it1.hasNext();
				boolean b2=!it2.hasNext();
				if(b1 && b2) return 0;
				else if(b1) return -1;
				else if(b2) return 1;
				else {
					Map.Entry e1=(Map.Entry)it1.next();
					Map.Entry e2=(Map.Entry)it2.next();
					Literal l1=(Literal)e1.getKey();
					Literal l2=(Literal)e2.getKey();
					int c=l1.compareTo(l2);
					if(c<0) return -1;
					else if(c>0) return 1;
					else {
						JSCLInteger en1=(JSCLInteger)e1.getValue();
						JSCLInteger en2=(JSCLInteger)e2.getValue();
						c=en1.compareTo(en2);
						if(c<0) return -1;
						else if(c>0) return 1;
					}
				}
			}
		} else if(comparable instanceof JSCLInteger) {
			return compareTo(valueof((JSCLInteger)comparable));
		} else {
			return ((Arithmetic)comparable).valueof(this).compareTo(comparable);
		}
	}

	public static Expression valueOf(Arithmetic arithmetic) {
		Expression ex=new Expression();
		ex.put(arithmetic);
		return ex;
	}

	public static Expression valueOf(Variable variable) {
		Expression ex=new Expression();
		Literal l=new Literal();
		l.put(variable,new Integer(1));
		ex.put(l,JSCLInteger.valueOf(1));
		return ex;
	}

	public static Expression valueOf(String str) throws ParseException {
		Expression ex=new Expression();
		Arithmetic a=(Arithmetic)UserInput.parser.parse(str,new int[1]);
		ex.put(a);
		return ex;
	}

	void put(Arithmetic arithmetic) {
		if(arithmetic instanceof Expression) {
			Expression ex=(Expression)arithmetic;
			Iterator it=ex.content.entrySet().iterator();
			while(it.hasNext()) {
				Map.Entry e=(Map.Entry)it.next();
				put(
					(Literal)e.getKey(),
					(JSCLInteger)e.getValue()
				);
			}
		} else if(arithmetic instanceof JSCLInteger) {
			JSCLInteger en=(JSCLInteger)arithmetic;
			put(new Literal(),en);
		} else if(arithmetic instanceof FactorizedExpression) {
			FactorizedExpression f=(FactorizedExpression)arithmetic;
			put(f.unfactorize());
		} else if(arithmetic instanceof Polynomial) {
			Polynomial p=(Polynomial)arithmetic;
			Iterator it=p.content.entrySet().iterator();
			while(it.hasNext()) {
				Map.Entry e=(Map.Entry)it.next();
				Monomial m=(Monomial)e.getKey();
				Arithmetic a=(Arithmetic)e.getValue();
				if(p.modulo>0) a=Polynomial.unmodulo(a);
				Expression ex=new Expression();
				ex.put(Literal.valueOf(m),JSCLInteger.valueOf(1));
				put(ex.multiply(a));
			}
		} else {}
	}

	void put(Literal literal, JSCLInteger integer) {
		Object o=content.get(literal);
		if(o!=null) {
			integer=(JSCLInteger)integer.add((JSCLInteger)o);
			if(integer.signum()==0) content.remove(literal);
			else content.put(literal,integer);
		} else {
			if(integer.signum()==0);
			else content.put(literal,integer);
		}
	}

	public String toString() {
		StringBuffer buffer=new StringBuffer();
		if(signum()==0) buffer.append("0");
		Iterator it=content.entrySet().iterator();
		for(int i=0;it.hasNext();i++) {
			Map.Entry e=(Map.Entry)it.next();
			Literal l=(Literal)e.getKey();
			JSCLInteger en=(JSCLInteger)e.getValue();
			if(en.signum()==1 && i>0) buffer.append("+");
			if(l.degree()==0) buffer.append(en);
			else {
				if(en.compareTo(JSCLInteger.valueOf(1))==0);
				else if(en.compareTo(JSCLInteger.valueOf(-1))==0) buffer.append("-");
				else buffer.append(en).append("*");
				buffer.append(l);
			}
		}
		return buffer.toString();
	}

	public String toMathML(Object data) {
		IndentedBuffer buffer=new IndentedBuffer();
		buffer.append("<mrow>\n");
		if(signum()==0) buffer.append(1,"<mn>0</mn>\n");
		Iterator it=content.entrySet().iterator();
		for(int i=0;it.hasNext();i++) {
			Map.Entry e=(Map.Entry)it.next();
			Literal l=(Literal)e.getKey();
			JSCLInteger en=(JSCLInteger)e.getValue();
			if(en.signum()==1 && i>0) buffer.append(1,"<mo>+</mo>\n");
			if(l.degree()==0) buffer.append(1,separateSign(en));
			else {
				if(en.compareTo(JSCLInteger.valueOf(1))==0);
				else if(en.compareTo(JSCLInteger.valueOf(-1))==0) buffer.append(1,"<mo>-</mo>\n");
				else buffer.append(1,separateSign(en));
				buffer.append(1,l.toMathML(null));
			}
		}
		buffer.append("</mrow>\n");
		return buffer.toString();
	}

	static String separateSign(Arithmetic arithmetic) {
		IndentedBuffer buffer=new IndentedBuffer();
		if(arithmetic.signum()==-1) {
			buffer.append("<mo>-</mo>\n");
			buffer.append(arithmetic.negate().toMathML(null));
		} else buffer.append(arithmetic.toMathML(null));
		return buffer.toString();
	}

	protected Arithmetic newinstance() {
		return new Expression();
	}
}

class CommaAndExpression extends Parser {
	public static final Parser parser=new CommaAndExpression();

	private CommaAndExpression() {}

	public Object parse(String str, int pos[]) throws ParseException {
		int pos0=pos[0];
		Arithmetic a;
		skipWhitespaces(str,pos);
		if(pos[0]<str.length() && str.charAt(pos[0])==',') {
			str.charAt(pos[0]++);
		} else {
			pos[0]=pos0;
			throw new ParseException();
		}
		try {
			a=(Arithmetic)ExpressionParser.parser.parse(str,pos);
		} catch (ParseException e) {
			pos[0]=pos0;
			throw e;
		}
		return a;
	}
}

class UserInput extends Parser {
	public static final Parser parser=new UserInput();

	private UserInput() {}

	public Object parse(String str, int pos[]) throws ParseException {
		Arithmetic a;
		try {
			a=(Arithmetic)ExpressionParser.parser.parse(str,pos);
		} catch (ParseException e) {
			throw e;
		}
		skipWhitespaces(str,pos);
		if(pos[0]<str.length()) {
			throw new ParseException();
		}
		return a;
	}
}

class UserInputWithEqual extends Parser {
	public static final Parser parser=new UserInputWithEqual();

	private UserInputWithEqual() {}

	public Object parse(String str, int pos[]) throws ParseException {
		Arithmetic a;
		boolean equal=false;
		try {
			a=(Arithmetic)ExpressionParser.parser.parse(str,pos);
		} catch (ParseException e) {
			throw e;
		}
		try {
			EqualParser.parser.parse(str,pos);
			equal=true;
		} catch (ParseException e) {}
		skipWhitespaces(str,pos);
		if(pos[0]<str.length()) {
			throw new ParseException();
		}
		return new Object[] {a,new Boolean(equal)};
	}
}

class EqualParser extends Parser {
	public static final Parser parser=new EqualParser();

	private EqualParser() {}

	public Object parse(String str, int pos[]) throws ParseException {
		int pos0=pos[0];
		skipWhitespaces(str,pos);
		if(pos[0]<str.length() && str.charAt(pos[0])=='=') {
			str.charAt(pos[0]++);
		} else {
			pos[0]=pos0;
			throw new ParseException();
		}
		return null;
	}
}

class ExpressionParser extends Parser {
	public static final Parser parser=new ExpressionParser();

	private ExpressionParser() {}

	public Object parse(String str, int pos[]) throws ParseException {
		Arithmetic a;
		boolean sign=false;
		try {
			MinusParser.parser.parse(str,pos);
			sign=true;
		} catch (ParseException e) {}
		try {
			a=(Arithmetic)Term.parser.parse(str,pos);
		} catch (ParseException e) {
			throw e;
		}
		if(sign) a=a.negate();
		while(true) {
			try {
				Arithmetic a2=(Arithmetic)PlusOrMinusTerm.parser.parse(str,pos);
				a=a.add(a2);
			} catch (ParseException e) {
				break;
			}
		}
		return a;
	}
}

class MinusParser extends Parser {
	public static final Parser parser=new MinusParser();

	private MinusParser() {}

	public Object parse(String str, int pos[]) throws ParseException {
		int pos0=pos[0];
		skipWhitespaces(str,pos);
		if(pos[0]<str.length() && str.charAt(pos[0])=='-') {
			str.charAt(pos[0]++);
		} else {
			pos[0]=pos0;
			throw new ParseException();
		}
		return null;
	}
}

class PlusOrMinusTerm extends Parser {
	public static final Parser parser=new PlusOrMinusTerm();

	private PlusOrMinusTerm() {}

	public Object parse(String str, int pos[]) throws ParseException {
		int pos0=pos[0];
		boolean sign;
		Arithmetic a;
		skipWhitespaces(str,pos);
		if(pos[0]<str.length() && (str.charAt(pos[0])=='+' || str.charAt(pos[0])=='-')) {
			sign=str.charAt(pos[0]++)=='-';
		} else {
			pos[0]=pos0;
			throw new ParseException();
		}
		try {
			a=(Arithmetic)Term.parser.parse(str,pos);
		} catch (ParseException e) {
			pos[0]=pos0;
			throw e;
		}
		return sign?a.negate():a;
	}
}

class Term extends Parser {
	public static final Parser parser=new Term();

	private Term() {}

	public Object parse(String str, int pos[]) throws ParseException {
		Arithmetic a=JSCLInteger.valueOf(1);
		Arithmetic s;
		try {
			s=(Arithmetic)UnsignedFactor.parser.parse(str,pos);
		} catch (ParseException e) {
			throw e;
		}
		while(true) {
			try {
				Arithmetic a2=(Arithmetic)MultiplyOrDivideFactor.multiply.parse(str,pos);
				a=a.multiply(s);
				s=a2;
			} catch (ParseException e) {
				try {
					Arithmetic a2=(Arithmetic)MultiplyOrDivideFactor.divide.parse(str,pos);
					if(s.compareTo(JSCLInteger.valueOf(1))==0) s=new Inv(ExpressionVariable.content(a2)).expressionValue();
					else s=new Frac(ExpressionVariable.content(s),ExpressionVariable.content(a2)).expressionValue();
				} catch (ParseException e2) {
					break;
				}
			}
		}
		a=a.multiply(s);
		return a;
	}
}

class MultiplyOrDivideFactor extends Parser {
	public static final Parser multiply=new MultiplyOrDivideFactor(true);
	public static final Parser divide=new MultiplyOrDivideFactor(false);
	boolean option;

	private MultiplyOrDivideFactor(boolean option) {
		this.option=option;
	}

	public Object parse(String str, int pos[]) throws ParseException {
		int pos0=pos[0];
		Arithmetic a;
		skipWhitespaces(str,pos);
		if(pos[0]<str.length() && str.charAt(pos[0])==(option?'*':'/')) {
			str.charAt(pos[0]++);
		} else {
			pos[0]=pos0;
			throw new ParseException();
		}
		try {
			a=(Arithmetic)Factor.parser.parse(str,pos);
		} catch (ParseException e) {
			pos[0]=pos0;
			throw e;
		}
		return a;
	}
}

class Factor extends Parser {
	public static final Parser parser=new Factor();

	private Factor() {}

	public Object parse(String str, int pos[]) throws ParseException {
		Arithmetic a;
		boolean sign=false;
		try {
			MinusParser.parser.parse(str,pos);
			sign=true;
		} catch (ParseException e) {}
		try {
			a=(Arithmetic)UnsignedFactor.parser.parse(str,pos);
		} catch (ParseException e) {
			throw e;
		}
		return sign?a.negate():a;
	}
}

class UnsignedFactor extends Parser {
	public static final Parser parser=new UnsignedFactor();

	private UnsignedFactor() {}

	public Object parse(String str, int pos[]) throws ParseException {
		Arithmetic a;
		try {
			a=(Arithmetic)UnsignedExponent.parser.parse(str,pos);
		} catch (ParseException e) {
			throw e;
		}
		while(true) {
			try {
				Arithmetic a2=(Arithmetic)PowerExponent.parser.parse(str,pos);
				try {
					int c=a2.integerValue().intValue();
					if(c<0) a=new Pow(ExpressionVariable.content(a),JSCLInteger.valueOf(c)).expressionValue();
					else a=a.pow(c);
				} catch (NotIntegerException e) {
					a=new Pow(ExpressionVariable.content(a),ExpressionVariable.content(a2)).expressionValue();
				}
			} catch (ParseException e) {
				break;
			}
		}
		return a;
	}
}

class PowerExponent extends Parser {
	public static final Parser parser=new PowerExponent();

	private PowerExponent() {}

	public Object parse(String str, int pos[]) throws ParseException {
		int pos0=pos[0];
		Arithmetic a;
		try {
			PowerParser.parser.parse(str,pos);
		} catch (ParseException e) {
			pos[0]=pos0;
			throw e;
		}
		try {
			a=(Arithmetic)Exponent.parser.parse(str,pos);
		} catch (ParseException e) {
			pos[0]=pos0;
			throw e;
		}
		return a;
	}
}

class PowerParser extends Parser {
	public static final Parser parser=new PowerParser();

	private PowerParser() {}

	public Object parse(String str, int pos[]) throws ParseException {
		int pos0=pos[0];
		skipWhitespaces(str,pos);
		if(pos[0]<str.length() && str.charAt(pos[0])=='^') {
			str.charAt(pos[0]++);
		} else {
			if(pos[0]+1<str.length() && str.charAt(pos[0])=='*' && str.charAt(pos[0]+1)=='*') {
				str.charAt(pos[0]++);
				str.charAt(pos[0]++);
			} else {
				pos[0]=pos0;
				throw new ParseException();
			}
		}
		return null;
	}
}

class Exponent extends Parser {
	public static final Parser parser=new Exponent();

	private Exponent() {}

	public Object parse(String str, int pos[]) throws ParseException {
		int pos0=pos[0];
		Arithmetic a;
		boolean sign=false;
		try {
			MinusParser.parser.parse(str,pos);
			sign=true;
		} catch (ParseException e) {}
		try {
			a=(Arithmetic)UnsignedExponent.parser.parse(str,pos);
		} catch (ParseException e) {
			pos[0]=pos0;
			throw e;
		}
		return sign?a.negate():a;
	}
}

class UnsignedExponent extends Parser {
	public static final Parser parser=new UnsignedExponent();

	private UnsignedExponent() {}

	public Object parse(String str, int pos[]) throws ParseException {
		int pos0=pos[0];
		Arithmetic a;
		boolean factorial=false;
		try {
			a=(Arithmetic)PrimaryExpression.parser.parse(str,pos);
		} catch (ParseException e) {
			pos[0]=pos0;
			throw e;
		}
		try {
			FactorialParser.parser.parse(str,pos);
			factorial=true;
		} catch (ParseException e) {}
		return factorial?new Factorial(ExpressionVariable.content(a)).expressionValue():a;
	}
}

class FactorialParser extends Parser {
	public static final Parser parser=new FactorialParser();

	private FactorialParser() {}

	public Object parse(String str, int pos[]) throws ParseException {
		int pos0=pos[0];
		skipWhitespaces(str,pos);
		if(pos[0]<str.length() && str.charAt(pos[0])=='!') {
			str.charAt(pos[0]++);
		} else {
			pos[0]=pos0;
			throw new ParseException();
		}
		return null;
	}
}

class PrimaryExpression extends Parser {
	public static final Parser parser=new PrimaryExpression();

	private PrimaryExpression() {}

	public Object parse(String str, int pos[]) throws ParseException {
		Arithmetic a;
		try {
			a=(Arithmetic)JSCLInteger.parser.parse(str,pos);
		} catch (ParseException e) {
			try {
				a=((Variable)Variable.parser.parse(str,pos)).expressionValue();
			} catch (ParseException e2) {
				throw e2;
			}
		}
		return a;
	}
}
