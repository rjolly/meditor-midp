package jscl.math;

import jscl.util.*;

public abstract class Arithmetic implements jscl.util.Comparable {
	Arithmetic() {}

	public abstract Arithmetic add(Arithmetic arithmetic);

	public Arithmetic subtract(Arithmetic arithmetic) {
		return add(arithmetic.negate());
	}

	public abstract Arithmetic multiply(Arithmetic arithmetic);
	public abstract Arithmetic divide(Arithmetic arithmetic) throws ArithmeticException;

	public Arithmetic remainder(Arithmetic arithmetic) throws ArithmeticException {
		return divideAndRemainder(arithmetic)[1];
	}

	public abstract Arithmetic[] divideAndRemainder(Arithmetic arithmetic) throws ArithmeticException;
	public abstract Arithmetic gcd(Arithmetic arithmetic);

	public Arithmetic scm(Arithmetic arithmetic) {
		return multiply(arithmetic).divide(gcd(arithmetic));
	}

	public abstract Arithmetic gcd();

	public Arithmetic normalize() {
		return gcdAndNormalize()[1];
	}

	public Arithmetic[] gcdAndNormalize() {
		Arithmetic gcd=gcd();
		if(gcd.signum()==0) return new Arithmetic[] {gcd,this};
		if(gcd.signum()!=signum()) gcd=gcd.negate();
		return new Arithmetic[] {gcd,divide(gcd)};
	}

	public Arithmetic pow(int exponent) {
		Arithmetic a=JSCLInteger.valueOf(1);
		for(int i=0;i<exponent;i++) a=a.multiply(this);
		return a;
	}

	public Arithmetic abs() {
		return signum()<0?negate():this;
	}

	public abstract Arithmetic negate();
	public abstract int signum();
	public abstract int degree();
//	public abstract Arithmetic mod(Arithmetic arithmetic);
//	public abstract Arithmetic modPow(Arithmetic arithmetic, Arithmetic arithmetic);
//	public abstract Arithmetic modInverse(Arithmetic arithmetic);
//	public abstract boolean isProbablePrime(int certainty);
	public abstract Arithmetic antiderivative(Variable variable) throws NotIntegrableException;
	public abstract Arithmetic derivative(Variable variable);
	public abstract Arithmetic substitute(Variable variable, Arithmetic arithmetic);
	public abstract Arithmetic expand();
	public abstract Factorized factorize();
	public abstract Arithmetic elementary();
	public abstract Arithmetic simplify();
	public abstract Arithmetic valueof(Arithmetic arithmetic);
	public abstract Arithmetic[] sumValue();
	public abstract Arithmetic[] productValue() throws NotProductException;
	public abstract Object[] powerValue() throws NotPowerException;
	public abstract JSCLInteger integerValue() throws NotIntegerException;
	public abstract Variable variableValue() throws NotVariableException;
	public abstract boolean isPolynomial(Variable variable);
	public abstract boolean isConstant(Variable variable);

	public boolean isIdentity(Variable variable) {
		try {
			return variableValue().isIdentity(variable);
		} catch (NotVariableException e) {
			return false;
		}
	}

	public boolean equals(Object obj) {
		if(obj instanceof Arithmetic) {
			return compareTo((Arithmetic)obj)==0;
		} else return false;
	}

	public abstract String toMathML(Object data);
	protected abstract Arithmetic newinstance();
}
