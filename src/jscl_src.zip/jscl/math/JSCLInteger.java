package jscl.math;

import java.math.*;
import jscl.text.*;

public class JSCLInteger extends Arithmetic {
	public static final Parser parser=JSCLIntegerParser.parser;
	BigInteger content;

	JSCLInteger() {}

	public Arithmetic add(Arithmetic arithmetic) {
		if(arithmetic instanceof JSCLInteger) {
			JSCLInteger e=(JSCLInteger)newinstance();
			e.put(content.add(((JSCLInteger)arithmetic).content));
			return e;
		} else {
			return arithmetic.valueof(this).add(arithmetic);
		}
	}

	public Arithmetic subtract(Arithmetic arithmetic) {
		if(arithmetic instanceof JSCLInteger) {
			JSCLInteger e=(JSCLInteger)newinstance();
			e.put(content.subtract(((JSCLInteger)arithmetic).content));
			return e;
		} else {
			return arithmetic.valueof(this).subtract(arithmetic);
		}
	}

	public Arithmetic multiply(Arithmetic arithmetic) {
		if(arithmetic instanceof JSCLInteger) {
			JSCLInteger e=(JSCLInteger)newinstance();
			e.put(content.multiply(((JSCLInteger)arithmetic).content));
			return e;
		} else {
			return arithmetic.multiply(this);
		}
	}

	public Arithmetic divide(Arithmetic arithmetic) throws ArithmeticException {
		if(arithmetic instanceof JSCLInteger) {
			JSCLInteger e[]=(JSCLInteger[])divideAndRemainder(arithmetic);
			if(e[1].signum()==0) return e[0];
			else throw new NotDivisibleException();
		} else {
			return arithmetic.valueof(this).divide(arithmetic);
		}
	}

	public Arithmetic remainder(Arithmetic arithmetic) throws ArithmeticException {
		if(arithmetic instanceof JSCLInteger) {
			JSCLInteger e=(JSCLInteger)newinstance();
			e.put(content.remainder(((JSCLInteger)arithmetic).content));
			return e;
		} else {
			return arithmetic.valueof(this).remainder(arithmetic);
		}
	}

	public Arithmetic[] divideAndRemainder(Arithmetic arithmetic) throws ArithmeticException {
		if(arithmetic instanceof JSCLInteger) {
			JSCLInteger e[]={(JSCLInteger)newinstance(),(JSCLInteger)newinstance()};
			BigInteger b[]=content.divideAndRemainder(((JSCLInteger)arithmetic).content);
			e[0].put(b[0]);
			e[1].put(b[1]);
			return e;
		} else {
			return arithmetic.valueof(this).divideAndRemainder(arithmetic);
		}
	}

	public Arithmetic gcd(Arithmetic arithmetic) {
		if(arithmetic instanceof JSCLInteger) {
			JSCLInteger e=(JSCLInteger)newinstance();
			e.put(content.gcd(((JSCLInteger)arithmetic).content));
			return e;
		} else {
			return arithmetic.valueof(this).gcd(arithmetic);
		}
	}

	public Arithmetic gcd() {
		JSCLInteger e=(JSCLInteger)newinstance();
		e.put(BigInteger.valueOf(signum()));
		return e;
	}

	public Arithmetic pow(int exponent) {
		JSCLInteger e=(JSCLInteger)newinstance();
		e.put(content.pow(exponent));
		return e;
	}

	public Arithmetic negate() {
		JSCLInteger e=(JSCLInteger)newinstance();
		e.put(content.negate());
		return e;
	}

	public int signum() {
		return content.signum();
	}

	public int degree() {
		return 0;
	}

	public Arithmetic modInverse(Arithmetic arithmetic) {
		JSCLInteger e=(JSCLInteger)newinstance();
		e.put(content.modInverse(((JSCLInteger)arithmetic).content));
		return e;
	}

	public Arithmetic antiderivative(Variable variable) throws NotIntegrableException {
		return multiply(variable.expressionValue());
	}

	public Arithmetic derivative(Variable variable) {
		JSCLInteger e=(JSCLInteger)newinstance();
		e.put(BigInteger.valueOf(0));
		return e;
	}

	public Arithmetic substitute(Variable variable, Arithmetic arithmetic) {
		return this;
	}

	public Arithmetic expand() {
		return this;
	}

	public Arithmetic factorize() {
		Factorization s=new Factorization();
		s.compute(this);
		return s.getValue();
	}

	public Arithmetic elementary() {
		return this;
	}

	public Arithmetic simplify() {
		return this;
	}

	public Arithmetic valueof(Arithmetic arithmetic) {
		JSCLInteger e=(JSCLInteger)newinstance();
		e.put(arithmetic);
		return e;
	}

	public Arithmetic[] sumValue() {
		if(content.signum()==0) return new Arithmetic[0];
		else return new Arithmetic[] {this};
	}

	public Arithmetic[] productValue() throws NotProductException {
		if(content.compareTo(BigInteger.valueOf(1))==0) return new Arithmetic[0];
		else return new Arithmetic[] {this};
	}

	public Object[] powerValue() throws NotPowerException {
		if(content.signum()<0) throw new NotPowerException();
		else return new Object[] {this,new Integer(1)};
	}

	public JSCLInteger integerValue() throws NotIntegerException {
		return this;
	}

	public Variable variableValue() throws NotVariableException {
		throw new NotVariableException();
	}

	public boolean isPolynomial(Variable variable) {
		return true;
	}

	public boolean isConstant(Variable variable) {
		return true;
	}

	public int intValue() {
		return content.intValue();
	}

	public int compareTo(Object comparable) {
		if(comparable instanceof JSCLInteger) {
			JSCLInteger e=(JSCLInteger)comparable;
			return content.compareTo(e.content);
		} else {
			return ((Arithmetic)comparable).valueof(this).compareTo(comparable);
		}
	}

	public static JSCLInteger valueOf(long val) {
		JSCLInteger e=new JSCLInteger();
		e.put(BigInteger.valueOf(val));
		return e;
	}

	public static JSCLInteger valueOf(String str) {
		JSCLInteger e=new JSCLInteger();
		e.put(new BigInteger(str));
		return e;
	}

	void put(Arithmetic arithmetic) {
		JSCLInteger e=(JSCLInteger)arithmetic;
		put(e.content);
	}

	void put(BigInteger b) {
		content=b;
	}

	public String toString() {
		return content.toString();
	}

	public String toMathML(Object data) {
		IndentedBuffer buffer=new IndentedBuffer();
		int exponent=data instanceof Integer?((Integer)data).intValue():1;
		if(exponent==1) {
			buffer.append(bodyToMathML());
		} else {
			buffer.append("<msup>\n");
			buffer.append(1,bodyToMathML());
			buffer.append(1,"<mn>").append(exponent).append("</mn>\n");
			buffer.append("</msup>\n");
		}
		return buffer.toString();
	}

	public String bodyToMathML() {
		IndentedBuffer buffer=new IndentedBuffer();
		buffer.append("<mn>").append(content).append("</mn>\n");
		return buffer.toString();
	}

	protected Arithmetic newinstance() {
		return new JSCLInteger();
	}
}

class JSCLIntegerParser extends Parser {
	public static final Parser parser=new JSCLIntegerParser();

	private JSCLIntegerParser() {}

	public Object parse(String str, int pos[]) throws ParseException {
		int pos0=pos[0];
		StringBuffer buffer=new StringBuffer();
		skipWhitespaces(str,pos);
		if(pos[0]<str.length() && Character.isDigit(str.charAt(pos[0]))) {
			char c=str.charAt(pos[0]++);
			buffer.append(c);
		} else {
			pos[0]=pos0;
			throw new ParseException();
		}
		while(pos[0]<str.length() && Character.isDigit(str.charAt(pos[0]))) {
			char c=str.charAt(pos[0]++);
			buffer.append(c);
		}
		JSCLInteger e=new JSCLInteger();
		e.put(new BigInteger(buffer.toString()));
		return e;
	}
}
