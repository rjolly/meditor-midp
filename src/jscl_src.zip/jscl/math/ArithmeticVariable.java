package jscl.math;

public abstract class ArithmeticVariable extends Variable {
	Arithmetic content;

	public ArithmeticVariable(Arithmetic arithmetic) {
		super("");
		content=arithmetic;
	}

	public static Arithmetic content(Arithmetic arithmetic) {
		try {
			Variable v=arithmetic.variableValue();
			if(v instanceof ArithmeticVariable) arithmetic=((ArithmeticVariable)v).content;
		} catch (NotVariableException e) {}
		return arithmetic;
	}

	public Arithmetic antiderivative(Variable variable) throws NotIntegrableException {
		return content.antiderivative(variable);
	}

	public Arithmetic derivative(Variable variable) {
		return content.derivative(variable);
	}

	public Arithmetic substitute(Variable variable, Arithmetic arithmetic) {
		return content.substitute(variable,arithmetic);
	}

	public Arithmetic expand() {
		return content.expand();
	}

	public Arithmetic factorize() {
		ArithmeticVariable v=(ArithmeticVariable)newinstance();
		v.content=content.factorize();
		return v.expressionValue();
	}

	public Arithmetic elementary() {
		ArithmeticVariable v=(ArithmeticVariable)newinstance();
		v.content=content.elementary();
		return v.expressionValue();
	}

	public Arithmetic simplify() {
		ArithmeticVariable v=(ArithmeticVariable)newinstance();
		v.content=content.simplify();
		return v.expressionValue();
	}

	public Arithmetic numeric() {
		return content.numeric();
	}

	public boolean isConstant(Variable variable) {
		return content.isConstant(variable);
	}

	public int compareTo(Object comparable) {
		if(this==comparable) return 0;
		int c=comparator.compare(this,comparable);
		if(c<0) return -1;
		else if(c>0) return 1;
		else {
			ArithmeticVariable v=(ArithmeticVariable)comparable;
			return content.compareTo(v.content);
		}
	}

	public String toString() {
		return content.toString();
	}

	public String toJava() {
		return content.toJava();
	}

	public String toMathML(Object data) {
		return content.toMathML(data);
	}
}
