package jscl.math;

public abstract class ArithmeticVariable extends Variable {
	public Arithmetic content;

	public ArithmeticVariable(Arithmetic arithmetic) {
		super("");
		content=arithmetic;
	}

	public Arithmetic antiderivative(Variable variable) throws NotIntegrableException {
		return content.antiderivative(variable);
	}

	public Arithmetic derivative(Variable variable) {
		return content.derivative(variable);
	}

	public Arithmetic substitute(Variable variable, Arithmetic arithmetic) {
		return content.substitute(variable,arithmetic);
	}

	public Arithmetic expand() {
		return content.expand();
	}

	public Arithmetic factorize() {
		ArithmeticVariable v=(ArithmeticVariable)newinstance();
		v.content=content.factorize();
		return v.expressionValue();
	}

	public boolean isConstant(Variable variable) {
		return content.isConstant(variable);
	}

	public int compareTo(Object comparable) {
		if(this==comparable) return 0;
		int c=comparator.compare(this,comparable);
		if(c<0) return -1;
		else if(c>0) return 1;
		else {
			ArithmeticVariable v=(ArithmeticVariable)comparable;
			return content.compareTo(v.content);
		}
	}
}
