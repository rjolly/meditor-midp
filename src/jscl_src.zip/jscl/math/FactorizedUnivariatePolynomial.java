package jscl.math;

import java.util.*;

public class FactorizedUnivariatePolynomial extends Factorized {
	final Variable unknown[];

	FactorizedUnivariatePolynomial(Variable var) {
		unknown=new Variable[] {var};
	}

	public Arithmetic[] identification(Arithmetic arithmetic) {
		return null;
	}

	public Arithmetic resultant(Arithmetic arithmetic) {
		FactorizedUnivariatePolynomial f=(FactorizedUnivariatePolynomial)arithmetic;
		Arithmetic a=JSCLInteger.valueOf(1);
		Enumeration k1=content.keys();
		Enumeration e1=content.elements();
		while(k1.hasMoreElements()) {
			UnivariatePolynomial p1=(UnivariatePolynomial)k1.nextElement();
			int c1=((Integer)e1.nextElement()).intValue();
			Enumeration k2=f.content.keys();
			Enumeration e2=f.content.elements();
			while(k2.hasMoreElements()) {
				UnivariatePolynomial p2=(UnivariatePolynomial)k2.nextElement();
				int c2=((Integer)e2.nextElement()).intValue();
				a=a.multiply(p1.resultant(p2).factorize().pow(c1*c2));
			}
		}
		return a;
	}

	public Arithmetic squarefree() {
		return divide(gcd(derivative()));
	}

	public Arithmetic derivative() {
		if(content.isEmpty()) return valueof(JSCLInteger.valueOf(0));
		else {
			Enumeration k=content.keys();
			Enumeration e=content.elements();
			UnivariatePolynomial p=(UnivariatePolynomial)k.nextElement();
			int c=((Integer)e.nextElement()).intValue();
			Arithmetic a1=valueof(p).pow(c).multiply(coefficient);
			Arithmetic a1_=valueof(p).pow(c-1).multiply(p.derivative().factorize()).multiply(coefficient.multiply(JSCLInteger.valueOf(c)));
			Arithmetic a2=valueof(JSCLInteger.valueOf(1));
			while(k.hasMoreElements()) {
				p=(UnivariatePolynomial)k.nextElement();
				c=((Integer)e.nextElement()).intValue();
				a2=a2.multiply(valueof(p).pow(c));
			}
			Arithmetic a2_=((FactorizedUnivariatePolynomial)a2).derivative();
			return a1_.multiply(a2).add(a1.multiply(a2_));
		}
	}

	public static FactorizedUnivariatePolynomial valueOf(Arithmetic arithmetic, Variable var) {
		FactorizedUnivariatePolynomial f=new FactorizedUnivariatePolynomial(var);
		f.put(arithmetic);
		return f;
	}

	void put(Arithmetic arithmetic) {
		if(arithmetic instanceof Expression || arithmetic instanceof JSCLInteger) {
			put(UnivariatePolynomial.valueOf(arithmetic,unknown[0]));
		} else if(arithmetic instanceof FactorizedExpression) {
			FactorizedExpression f=(FactorizedExpression)arithmetic;
			Enumeration k=f.content.keys();
			Enumeration e=f.content.elements();
			while(k.hasMoreElements()) {
				put(
					valueof(
						(Expression)k.nextElement()
					).pow(
						((Integer)e.nextElement()).intValue()
					)
				);
			}
			coefficient=coefficient.multiply(f.coefficient);
		} else super.put(arithmetic);
	}

	protected Arithmetic newinstance() {
		return new FactorizedUnivariatePolynomial(unknown[0]);
	}
}
