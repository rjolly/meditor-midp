package jscl.math;

import java.util.*;

public class FactorizedUnivariatePolynomial extends Factorized {
	final Variable unknown[];

	FactorizedUnivariatePolynomial(Variable var) {
		unknown=new Variable[] {var};
	}

	public Arithmetic[] identification(Arithmetic arithmetic) {
		return null;
	}

	public Arithmetic resultant(Arithmetic arithmetic) {
		FactorizedUnivariatePolynomial f=(FactorizedUnivariatePolynomial)arithmetic;
		Arithmetic a=JSCLInteger.valueOf(1);
		Iterator it1=content.entrySet().iterator();
		while(it1.hasNext()) {
			Map.Entry e1=(Map.Entry)it1.next();
			UnivariatePolynomial p1=(UnivariatePolynomial)e1.getKey();
			int c1=((Integer)e1.getValue()).intValue();
			Iterator it2=f.content.entrySet().iterator();
			while(it2.hasNext()) {
				Map.Entry e2=(Map.Entry)it2.next();
				UnivariatePolynomial p2=(UnivariatePolynomial)e2.getKey();
				int c2=((Integer)e2.getValue()).intValue();
				a=a.multiply(p1.resultant(p2).factorize().pow(c1*c2));
			}
		}
		return a;
	}

	public Arithmetic squarefree() {
		return divide(gcd(derivative()));
	}

	public Arithmetic derivative() {
		if(content.isEmpty()) return valueof(JSCLInteger.valueOf(0));
		else {
			Iterator it=content.entrySet().iterator();
			Map.Entry e=(Map.Entry)it.next();
			UnivariatePolynomial p=(UnivariatePolynomial)e.getKey();
			int c=((Integer)e.getValue()).intValue();
			Arithmetic a1=valueof(p).pow(c).multiply(coefficient);
			Arithmetic a1_=valueof(p).pow(c-1).multiply(p.derivative().factorize()).multiply(coefficient.multiply(JSCLInteger.valueOf(c)));
			Arithmetic a2=valueof(JSCLInteger.valueOf(1));
			while(it.hasNext()) {
				e=(Map.Entry)it.next();
				p=(UnivariatePolynomial)e.getKey();
				c=((Integer)e.getValue()).intValue();
				a2=a2.multiply(valueof(p).pow(c));
			}
			Arithmetic a2_=((FactorizedUnivariatePolynomial)a2).derivative();
			return a1_.multiply(a2).add(a1.multiply(a2_));
		}
	}

	public static FactorizedUnivariatePolynomial valueOf(Arithmetic arithmetic, Variable var) {
		FactorizedUnivariatePolynomial f=new FactorizedUnivariatePolynomial(var);
		f.put(arithmetic);
		return f;
	}

	void put(Arithmetic arithmetic) {
		if(arithmetic instanceof Expression || arithmetic instanceof JSCLInteger) {
			put(UnivariatePolynomial.valueOf(arithmetic,unknown[0]));
		} else if(arithmetic instanceof FactorizedExpression) {
			FactorizedExpression f=(FactorizedExpression)arithmetic;
			Iterator it=f.content.entrySet().iterator();
			while(it.hasNext()) {
				Map.Entry e=(Map.Entry)it.next();
				put(
					valueof(
						(Expression)e.getKey()
					).pow(
						((Integer)e.getValue()).intValue()
					)
				);
			}
			coefficient=coefficient.multiply(f.coefficient);
		} else super.put(arithmetic);
	}

	protected Arithmetic newinstance() {
		return new FactorizedUnivariatePolynomial(unknown[0]);
	}
}
