package jscl.math;

import java.util.*;

public class FactorizedExpression extends Factorized {
	FactorizedExpression() {}

	public Arithmetic add(Arithmetic arithmetic) {
		if(arithmetic instanceof FactorizedExpression) {
			return super.add(arithmetic);
		} else if(arithmetic instanceof Expression) {
			return add(arithmetic.factorize());
		} else if(arithmetic instanceof JSCLInteger) {
			return add(valueof(arithmetic));
		} else {
			return arithmetic.valueof(this).add(arithmetic);
		}
	}

	public Arithmetic multiply(Arithmetic arithmetic) {
		if(arithmetic instanceof FactorizedExpression) {
			return super.multiply(arithmetic);
		} else if(arithmetic instanceof Expression) {
			return multiply(arithmetic.factorize());
		} else if(arithmetic instanceof JSCLInteger) {
			return multiply(valueof(arithmetic));
		} else {
			return arithmetic.multiply(this);
		}
	}

	public Arithmetic divide(Arithmetic arithmetic) throws ArithmeticException {
		if(arithmetic instanceof FactorizedExpression) {
			return super.divide(arithmetic);
		} else if(arithmetic instanceof Expression) {
			return divide(arithmetic.factorize());
		} else if(arithmetic instanceof JSCLInteger) {
			return divide(valueof(arithmetic));
		} else {
			return arithmetic.valueof(this).divide(arithmetic);
		}
	}

	public Arithmetic gcd(Arithmetic arithmetic) {
		if(arithmetic instanceof FactorizedExpression) {
			return super.gcd(arithmetic);
		} else if(arithmetic instanceof Expression) {
			return gcd(arithmetic.factorize());
		} else if(arithmetic instanceof JSCLInteger) {
			return gcd(valueof(arithmetic));
		} else {
			return arithmetic.valueof(this).gcd(arithmetic);
		}
	}

	public int compareTo(Object comparable) {
		if(comparable instanceof FactorizedExpression) {
			return super.compareTo(comparable);
		} else if(comparable instanceof Expression) {
			return compareTo(((Arithmetic)comparable).factorize());
		} else if(comparable instanceof JSCLInteger) {
			return compareTo(valueof((Arithmetic)comparable));
		} else {
			return ((Arithmetic)comparable).valueof(this).compareTo(comparable);
		}
	}

	public static FactorizedExpression valueOf(Arithmetic arithmetic) {
		FactorizedExpression f=new FactorizedExpression();
		f.put(arithmetic);
		return f;
	}

	void put(Arithmetic arithmetic) {
		if(arithmetic instanceof UnivariatePolynomial || arithmetic instanceof JSCLInteger) {
			put(Expression.valueOf(arithmetic));
		} else if(arithmetic instanceof FactorizedUnivariatePolynomial) {
			FactorizedUnivariatePolynomial f=(FactorizedUnivariatePolynomial)arithmetic;
			Iterator it=f.content.entrySet().iterator();
			while(it.hasNext()) {
				Map.Entry e=(Map.Entry)it.next();
				put(
					valueof(
						(UnivariatePolynomial)e.getKey()
					).pow(
						((Integer)e.getValue()).intValue()
					)
				);
			}
			put(f.coefficient);
		} else super.put(arithmetic);
	}

	protected Arithmetic newinstance() {
		return new FactorizedExpression();
	}
}
