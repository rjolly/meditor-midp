package jscl.math;

import jscl.math.function.*;
import jscl.math.numeric.*;
import jscl.text.*;

public final class NumericWrapper extends Arithmetic {
	public static final Parser parser=DoubleParser.parser;
	final Numeric content;

	public NumericWrapper(JSCLInteger integer) {
		content=JSCLDouble.valueOf(integer.content.doubleValue());
	}

	public NumericWrapper(Rational rational) {
		content=JSCLDouble.valueOf(rational.numerator.doubleValue()/rational.denominator.doubleValue());
	}

	public NumericWrapper(JSCLVector vector) {
		Numeric v[]=new Numeric[vector.n];
		for(int i=0;i<vector.n;i++) v[i]=((NumericWrapper)vector.element[i].numeric()).content();
		content=new NumericVector(v);
	}

	public NumericWrapper(Matrix matrix) {
		Numeric m[][]=new Numeric[matrix.n][matrix.p];
		for(int i=0;i<matrix.n;i++) {
			for(int j=0;j<matrix.p;j++) {
				m[i][j]=((NumericWrapper)matrix.element[i][j].numeric()).content();
			}
		}
		content=new NumericMatrix(m);
	}

	public NumericWrapper(Constant constant) {
		if(constant.compareTo(new Constant("pi"))==0) content=JSCLDouble.valueOf(Math.PI);
		else if(constant.compareTo(new Constant("infin"))==0) content=JSCLDouble.valueOf(Double.POSITIVE_INFINITY);
		else throw new ArithmeticException();
	}

	NumericWrapper(Numeric numeric) {
		content=numeric;
	}

	public Numeric content() {
		return content;
	}

	public Arithmetic add(Arithmetic arithmetic) {
		if(arithmetic instanceof NumericWrapper) {
			return new NumericWrapper(content.add(((NumericWrapper)arithmetic).content));
		} else {
			return add(valueof(arithmetic));
		}
	}

	public Arithmetic subtract(Arithmetic arithmetic) {
		if(arithmetic instanceof NumericWrapper) {
			return new NumericWrapper(content.subtract(((NumericWrapper)arithmetic).content));
		} else {
			return subtract(valueof(arithmetic));
		}
	}

	public Arithmetic multiply(Arithmetic arithmetic) {
		if(arithmetic instanceof NumericWrapper) {
			return new NumericWrapper(content.multiply(((NumericWrapper)arithmetic).content));
		} else {
			return multiply(valueof(arithmetic));
		}
	}

	public Arithmetic divide(Arithmetic arithmetic) throws ArithmeticException {
		if(arithmetic instanceof NumericWrapper) {
			return new NumericWrapper(content.divide(((NumericWrapper)arithmetic).content));
		} else {
			return divide(valueof(arithmetic));
		}
	}

	public Arithmetic gcd(Arithmetic arithmetic) {
		return null;
	}

	public Arithmetic gcd() {
		return null;
	}

	public Arithmetic abs() {
		return new NumericWrapper(content.abs());
	}

	public Arithmetic negate() {
		return new NumericWrapper(content.negate());
	}

	public int signum() {
		return content.signum();
	}

	public int degree() {
		return 0;
	}

	public Arithmetic antiderivative(Variable variable) throws NotIntegrableException {
		return null;
	}

	public Arithmetic derivative(Variable variable) {
		return null;
	}

	public Arithmetic substitute(Variable variable, Arithmetic arithmetic) {
		return null;
	}

	public Arithmetic expand() {
		return null;
	}

	public Arithmetic factorize() {
		return null;
	}

	public Arithmetic elementary() {
		return null;
	}

	public Arithmetic simplify() {
		return null;
	}

	public Arithmetic numeric() {
		return this;
	}

	public Arithmetic valueof(Arithmetic arithmetic) {
		if(arithmetic instanceof NumericWrapper) {
			return new NumericWrapper(content.valueof(((NumericWrapper)arithmetic).content));
		} else if(arithmetic instanceof JSCLInteger) { 
			return new NumericWrapper((JSCLInteger)arithmetic);
		} else if(arithmetic instanceof Rational) { 
			return new NumericWrapper((Rational)arithmetic);
		} else throw new ArithmeticException();
	}

	public Arithmetic[] sumValue() {
		return null;
	}

	public Arithmetic[] productValue() throws NotProductException {
		return null;
	}

	public Object[] powerValue() throws NotPowerException {
		return null;
	}

	public Expression expressionValue() throws NotExpressionException {
		throw new NotExpressionException();
	}

	public JSCLInteger integerValue() throws NotIntegerException {
		throw new NotIntegerException();
	}

	public Variable variableValue() throws NotVariableException {
		throw new NotVariableException();
	}

	public Variable[] variables() {
		return new Variable[0];
	}

	public boolean isPolynomial(Variable variable) {
		return true;
	}

	public boolean isConstant(Variable variable) {
		return true;
	}

	public Arithmetic sgn() {
		return new NumericWrapper(content.sgn());
	}

	public Arithmetic log() {
		return new NumericWrapper(content.log());
	}

	public Arithmetic exp() {
		return new NumericWrapper(content.exp());
	}

	public Arithmetic pow(Arithmetic arithmetic) {
		return new NumericWrapper(content.pow(((NumericWrapper)arithmetic).content));
	}

	public Arithmetic sqrt() {
		return new NumericWrapper(content.sqrt());
	}

	public static Arithmetic root(int subscript, Arithmetic parameter[]) {
		Numeric param[]=new Numeric[parameter.length];
		for(int i=0;i<param.length;i++) param[i]=((NumericWrapper)parameter[i]).content;
		return new NumericWrapper(Numeric.root(subscript,param));
	}

	public Arithmetic conjugate() {
		return new NumericWrapper(content.conjugate());
	}

	public Arithmetic acos() {
		return new NumericWrapper(content.acos());
	}

	public Arithmetic asin() {
		return new NumericWrapper(content.asin());
	}

	public Arithmetic atan() {
		return new NumericWrapper(content.atan());
	}

	public Arithmetic cos() {
		return new NumericWrapper(content.cos());
	}

	public Arithmetic sin() {
		return new NumericWrapper(content.sin());
	}

	public Arithmetic tan() {
		return new NumericWrapper(content.tan());
	}

	public Arithmetic acosh() {
		return new NumericWrapper(content.acosh());
	}

	public Arithmetic asinh() {
		return new NumericWrapper(content.asinh());
	}

	public Arithmetic atanh() {
		return new NumericWrapper(content.atanh());
	}

	public Arithmetic cosh() {
		return new NumericWrapper(content.cosh());
	}

	public Arithmetic sinh() {
		return new NumericWrapper(content.sinh());
	}

	public Arithmetic tanh() {
		return new NumericWrapper(content.tanh());
	}

	public int compareTo(Object comparable) {
		if(comparable instanceof NumericWrapper) {
			return content.compareTo(((NumericWrapper)comparable).content);
		} else {
			return compareTo(valueof((Arithmetic)comparable));
		}
	}

	public String toString() {
		return content.toString();
	}

	public String toJava() {
		return "JSCLDouble.valueOf("+new Double(((JSCLDouble)content).doubleValue())+")";
	}

	public String toMathML(Object data) {
		IndentedBuffer buffer=new IndentedBuffer();
		int exponent=data instanceof Integer?((Integer)data).intValue():1;
		if(exponent==1) {
			buffer.append(bodyToMathML());
		} else {
			buffer.append("<msup>\n");
			buffer.append(1,bodyToMathML());
			buffer.append(1,"<mn>").append(exponent).append("</mn>\n");
			buffer.append("</msup>\n");
		}
		return buffer.toString();
	}

	String bodyToMathML() {
		IndentedBuffer buffer=new IndentedBuffer();
		buffer.append("<mn>").append(new Double(((JSCLDouble)content).doubleValue())).append("</mn>\n");
		return buffer.toString();
	}

	protected Arithmetic newinstance() {
		return null;
	}
}

class DoubleParser extends Parser {
	public static final Parser parser=new DoubleParser();

	private DoubleParser() {}

	public Object parse(String str, int pos[]) throws ParseException {
		int pos0=pos[0];
		double d;
		try {
			d=((Double)Singularity.parser.parse(str,pos)).doubleValue();
		} catch (ParseException e) {
			try {
				d=((Double)FloatingPointLiteral.parser.parse(str,pos)).doubleValue();
			} catch (ParseException e2) {
				throw e2;
			}
		}
		return new NumericWrapper(JSCLDouble.valueOf(d));
	}
}

class Singularity extends Parser {
	public static final Parser parser=new Singularity();

	private Singularity() {}

	public Object parse(String str, int pos[]) throws ParseException {
		int pos0=pos[0];
		double d;
		try {
			String s=(String)Constant.identifier.parse(str,pos);
			if(s.compareTo("NaN")==0) d=Double.NaN;
			else if(s.compareTo("Infinity")==0) d=Double.POSITIVE_INFINITY;
			else {
				pos[0]=pos0;
				throw new ParseException();
			}
		} catch (ParseException e) {
			throw e;
		}
		return new Double(d);
	}
}

class FloatingPointLiteral extends Parser {
	public static final Parser parser=new FloatingPointLiteral();

	private FloatingPointLiteral() {}

	public Object parse(String str, int pos[]) throws ParseException {
		int pos0=pos[0];
		StringBuffer buffer=new StringBuffer();
		boolean digits=false;
		boolean point=false;
		try {
			String s=(String)JSCLInteger.digits.parse(str,pos);
			buffer.append(s);
			digits=true;
		} catch (ParseException e) {}
		try {
			Point.parser.parse(str,pos);
			buffer.append(".");
			point=true;
		} catch (ParseException e) {
			if(!digits) {
				pos[0]=pos0;
				throw e;
			}
		}
		try {
			String s=(String)JSCLInteger.digits.parse(str,pos);
			buffer.append(s);
		} catch (ParseException e) {
			if(!digits) {
				pos[0]=pos0;
				throw e;
			}
		}
		try {
			String s=(String)ExponentPart.parser.parse(str,pos);
			buffer.append(s);
		} catch (ParseException e) {
			if(!point) {
				pos[0]=pos0;
				throw e;
			}
		}
		return new Double(buffer.toString());
	}
}

class Point extends Parser {
	public static final Parser parser=new Point();

	private Point() {}

	public Object parse(String str, int pos[]) throws ParseException {
		int pos0=pos[0];
		skipWhitespaces(str,pos);
		if(pos[0]<str.length() && str.charAt(pos[0])=='.') {
			str.charAt(pos[0]++);
		} else {
			pos[0]=pos0;
			throw new ParseException();
		}
		return null;
	}
}

class ExponentPart extends Parser {
	public static final Parser parser=new ExponentPart();

	private ExponentPart() {}

	public Object parse(String str, int pos[]) throws ParseException {
		int pos0=pos[0];
		StringBuffer buffer=new StringBuffer();
		skipWhitespaces(str,pos);
		if(pos[0]<str.length() && (str.charAt(pos[0])=='e' || str.charAt(pos[0])=='E')) {
			char c=str.charAt(pos[0]++);
			buffer.append(c);
		} else {
			pos[0]=pos0;
			throw new ParseException();
		}
		try {
			String s=(String)SignedInteger.parser.parse(str,pos);
			buffer.append(s);
		} catch (ParseException e) {
			pos[0]=pos0;
			throw e;
		}
		return buffer.toString();
	}
}

class SignedInteger extends Parser {
	public static final Parser parser=new SignedInteger();

	private SignedInteger() {}

	public Object parse(String str, int pos[]) throws ParseException {
		int pos0=pos[0];
		StringBuffer buffer=new StringBuffer();
		skipWhitespaces(str,pos);
		if(pos[0]<str.length() && (str.charAt(pos[0])=='+' || str.charAt(pos[0])=='-')) {
			char c=str.charAt(pos[0]++);
			buffer.append(c);
		}
		try {
			int n=((Integer)Constant.integer.parse(str,pos)).intValue();
			buffer.append(n);
		} catch (ParseException e) {
			pos[0]=pos0;
			throw e;
		}
		return buffer.toString();
	}
}
