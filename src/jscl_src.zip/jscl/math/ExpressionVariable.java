package jscl.math;

import jscl.text.*;

public class ExpressionVariable extends ArithmeticVariable {
	public static final Parser parser=BracketedExpression.parser;

	public ExpressionVariable(Arithmetic arithmetic) {
		super(arithmetic);
	}

	public static Arithmetic content(Arithmetic arithmetic) {
		try {
			Variable v=arithmetic.variableValue();
			if(v instanceof ExpressionVariable) arithmetic=((ExpressionVariable)v).content;
		} catch (NotVariableException e) {}
		return arithmetic;
	}

	public Arithmetic elementary() {
		return content.elementary();
	}

	public Arithmetic simplify() {
		return content.simplify();
	}

	public String toString() {
		StringBuffer buffer=new StringBuffer();
		buffer.append("(").append(content).append(")");
		return buffer.toString();
	}

	public String toMathML(Object data) {
		IndentedBuffer buffer=new IndentedBuffer();
		int exponent=data instanceof Integer?((Integer)data).intValue():1;
		if(exponent==1) {
			buffer.append(bodyToMathML());
		} else {
			buffer.append("<msup>\n");
			buffer.append(1,bodyToMathML());
			buffer.append(1,"<mn>").append(exponent).append("</mn>\n");
			buffer.append("</msup>\n");
		}
		return buffer.toString();
	}

	String bodyToMathML() {
		IndentedBuffer buffer=new IndentedBuffer();
		buffer.append("<mrow>\n");
		buffer.append(1,"<mo>(</mo>\n");
		buffer.append(1,content.toMathML(null));
		buffer.append(1,"<mo>)</mo>\n");
		buffer.append("</mrow>\n");
		return buffer.toString();
	}

	protected Variable newinstance() {
		return new ExpressionVariable(null);
	}
}

class BracketedExpression extends Parser {
	public static final Parser parser=new BracketedExpression();

	private BracketedExpression() {}

	public Object parse(String str, int pos[]) throws ParseException {
		int pos0=pos[0];
		Arithmetic a;
		skipWhitespaces(str,pos);
		if(pos[0]<str.length() && str.charAt(pos[0])=='(') {
			str.charAt(pos[0]++);
		} else {
			pos[0]=pos0;
			throw new ParseException();
		}
		try {
			a=(Arithmetic)Expression.parser.parse(str,pos);
		} catch (ParseException e) {
			pos[0]=pos0;
			throw e;
		}
		skipWhitespaces(str,pos);
		if(pos[0]<str.length() && str.charAt(pos[0])==')') {
			str.charAt(pos[0]++);
		} else {
			pos[0]=pos0;
			throw new ParseException();
		}
		return new ExpressionVariable(a);
	}
}
