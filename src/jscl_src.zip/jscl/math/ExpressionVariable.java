package jscl.math;

import jscl.text.*;

public class ExpressionVariable extends GenericVariable {
	public static final Parser parser=BracketedExpression.parser;

	public ExpressionVariable(Generic generic) {
		super(generic);
	}

	public static Generic content(Generic generic) {
		try {
			Variable v=generic.variableValue();
			if(v instanceof ExpressionVariable) generic=((ExpressionVariable)v).content;
		} catch (NotVariableException e) {}
		return generic;
	}

	public Generic substitute(Variable variable, Generic generic) {
		if(isIdentity(variable)) return generic;
		else return content.substitute(variable,generic);
	}

	public Generic elementary() {
		return content.elementary();
	}

	public Generic simplify() {
		return content.simplify();
	}

	public String toString() {
		StringBuffer buffer=new StringBuffer();
		buffer.append("(").append(content).append(")");
		return buffer.toString();
	}

	public String toJava() {
		StringBuffer buffer=new StringBuffer();
		buffer.append("(").append(content.toJava()).append(")");
		return buffer.toString();
	}

	public String toMathML(Object data) {
		IndentedBuffer buffer=new IndentedBuffer();
		int exponent=data instanceof Integer?((Integer)data).intValue():1;
		if(exponent==1) {
			buffer.append(bodyToMathML());
		} else {
			buffer.append("<msup>\n");
			buffer.append(1,bodyToMathML());
			buffer.append(1,"<mn>").append(exponent).append("</mn>\n");
			buffer.append("</msup>\n");
		}
		return buffer.toString();
	}

	String bodyToMathML() {
		IndentedBuffer buffer=new IndentedBuffer();
		buffer.append("<mfenced>\n");
		buffer.append(1,content.toMathML(null));
		buffer.append("</mfenced>\n");
		return buffer.toString();
	}

	protected Variable newinstance() {
		return new ExpressionVariable(null);
	}
}

class BracketedExpression extends Parser {
	public static final Parser parser=new BracketedExpression();

	private BracketedExpression() {}

	public Object parse(String str, int pos[]) throws ParseException {
		int pos0=pos[0];
		Generic a;
		skipWhitespaces(str,pos);
		if(pos[0]<str.length() && str.charAt(pos[0])=='(') {
			str.charAt(pos[0]++);
		} else {
			pos[0]=pos0;
			throw new ParseException();
		}
		try {
			a=(Generic)Expression.parser.parse(str,pos);
		} catch (ParseException e) {
			pos[0]=pos0;
			throw e;
		}
		skipWhitespaces(str,pos);
		if(pos[0]<str.length() && str.charAt(pos[0])==')') {
			str.charAt(pos[0]++);
		} else {
			pos[0]=pos0;
			throw new ParseException();
		}
		return new ExpressionVariable(a);
	}
}
