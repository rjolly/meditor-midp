package jscl.math;

import jscl.util.*;

public class IntegerVariable extends ArithmeticVariable {
	public IntegerVariable(JSCLInteger integer) {
		super(integer);
	}

	public static Arithmetic content(Arithmetic arithmetic) {
		try {
			Variable v=arithmetic.variableValue();
			if(v instanceof IntegerVariable) arithmetic=((IntegerVariable)v).content;
		} catch (NotVariableException e) {}
		return arithmetic;
	}

	public Arithmetic elementary() {
		return content.elementary();
	}

	public Arithmetic simplify() {
		return content.simplify();
	}

	public String toString() {
		return content.toString();
	}

	public String toMathML(Object data) {
		return content.toMathML(data);
	}

	protected Variable newinstance() {
		return new IntegerVariable(null);
	}
}
