package jscl.math;

import jscl.util.*;

public class IntegerVariable extends GenericVariable {
	public IntegerVariable(Generic generic) {
		super(generic);
	}

	public static Generic content(Generic generic) {
		try {
			Variable v=generic.variableValue();
			if(v instanceof IntegerVariable) generic=((IntegerVariable)v).content;
		} catch (NotVariableException e) {}
		return generic;
	}

	public Generic elementary() {
		return content.elementary();
	}

	public Generic simplify() {
		return content.simplify();
	}

	protected Variable newinstance() {
		return new IntegerVariable(null);
	}
}
