package jscl.text;

public class ParseException extends Exception {
	public ParseException() {}

	public ParseException(String s) {
		super(s);
	}
}
